# Streamvision CMS — Docker on AWS

## Architecture

```
Internet → EC2 (t3.micro) → Docker
                              ├── nginx container   (port 80/443)
                              ├── app container     (port 3006, internal only)
                              └── named volume      (streamtv_data → SQLite DB)
```

**DB lives in a Docker named volume** (`streamtv_data`), mounted at `/app/data`
inside the container. The volume is stored on the EC2's EBS disk and is
**completely independent of the container**. You can rebuild, update, or delete
the container and the database is untouched. Only `docker volume rm streamtv_data`
or terminating the EC2 instance destroys it (use S3 backup for the latter).

---

## First-time AWS setup

### 1. Launch EC2
- **AMI:** Ubuntu 24.04 LTS
- **Type:** t3.micro (recommended) or t4g.nano (cheapest ARM option)
- **Storage:** 20GB gp3 (default is fine)
- **Security Group:** inbound 22 (SSH), 80 (HTTP), 443 (HTTPS)
- **Key pair:** create/select one for SSH access

### 2. Deploy
```bash
# On your local machine — copy the package
scp streamTV-docker-v2.0.0.tar.gz ubuntu@<EC2-IP>:~

# SSH into the instance
ssh ubuntu@<EC2-IP>

# Extract and deploy (takes 3-5 min to build Docker image)
tar xf streamTV-docker-v2.0.0.tar.gz
cd streamTV-docker-v2.0.0
sudo bash deploy.sh
```

### 3. Configure backups (recommended)
Edit `/opt/streamtv-cms/.env`:
```
BACKUP_S3_BUCKET=your-bucket-name
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
```
Then: `sudo streamtv backup` to test, or enable the backup service:
```bash
cd /opt/streamtv-cms
docker compose --profile backup up -d backup
```

### 4. Enable HTTPS
```bash
sudo apt install certbot
sudo certbot certonly --webroot \
  -w /var/lib/docker/volumes/streamtv_certbot_www/_data \
  -d yourdomain.com
# Then edit nginx/conf.d/streamtv.conf — uncomment the HTTPS server blocks
sudo streamtv nginx-reload
```

---

## Cost saving — scheduled stop/start

**For 1-2x/week usage, stop the instance overnight and on weekends.**

Deploys via CloudFormation in 2 minutes:

1. Go to **AWS Console → CloudFormation → Create Stack**
2. Upload `aws/scheduled-stop-start.json`
3. Enter your EC2 Instance ID
4. Deploy

This runs the instance **Mon–Fri 7am–7pm AEST only**.

| Instance | Always-on/mo | Scheduled/mo | Saving |
|----------|-------------|-------------|--------|
| t3.micro | ~$8.50 | ~$3.00 | ~65% |
| t4g.nano | ~$3.50 | ~$1.25 | ~65% |

> EBS storage (~$1.60/month for 20GB gp3) runs regardless — this is fine.
> The DB volume on EBS is not affected by stop/start.

**Start the instance manually any time:**
```bash
aws ec2 start-instances --instance-ids i-xxxxxxxxx
# Or just click "Start" in the AWS Console
```

---

## Day-to-day management

```bash
streamtv status       # show running containers + DB volume info
streamtv logs         # live log tail
streamtv restart      # restart app container
streamtv stop         # stop all containers (DB preserved)
streamtv start        # start all containers
streamtv update       # rebuild image + recreate container (DB preserved)
streamtv backup       # manual S3 backup
streamtv shell        # sh into app container
streamtv db           # SQLite shell on live database
```

## Restore from S3 backup
```bash
sudo bash /opt/streamtv-cms/scripts/restore.sh
# or from a specific backup:
sudo bash /opt/streamtv-cms/scripts/restore.sh s3://your-bucket/streamtv-cms/backups/streamtv-20260220-060000.db
```

## Update the app
```bash
# Upload new source, then on the server:
sudo streamtv update
# Container is replaced, DB volume is untouched.
```

---

## Default logins
> ⚠️ Change these immediately after first login!

| Role | Email | Password |
|------|-------|----------|
| Streamvision Admin | admin@streamvision.com.au | StreamTV2026! |
| Group Admin | portfolio@hilton.com | Hilton2026! |
| Hotel Admin | manager@hgidarwin.com.au | HotelDemo2026! |

## File locations on EC2
| Path | Contents |
|------|---------|
| `/opt/streamtv-cms/` | Compose files, nginx config, scripts |
| `/opt/streamtv-cms/.env` | JWT secret, S3 backup config |
| `docker volume streamtv_data` | SQLite database (EBS-backed) |
