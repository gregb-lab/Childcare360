import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { ThemeProvider, useTheme } from './context/ThemeContext.jsx';
import LoginPage from './pages/Login.jsx';
import AdminPortal from './pages/AdminPortal.jsx';
import HotelSelector from './pages/HotelSelector.jsx';
import CMS from './pages/CMS.jsx';

function AppRouter() {
  const { user, loading, activeHotel } = useAuth();
  const { C } = useTheme();

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', background: C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'DM Sans', sans-serif" }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>📺</div>
          <div style={{ color: C.textSecondary, fontSize: 14 }}>Loading Streamvision CMS...</div>
        </div>
      </div>
    );
  }

  if (!user) return <LoginPage />;
  if (user.role === 'superadmin') return <AdminPortal />;

  const needsSelector = (user.role === 'group_admin' || (user.accessibleHotels && user.accessibleHotels.length > 1)) && !activeHotel;
  if (needsSelector) return <HotelSelector />;

  const hotel = activeHotel || user.hotel;
  if (!hotel) return <HotelSelector />;

  return <CMS hotel={hotel} />;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppRouter />
      </AuthProvider>
    </ThemeProvider>
  );
}
