const BASE = '/api';

function getToken() {
  return localStorage.getItem('streamtv_token');
}

async function request(method, path, body) {
  const token = getToken();
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

export const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body),
  put: (path, body) => request('PUT', path, body),
  delete: (path) => request('DELETE', path),

  auth: {
    login: (email, password) => request('POST', '/auth/login', { email, password }),
    me: () => request('GET', '/auth/me'),
  },

  hotels: {
    list: () => request('GET', '/hotels'),
    create: (data) => request('POST', '/hotels', data),
    update: (id, data) => request('PUT', `/hotels/${id}`, data),
    stats: (hid) => request('GET', `/hotels/${hid}/stats`),
    rooms: (hid) => request('GET', `/hotels/${hid}/rooms`),
    createRoom: (hid, data) => request('POST', `/hotels/${hid}/rooms`, data),
    updateRoom: (hid, rid, data) => request('PUT', `/hotels/${hid}/rooms/${rid}`, data),
    devices: (hid) => request('GET', `/hotels/${hid}/devices`),
    faults: (hid) => request('GET', `/hotels/${hid}/devices/faults`),
    resolveDevice: (hid, did, data) => request('PUT', `/hotels/${hid}/devices/${did}/resolve`, data),
    messages: (hid) => request('GET', `/hotels/${hid}/messages`),
    sendMessage: (hid, data) => request('POST', `/hotels/${hid}/messages`, data),
    channels: (hid) => request('GET', `/hotels/${hid}/channels`),
    updateChannel: (hid, cid, data) => request('PUT', `/hotels/${hid}/channels/${cid}`, data),
    movies: (hid) => request('GET', `/hotels/${hid}/movies`),
    updateMovie: (hid, mid, data) => request('PUT', `/hotels/${hid}/movies/${mid}`, data),
    minibar: (hid) => request('GET', `/hotels/${hid}/minibar`),
    createMinibarItem: (hid, data) => request('POST', `/hotels/${hid}/minibar`, data),
    updateMinibarItem: (hid, iid, data) => request('PUT', `/hotels/${hid}/minibar/${iid}`, data),
    pages: (hid) => request('GET', `/hotels/${hid}/pages`),
    createPage: (hid, data) => request('POST', `/hotels/${hid}/pages`, data),
    updatePage: (hid, pid, data) => request('PUT', `/hotels/${hid}/pages/${pid}`, data),
    audit: (hid) => request('GET', `/hotels/${hid}/audit`),
    // Signage
    signageAssets:          (hid)           => request('GET',    `/hotels/${hid}/signage/assets`),
    createSignageAsset:     (hid, data)     => request('POST',   `/hotels/${hid}/signage/assets`, data),
    deleteSignageAsset:     (hid, id)       => request('DELETE', `/hotels/${hid}/signage/assets/${id}`),
    signagePlaylists:       (hid)           => request('GET',    `/hotels/${hid}/signage/playlists`),
    createSignagePlaylist:  (hid, data)     => request('POST',   `/hotels/${hid}/signage/playlists`, data),
    updateSignagePlaylist:  (hid, id, data) => request('PUT',    `/hotels/${hid}/signage/playlists/${id}`, data),
    deleteSignagePlaylist:  (hid, id)       => request('DELETE', `/hotels/${hid}/signage/playlists/${id}`),
    signageScreens:         (hid)           => request('GET',    `/hotels/${hid}/signage/screens`),
    createSignageScreen:    (hid, data)     => request('POST',   `/hotels/${hid}/signage/screens`, data),
    updateSignageScreen:    (hid, id, data) => request('PUT',    `/hotels/${hid}/signage/screens/${id}`, data),
    deleteSignageScreen:    (hid, id)       => request('DELETE', `/hotels/${hid}/signage/screens/${id}`),
    signageSchedules:       (hid)           => request('GET',    `/hotels/${hid}/signage/schedules`),
    createSignageSchedule:  (hid, data)     => request('POST',   `/hotels/${hid}/signage/schedules`, data),
    updateSignageSchedule:  (hid, id, data) => request('PUT',    `/hotels/${hid}/signage/schedules/${id}`, data),
    deleteSignageSchedule:  (hid, id)       => request('DELETE', `/hotels/${hid}/signage/schedules/${id}`),
  },

  groups: {
    list: () => request('GET', '/groups'),
    create: (data) => request('POST', '/groups', data),
  },

  users: {
    list: () => request('GET', '/users'),
    create: (data) => request('POST', '/users', data),
    update: (id, data) => request('PUT', `/users/${id}`, data),
  },
};
