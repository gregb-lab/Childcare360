import { createContext, useContext, useState, useEffect } from 'react';

export const LIGHT = {
  mode: 'light',
  bg: '#eef2f7',
  sidebar: '#1a2644',
  sidebarHover: '#243258',
  sidebarBorder: '#243258',
  panel: '#ffffff',
  card: '#ffffff',
  cardBorder: '#dde5f0',
  teal: '#00b894',
  tealDim: '#00b89418',
  tealMid: '#00b89430',
  blue: '#3b82f6',
  amber: '#f59e0b',
  red: '#ef4444',
  green: '#22c55e',
  purple: '#8b5cf6',
  textPrimary: '#0f172a',
  textSecondary: '#475569',
  textDim: '#94a3b8',
  border: '#dde5f0',
  input: '#f1f5f9',
  inputBorder: '#dde5f0',
  tableHeader: '#f8fafc',
  tableRow: '#ffffff',
  tableRowAlt: '#f8fafc',
  shadow: '0 1px 3px rgba(0,0,0,0.08)',
  shadowLg: '0 8px 24px rgba(0,0,0,0.12)',
  sidebarText: '#94a3b8',
  sidebarActive: '#00b894',
};

export const DARK = {
  mode: 'dark',
  bg: '#0b0f1a',
  sidebar: '#0d1117',
  sidebarHover: '#161d2e',
  sidebarBorder: '#1e2d45',
  panel: '#111827',
  card: '#161d2e',
  cardBorder: '#1e2d45',
  teal: '#00d4aa',
  tealDim: '#00d4aa22',
  tealMid: '#00d4aa44',
  blue: '#3b82f6',
  amber: '#f59e0b',
  red: '#ef4444',
  green: '#22c55e',
  purple: '#a855f7',
  textPrimary: '#f1f5f9',
  textSecondary: '#8899b4',
  textDim: '#4b5e7a',
  border: '#1e2d45',
  input: '#111827',
  inputBorder: '#1e2d45',
  tableHeader: '#0d1117',
  tableRow: '#161d2e',
  tableRowAlt: '#111827',
  shadow: '0 1px 3px rgba(0,0,0,0.4)',
  shadowLg: '0 10px 30px rgba(0,0,0,0.6)',
  sidebarText: '#8899b4',
  sidebarActive: '#00d4aa',
};

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [mode, setModeState] = useState(() => localStorage.getItem('streamtv_theme') || 'light');
  const [systemDark, setSystemDark] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    setSystemDark(mq.matches);
    const handler = e => setSystemDark(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  const setMode = (m) => { setModeState(m); localStorage.setItem('streamtv_theme', m); };
  const isDark = mode === 'dark' || (mode === 'auto' && systemDark);
  const C = isDark ? DARK : LIGHT;

  return (
    <ThemeContext.Provider value={{ C, mode, setMode, isDark }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
