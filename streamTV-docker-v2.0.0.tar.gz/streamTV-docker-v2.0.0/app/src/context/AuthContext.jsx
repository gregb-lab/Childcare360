import { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../api/client.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeHotel, setActiveHotelState] = useState(null);
  const [version] = useState('2.0.0');

  useEffect(() => {
    const token = localStorage.getItem('streamtv_token');
    const savedUser = localStorage.getItem('streamtv_user');
    const savedHotel = localStorage.getItem('streamtv_active_hotel');
    if (token && savedUser) {
      try {
        const u = JSON.parse(savedUser);
        setUser(u);
        if (savedHotel) setActiveHotelState(JSON.parse(savedHotel));
        else if (u.hotel) setActiveHotelState(u.hotel);
      } catch {}
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const data = await api.auth.login(email, password);
    localStorage.setItem('streamtv_token', data.token);
    localStorage.setItem('streamtv_user', JSON.stringify(data.user));
    setUser(data.user);
    // Auto-select hotel if only one
    if (data.user.hotel) {
      setActiveHotelState(data.user.hotel);
      localStorage.setItem('streamtv_active_hotel', JSON.stringify(data.user.hotel));
    } else if (data.user.accessibleHotels?.length === 1) {
      const h = data.user.accessibleHotels[0];
      setActiveHotelState(h);
      localStorage.setItem('streamtv_active_hotel', JSON.stringify(h));
    }
    return data;
  };

  const logout = () => {
    localStorage.removeItem('streamtv_token');
    localStorage.removeItem('streamtv_user');
    localStorage.removeItem('streamtv_active_hotel');
    setUser(null);
    setActiveHotelState(null);
  };

  const setActiveHotel = (hotel) => {
    setActiveHotelState(hotel);
    localStorage.setItem('streamtv_active_hotel', JSON.stringify(hotel));
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, activeHotel, setActiveHotel, version }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
