import { useState, useEffect } from 'react';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import {
  Building2, Users, Plus, Edit, Check, X, RefreshCw,
  Globe, Mail, Tv, Shield, ChevronDown, AlertCircle, Layers
} from 'lucide-react';


const badge = (label, color) => (
  <span style={{ background: color + '22', color, border: `1px solid ${color}44`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 }}>{label}</span>
);

const Btn = ({ children, variant = 'primary', size = 'md', onClick, icon: Icon, style: s = {} }) => {
  const { C, isDark } = useTheme();
  const variants = {
    primary: { background: C.teal, color: isDark ? '#07080f' : '#fff', border: 'none' },
    secondary: { background: C.card, color: C.textPrimary, border: `1px solid ${C.border}` },
    danger: { background: C.red + '18', color: C.red, border: `1px solid ${C.red}33` },
    ghost: { background: 'transparent', color: C.textSecondary, border: '1px solid transparent' },
  };
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer',
      borderRadius: 8, fontWeight: 600, fontFamily: 'inherit',
      fontSize: size === 'sm' ? 12 : 14, padding: size === 'sm' ? '6px 12px' : '9px 16px',
      ...variants[variant], ...s
    }}>
      {Icon && <Icon size={size === 'sm' ? 13 : 15} />}
      {children}
    </button>
  );
};

const Modal = ({ title, onClose, children }) => {
  const { C } = useTheme();
  return (
  <div style={{
    position: 'fixed', inset: 0, background: '#00000088', zIndex: 200,
    display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20
  }}>
    <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: 28, width: '100%', maxWidth: 480 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 }}>
        <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: C.textPrimary }}>{title}</h3>
        <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.textSecondary }}><X size={18} /></button>
      </div>
      {children}
    </div>
  </div>
  );
};

const Field = ({ label, children }) => {
  const { C } = useTheme();
  return (
  <div style={{ marginBottom: 14 }}>
    <label style={{ fontSize: 12, color: C.textSecondary, display: 'block', marginBottom: 5, fontWeight: 500 }}>{label}</label>
    {children}
  </div>
  );
};

const Input = ({ ...props }) => {
  const { C } = useTheme();
  return (
  <input {...props} style={{
    width: '100%', padding: '9px 11px', background: C.card, border: `1px solid ${C.border}`,
    borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: 'inherit',
    boxSizing: 'border-box', outline: 'none'
  }} />
  );
};

const APSelect = ({ ...props }) => {
  const { C } = useTheme();
  return (
  <select {...props} style={{
    width: '100%', padding: '9px 11px', background: C.card, border: `1px solid ${C.border}`,
    borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: 'inherit', boxSizing: 'border-box'
  }} />
  );
};

export default function AdminPortal() {
  const { C } = useTheme();
  const { user, logout, version } = useAuth();
  const [tab, setTab] = useState('hotels');
  const [hotels, setHotels] = useState([]);
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [showAddHotel, setShowAddHotel] = useState(false);
  const [showAddGroup, setShowAddGroup] = useState(false);
  const [showAddUser, setShowAddUser] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [hotelForm, setHotelForm] = useState({ name: '', code: '', group_id: '', city: '', country: 'Australia', timezone: 'Australia/Sydney', total_rooms: '', contact_email: '' });
  const [groupForm, setGroupForm] = useState({ name: '', code: '', country: 'Australia', contact_email: '' });
  const [userForm, setUserForm] = useState({ name: '', email: '', password: '', role: 'hotel_admin', group_id: '', hotel_id: '' });

  const load = async () => {
    try {
      const [h, g, u] = await Promise.all([api.hotels.list(), api.groups.list(), api.users.list()]);
      setHotels(h); setGroups(g); setUsers(u);
    } catch (e) { setError(e.message); }
  };

  useEffect(() => { load(); }, []);

  const flash = (msg) => { setSuccess(msg); setTimeout(() => setSuccess(''), 3000); };

  const submitHotel = async () => {
    try {
      await api.hotels.create({ ...hotelForm, group_id: hotelForm.group_id || null, total_rooms: parseInt(hotelForm.total_rooms) || 0 });
      setShowAddHotel(false); setHotelForm({ name: '', code: '', group_id: '', city: '', country: 'Australia', timezone: 'Australia/Sydney', total_rooms: '', contact_email: '' });
      load(); flash('Hotel created successfully');
    } catch (e) { setError(e.message); }
  };

  const submitGroup = async () => {
    try {
      await api.groups.create(groupForm);
      setShowAddGroup(false); setGroupForm({ name: '', code: '', country: 'Australia', contact_email: '' });
      load(); flash('Group created successfully');
    } catch (e) { setError(e.message); }
  };

  const submitUser = async () => {
    try {
      await api.users.create({ ...userForm, group_id: userForm.group_id || null, hotel_id: userForm.hotel_id || null });
      setShowAddUser(false); setUserForm({ name: '', email: '', password: '', role: 'hotel_admin', group_id: '', hotel_id: '' });
      load(); flash('User created successfully');
    } catch (e) { setError(e.message); }
  };

  const roleColor = (r) => ({ superadmin: C.red, group_admin: C.purple, hotel_admin: C.blue, hotel_staff: C.green }[r] || C.textDim);

  return (
    <div style={{ display: 'flex', height: '100vh', background: C.bg, fontFamily: "'DM Sans', sans-serif", color: C.textPrimary }}>
      {/* Sidebar */}
      <div style={{ width: 220, background: C.sidebar, borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '20px 16px 16px', borderBottom: `1px solid ${C.border}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: C.teal, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Tv size={17} color='#07080f' />
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 800, color: C.textPrimary }}>streamvision</div>
              <div style={{ fontSize: 9, color: C.red, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase' }}>Admin Portal</div>
            </div>
          </div>
        </div>

        <div style={{ padding: '10px 0', flex: 1 }}>
          {[
            ['hotels', Building2, 'Hotels'],
            ['groups', Layers, 'Hotel Groups'],
            ['users', Users, 'Users & Access'],
          ].map(([k, Icon, label]) => (
            <button key={k} onClick={() => setTab(k)} style={{
              display: 'flex', alignItems: 'center', gap: 9, width: '100%',
              padding: '10px 16px', background: tab === k ? C.tealDim : 'transparent',
              border: 'none', borderLeft: `2px solid ${tab === k ? C.teal : 'transparent'}`,
              cursor: 'pointer', fontFamily: 'inherit', color: tab === k ? C.teal : C.textSecondary,
              fontSize: 13, fontWeight: tab === k ? 600 : 400
            }}>
              <Icon size={15} /> {label}
            </button>
          ))}
        </div>

        <div style={{ padding: '12px 14px', borderTop: `1px solid ${C.border}` }}>
          <div style={{ fontSize: 12, color: C.textSecondary, marginBottom: 4 }}>{user.name}</div>
          <div style={{ fontSize: 10, color: C.textDim, marginBottom: 10 }}>v{version}</div>
          <button onClick={logout} style={{
            width: '100%', padding: '7px', background: C.card, border: `1px solid ${C.border}`,
            borderRadius: 6, color: C.textSecondary, cursor: 'pointer', fontSize: 12, fontFamily: 'inherit'
          }}>Sign Out</button>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 28 }}>
        {success && (
          <div style={{ background: '#22c55e18', border: '1px solid #22c55e44', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 13, color: C.green }}>
            ✓ {success}
          </div>
        )}
        {error && (
          <div style={{ background: '#ef444418', border: '1px solid #ef444433', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 13, color: C.red, display: 'flex', justifyContent: 'space-between' }}>
            <span>⚠ {error}</span><button onClick={() => setError('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.red }}>×</button>
          </div>
        )}

        {/* HOTELS TAB */}
        {tab === 'hotels' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <div>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Hotels</h2>
                <p style={{ margin: '3px 0 0', fontSize: 13, color: C.textSecondary }}>{hotels.length} properties registered</p>
              </div>
              <Btn icon={Plus} onClick={() => setShowAddHotel(true)}>Add Hotel</Btn>
            </div>

            <div style={{ display: 'grid', gap: 10 }}>
              {hotels.map(h => (
                <div key={h.id} style={{
                  background: C.card, border: `1px solid ${h.active ? C.cardBorder : C.red + '33'}`,
                  borderRadius: 10, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14
                }}>
                  <div style={{
                    width: 40, height: 40, borderRadius: 8, background: C.tealDim,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
                  }}>
                    <Building2 size={18} color={C.teal} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontWeight: 700, fontSize: 15, color: C.textPrimary }}>{h.name}</span>
                      {badge(h.code, C.teal)}
                      {!h.active && badge('Inactive', C.red)}
                    </div>
                    <div style={{ fontSize: 12, color: C.textSecondary, marginTop: 3 }}>
                      {h.city}, {h.country} · {h.total_rooms} rooms
                      {h.group_name && ` · ${h.group_name}`}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <span style={{ fontSize: 12, color: C.textDim }}>#{h.id}</span>
                    {badge(h.active ? 'Active' : 'Inactive', h.active ? C.green : C.red)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* GROUPS TAB */}
        {tab === 'groups' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <div>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Hotel Groups</h2>
                <p style={{ margin: '3px 0 0', fontSize: 13, color: C.textSecondary }}>{groups.length} groups</p>
              </div>
              <Btn icon={Plus} onClick={() => setShowAddGroup(true)}>Add Group</Btn>
            </div>
            <div style={{ display: 'grid', gap: 10 }}>
              {groups.map(g => (
                <div key={g.id} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 8, background: '#a855f722', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Layers size={18} color={C.purple} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 15, color: C.textPrimary }}>{g.name} <span style={{ fontSize: 11, color: C.textDim }}>· {g.code}</span></div>
                    <div style={{ fontSize: 12, color: C.textSecondary, marginTop: 3 }}>{g.country} · {g.contact_email}</div>
                  </div>
                  <div style={{ fontSize: 13, color: C.teal, fontWeight: 600 }}>{g.hotel_count} hotels</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* USERS TAB */}
        {tab === 'users' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <div>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700 }}>Users & Access</h2>
                <p style={{ margin: '3px 0 0', fontSize: 13, color: C.textSecondary }}>{users.length} users</p>
              </div>
              <Btn icon={Plus} onClick={() => setShowAddUser(true)}>Add User</Btn>
            </div>
            <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                    {['Name', 'Email', 'Role', 'Hotel/Group', 'Last Login', 'Status'].map(h => (
                      <th key={h} style={{ padding: '11px 14px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: 0.6 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => {
                    const hotel = hotels.find(h => h.id === u.hotel_id);
                    const group = groups.find(g => g.id === u.group_id);
                    return (
                      <tr key={u.id} style={{ borderBottom: `1px solid ${C.border}` }}>
                        <td style={{ padding: '11px 14px', fontWeight: 600, color: C.textPrimary, fontSize: 13 }}>{u.name}</td>
                        <td style={{ padding: '11px 14px', color: C.textSecondary, fontSize: 12 }}>{u.email}</td>
                        <td style={{ padding: '11px 14px' }}>{badge(u.role.replace('_', ' '), roleColor(u.role))}</td>
                        <td style={{ padding: '11px 14px', color: C.textSecondary, fontSize: 12 }}>
                          {hotel?.name || group?.name || '—'}
                        </td>
                        <td style={{ padding: '11px 14px', color: C.textDim, fontSize: 12 }}>
                          {u.last_login ? new Date(u.last_login).toLocaleDateString() : 'Never'}
                        </td>
                        <td style={{ padding: '11px 14px' }}>{badge(u.active ? 'Active' : 'Inactive', u.active ? C.green : C.red)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* ADD HOTEL MODAL */}
      {showAddHotel && (
        <Modal title='Add New Hotel' onClose={() => setShowAddHotel(false)}>
          <Field label='Hotel Name'><Input value={hotelForm.name} onChange={e => setHotelForm({ ...hotelForm, name: e.target.value })} placeholder='e.g. Hilton Garden Inn Perth' /></Field>
          <Field label='Hotel Code'><Input value={hotelForm.code} onChange={e => setHotelForm({ ...hotelForm, code: e.target.value })} placeholder='e.g. HGI-PER' /></Field>
          <Field label='Hotel Group (optional)'>
            <APSelect value={hotelForm.group_id} onChange={e => setHotelForm({ ...hotelForm, group_id: e.target.value })}>
              <option value=''>No group (standalone)</option>
              {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </APSelect>
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <Field label='City'><Input value={hotelForm.city} onChange={e => setHotelForm({ ...hotelForm, city: e.target.value })} placeholder='Darwin' /></Field>
            <Field label='Country'><Input value={hotelForm.country} onChange={e => setHotelForm({ ...hotelForm, country: e.target.value })} /></Field>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <Field label='Timezone'>
              <APSelect value={hotelForm.timezone} onChange={e => setHotelForm({ ...hotelForm, timezone: e.target.value })}>
                {['Australia/Sydney', 'Australia/Melbourne', 'Australia/Brisbane', 'Australia/Darwin', 'Australia/Perth', 'Australia/Adelaide', 'Pacific/Auckland'].map(tz => <option key={tz}>{tz}</option>)}
              </APSelect>
            </Field>
            <Field label='Total Rooms'><Input type='number' value={hotelForm.total_rooms} onChange={e => setHotelForm({ ...hotelForm, total_rooms: e.target.value })} placeholder='0' /></Field>
          </div>
          <Field label='Contact Email'><Input type='email' value={hotelForm.contact_email} onChange={e => setHotelForm({ ...hotelForm, contact_email: e.target.value })} placeholder='gm@hotel.com' /></Field>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 4 }}>
            <Btn variant='secondary' onClick={() => setShowAddHotel(false)}>Cancel</Btn>
            <Btn variant='primary' icon={Check} onClick={submitHotel}>Create Hotel</Btn>
          </div>
        </Modal>
      )}

      {/* ADD GROUP MODAL */}
      {showAddGroup && (
        <Modal title='Add Hotel Group' onClose={() => setShowAddGroup(false)}>
          <Field label='Group Name'><Input value={groupForm.name} onChange={e => setGroupForm({ ...groupForm, name: e.target.value })} placeholder='e.g. Marriott Portfolio' /></Field>
          <Field label='Group Code'><Input value={groupForm.code} onChange={e => setGroupForm({ ...groupForm, code: e.target.value })} placeholder='e.g. MARRIOTT' /></Field>
          <Field label='Country'><Input value={groupForm.country} onChange={e => setGroupForm({ ...groupForm, country: e.target.value })} /></Field>
          <Field label='Contact Email'><Input type='email' value={groupForm.contact_email} onChange={e => setGroupForm({ ...groupForm, contact_email: e.target.value })} /></Field>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 4 }}>
            <Btn variant='secondary' onClick={() => setShowAddGroup(false)}>Cancel</Btn>
            <Btn variant='primary' icon={Check} onClick={submitGroup}>Create Group</Btn>
          </div>
        </Modal>
      )}

      {/* ADD USER MODAL */}
      {showAddUser && (
        <Modal title='Add User' onClose={() => setShowAddUser(false)}>
          <Field label='Full Name'><Input value={userForm.name} onChange={e => setUserForm({ ...userForm, name: e.target.value })} placeholder='Jane Smith' /></Field>
          <Field label='Email'><Input type='email' value={userForm.email} onChange={e => setUserForm({ ...userForm, email: e.target.value })} placeholder='jane@hotel.com' /></Field>
          <Field label='Password'><Input type='password' value={userForm.password} onChange={e => setUserForm({ ...userForm, password: e.target.value })} placeholder='Temporary password' /></Field>
          <Field label='Role'>
            <APSelect value={userForm.role} onChange={e => setUserForm({ ...userForm, role: e.target.value })}>
              <option value='superadmin'>Streamvision Admin</option>
              <option value='group_admin'>Group Admin</option>
              <option value='hotel_admin'>Hotel Admin</option>
              <option value='hotel_staff'>Hotel Staff</option>
            </APSelect>
          </Field>
          {(userForm.role === 'group_admin') && (
            <Field label='Assign to Group'>
              <APSelect value={userForm.group_id} onChange={e => setUserForm({ ...userForm, group_id: e.target.value })}>
                <option value=''>Select group...</option>
                {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </APSelect>
            </Field>
          )}
          {(userForm.role === 'hotel_admin' || userForm.role === 'hotel_staff') && (
            <Field label='Assign to Hotel'>
              <APSelect value={userForm.hotel_id} onChange={e => setUserForm({ ...userForm, hotel_id: e.target.value })}>
                <option value=''>Select hotel...</option>
                {hotels.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
              </APSelect>
            </Field>
          )}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 4 }}>
            <Btn variant='secondary' onClick={() => setShowAddUser(false)}>Cancel</Btn>
            <Btn variant='primary' icon={Check} onClick={submitUser}>Create User</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}
