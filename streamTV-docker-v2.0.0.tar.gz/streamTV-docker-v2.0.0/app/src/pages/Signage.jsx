import { useState, useRef, useCallback, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext.jsx';
import { Btn, Badge, Card, SectionHeader, Modal, Field, Input, Select, Toggle } from '../components/UI.jsx';
import {
  Monitor, Plus, Upload, Trash2, Edit, Copy, Play, Pause, Eye,
  Grid, List, Search, Clock, Image, Video, FileText, Layers,
  AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline,
  ChevronDown, ChevronUp, RotateCw, ZoomIn, ZoomOut, Move,
  Tv, Rss, Twitter, Cloud, Plane, Film, BarChart2, Globe,
  Type, Square, Circle, Triangle, Minus, Link2, Star,
  Lock, Unlock, EyeOff, Maximize2, Layout, Save, FolderOpen,
  Magnet, Settings, X, Check, RefreshCw, Calendar, LayoutGrid,
  Sliders, Smartphone, Tablet, Monitor as DesktopIcon, Wand2,
  AlignJustify, ArrowRight, Download, Tag, Hash, Music
} from 'lucide-react';

// ─── ELEMENT TYPE DEFINITIONS ────────────────────────────────────────────────
const ELEMENT_TYPES = [
  { id: 'text', icon: Type, label: 'Text', color: '#3b82f6', defaultW: 400, defaultH: 80 },
  { id: 'image', icon: Image, label: 'Image', color: '#22c55e', defaultW: 300, defaultH: 200 },
  { id: 'video', icon: Video, label: 'Video', color: '#a855f7', defaultW: 400, defaultH: 225 },
  { id: 'shape', icon: Square, label: 'Shape', color: '#f59e0b', defaultW: 200, defaultH: 100 },
  { id: 'clock', icon: Clock, label: 'Clock', color: '#00d4aa', defaultW: 280, defaultH: 80 },
  { id: 'weather', icon: Cloud, label: 'Weather', color: '#3b82f6', defaultW: 280, defaultH: 120 },
  { id: 'livetv', icon: Tv, label: 'Live TV', color: '#ef4444', defaultW: 400, defaultH: 225 },
  { id: 'movies', icon: Film, label: 'Movies', color: '#a855f7', defaultW: 360, defaultH: 200 },
  { id: 'rss', icon: Rss, label: 'RSS / News', color: '#f59e0b', defaultW: 400, defaultH: 120 },
  { id: 'social', icon: Twitter, label: 'Social Feed', color: '#1da1f2', defaultW: 360, defaultH: 300 },
  { id: 'flights', icon: Plane, label: 'Flights', color: '#6366f1', defaultW: 500, defaultH: 250 },
  { id: 'slideshow', icon: Layers, label: 'Slideshow', color: '#ec4899', defaultW: 400, defaultH: 225 },
  { id: 'webpage', icon: Globe, label: 'Web Page', color: '#14b8a6', defaultW: 500, defaultH: 300 },
  { id: 'qr', icon: Hash, label: 'QR Code', color: '#8b5cf6', defaultW: 150, defaultH: 150 },
  { id: 'music', icon: Music, label: 'Music Bar', color: '#ec4899', defaultW: 400, defaultH: 60 },
];

const RESOLUTIONS = [
  { label: '1920×1080 (1080p)', w: 1920, h: 1080 },
  { label: '3840×2160 (4K)', w: 3840, h: 2160 },
  { label: '1280×720 (720p)', w: 1280, h: 720 },
  { label: '1080×1920 (Portrait)', w: 1080, h: 1920 },
  { label: '2160×3840 (4K Portrait)', w: 2160, h: 3840 },
  { label: '1024×768', w: 1024, h: 768 },
];

const FONTS = ['DM Sans', 'Arial', 'Georgia', 'Times New Roman', 'Courier New', 'Helvetica', 'Trebuchet MS', 'Impact', 'Comic Sans MS'];

const TEMPLATES = [
  { id: 'welcome', name: 'Welcome Screen', thumb: '🏨', elements: [
    { id: 't1', type: 'text', x: 100, y: 200, w: 800, h: 120, props: { text: 'Welcome', fontSize: 80, fontFamily: 'DM Sans', fontWeight: '700', color: '#ffffff', align: 'center' }},
    { id: 't2', type: 'text', x: 100, y: 340, w: 800, h: 60, props: { text: 'We hope you enjoy your stay', fontSize: 32, fontFamily: 'DM Sans', color: '#aaddff', align: 'center' }},
    { id: 't3', type: 'clock', x: 340, y: 500, w: 320, h: 80, props: { format: '12h', fontSize: 48, color: '#ffffff' }},
    { id: 't4', type: 'weather', x: 280, y: 620, w: 440, h: 120, props: { city: 'Darwin', color: '#ffffff' }},
  ]},
  { id: 'menu', name: 'Restaurant Menu', thumb: '🍽️', elements: [] },
  { id: 'info', name: 'Hotel Info', thumb: '📋', elements: [] },
  { id: 'promo', name: 'Promotion', thumb: '🎯', elements: [] },
  { id: 'lobby', name: 'Lobby Display', thumb: '🏛️', elements: [] },
  { id: 'wayfinding', name: 'Wayfinding', thumb: '🗺️', elements: [] },
];

const ASSETS_MOCK = [
  { id: 'a1', type: 'image', name: 'Pool Photo.jpg', size: '2.3 MB', thumb: '🏊', created: '2026-02-15' },
  { id: 'a2', type: 'image', name: 'Restaurant.jpg', size: '1.8 MB', thumb: '🍽️', created: '2026-02-15' },
  { id: 'a3', type: 'video', name: 'Welcome Loop.mp4', size: '45 MB', duration: '0:30', thumb: '🎬', created: '2026-02-14' },
  { id: 'a4', type: 'video', name: 'Property Tour.mp4', size: '120 MB', duration: '2:15', thumb: '🏨', created: '2026-02-13' },
  { id: 'a5', type: 'image', name: 'Logo White.png', size: '180 KB', thumb: '📛', created: '2026-02-10' },
  { id: 'a6', type: 'pdf', name: 'Dining Menu.pdf', size: '3.2 MB', thumb: '📄', created: '2026-02-10' },
  { id: 'a7', type: 'pptx', name: 'Conference Info.pptx', size: '8.4 MB', thumb: '📊', created: '2026-02-09' },
  { id: 'a8', type: 'image', name: 'Sunset View.jpg', size: '4.1 MB', thumb: '🌅', created: '2026-02-08' },
];

const PLAYLISTS_MOCK = [
  { id: 'pl1', name: 'Lobby Morning', slides: 4, duration: '2:00', status: 'active', screen: 'Lobby Screen' },
  { id: 'pl2', name: 'Pool Area', slides: 3, duration: '1:30', status: 'active', screen: 'Pool Display' },
  { id: 'pl3', name: 'Restaurant Lunch', slides: 5, duration: '2:30', status: 'scheduled', screen: 'Restaurant TV' },
  { id: 'pl4', name: 'Elevator Display', slides: 2, duration: '0:45', status: 'paused', screen: 'Elevator #1' },
  { id: 'pl5', name: 'Conference Welcome', slides: 3, duration: '1:15', status: 'inactive', screen: 'Conf Room A' },
];

const SCREENS_MOCK = [
  { id: 's1', name: 'Lobby Screen', location: 'Main Lobby', resolution: '1920×1080', status: 'online', playlist: 'Lobby Morning' },
  { id: 's2', name: 'Pool Display', location: 'Pool Area', resolution: '1920×1080', status: 'online', playlist: 'Pool Area' },
  { id: 's3', name: 'Restaurant TV', location: 'Restaurant', resolution: '1920×1080', status: 'offline', playlist: 'Restaurant Lunch' },
  { id: 's4', name: 'Elevator #1', location: 'Elevator Bank A', resolution: '1080×1920', status: 'online', playlist: 'Elevator Display' },
];

// ─── ELEMENT RENDERER ON CANVAS ──────────────────────────────────────────────
function CanvasElement({ el, selected, onSelect, onDragStart, snap, T }) {
  const el_type = ELEMENT_TYPES.find(e => e.id === el.type);
  const color = el_type?.color || T.teal;
  const p = el.props || {};

  const renderContent = () => {
    switch (el.type) {
      case 'text': return (
        <div style={{
          width: '100%', height: '100%', display: 'flex', alignItems: p.valign === 'bottom' ? 'flex-end' : p.valign === 'middle' ? 'center' : 'flex-start',
          justifyContent: p.align === 'center' ? 'center' : p.align === 'right' ? 'flex-end' : 'flex-start', padding: 4, overflow: 'hidden',
          color: p.color || '#ffffff', fontSize: `${p.fontSize || 32}px`, fontFamily: p.fontFamily || 'DM Sans',
          fontWeight: p.fontWeight || '400', fontStyle: p.italic ? 'italic' : 'normal',
          textDecoration: p.underline ? 'underline' : 'none', textAlign: p.align || 'left',
          textShadow: p.shadow ? '2px 2px 4px rgba(0,0,0,0.5)' : 'none',
          lineHeight: p.lineHeight || 1.2,
        }}>
          <span>{p.text || 'Text Block'}</span>
        </div>
      );
      case 'clock': return (
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: p.color || '#fff' }}>
          <div style={{ fontSize: `${p.fontSize || 36}px`, fontFamily: p.fontFamily || 'DM Sans', fontWeight: '700' }}>12:34 PM</div>
          <div style={{ fontSize: `${(p.fontSize || 36) * 0.4}px`, opacity: 0.7 }}>Thursday, February 20</div>
        </div>
      );
      case 'weather': return (
        <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, color: p.color || '#fff' }}>
          <div style={{ fontSize: 36 }}>⛅</div>
          <div>
            <div style={{ fontSize: 28, fontWeight: '700' }}>28°C</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>{p.city || 'Darwin'} · Partly Cloudy</div>
          </div>
        </div>
      );
      case 'livetv': return (
        <div style={{ width: '100%', height: '100%', background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 6 }}>
          <Tv size={32} color='#ffffff66' />
          <div style={{ fontSize: 12, color: '#fff9', fontWeight: 600 }}>Live TV — {p.channel || 'Ch 10'}</div>
        </div>
      );
      case 'image': return (
        <div style={{ width: '100%', height: '100%', background: color + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 6 }}>
          <Image size={28} color={color} />
          <div style={{ fontSize: 11, color, fontWeight: 600 }}>{p.src ? 'Image' : 'Drop Image Here'}</div>
        </div>
      );
      case 'video': return (
        <div style={{ width: '100%', height: '100%', background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 6 }}>
          <Play size={28} color='#ffffff88' />
          <div style={{ fontSize: 11, color: '#fff9', fontWeight: 600 }}>{p.src || 'Video Element'}</div>
        </div>
      );
      case 'rss': return (
        <div style={{ width: '100%', height: '100%', background: p.bg || '#0004', display: 'flex', alignItems: 'center', gap: 10, padding: '0 12px', overflow: 'hidden' }}>
          <Rss size={16} color={p.color || '#f59e0b'} style={{ flexShrink: 0 }} />
          <div style={{ overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis', color: p.color || '#fff', fontSize: `${p.fontSize || 16}px`, fontFamily: p.fontFamily || 'DM Sans' }}>
            Breaking: {p.feed || 'Latest news headlines will scroll here...'}
          </div>
        </div>
      );
      case 'flights': return (
        <div style={{ width: '100%', height: '100%', background: '#0008', padding: 8, overflow: 'hidden' }}>
          <div style={{ fontSize: 11, color: '#aff', fontWeight: 700, marginBottom: 6 }}>✈ DEPARTURES</div>
          {[['QF442','Sydney','10:45','On Time'],['JQ215','Melbourne','11:20','Boarding'],['VA803','Brisbane','12:05','Delayed']].map(([f,d,t,s]) => (
            <div key={f} style={{ display: 'flex', gap: 8, fontSize: 10, color: '#fff', padding: '3px 0', borderBottom: '1px solid #ffffff15' }}>
              <span style={{ color: '#ffd', width: 45 }}>{f}</span>
              <span style={{ flex: 1 }}>{d}</span>
              <span style={{ color: '#aff', width: 36 }}>{t}</span>
              <span style={{ color: s === 'On Time' ? '#4f4' : s === 'Boarding' ? '#ff4' : '#f44', width: 55 }}>{s}</span>
            </div>
          ))}
        </div>
      );
      case 'social': return (
        <div style={{ width: '100%', height: '100%', background: '#1da1f218', padding: 8, overflow: 'hidden' }}>
          <div style={{ fontSize: 11, color: '#1da1f2', fontWeight: 700, marginBottom: 6 }}>🐦 @{p.handle || 'HotelFeed'}</div>
          <div style={{ fontSize: 12, color: '#fff', lineHeight: 1.5 }}>Social feed content will display here in real time. Follow us for updates!</div>
        </div>
      );
      case 'slideshow': return (
        <div style={{ width: '100%', height: '100%', background: color + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 6 }}>
          <Layers size={28} color={color} />
          <div style={{ fontSize: 11, color, fontWeight: 600 }}>Slideshow ({p.slides || 0} slides)</div>
        </div>
      );
      case 'shape': return (
        <div style={{ width: '100%', height: '100%', background: p.fill || color + '66', border: p.border ? `${p.borderWidth || 2}px solid ${p.borderColor || color}` : 'none', borderRadius: p.shape === 'circle' ? '50%' : `${p.radius || 0}px` }} />
      );
      case 'qr': return (
        <div style={{ width: '100%', height: '100%', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 4 }}>
          <Hash size={Math.min(el.w, el.h) * 0.6} color='#000' />
        </div>
      );
      case 'webpage': return (
        <div style={{ width: '100%', height: '100%', background: '#fff1', border: '1px solid #fff2', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 6 }}>
          <Globe size={24} color={color} />
          <div style={{ fontSize: 11, color, fontWeight: 600 }}>{p.url || 'Web Page'}</div>
        </div>
      );
      case 'music': return (
        <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '0 12px', background: '#0006' }}>
          <Music size={16} color='#ec4899' />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: '#fff' }}>{p.title || 'Now Playing: Hotel Lounge Mix'}</div>
          </div>
          <div style={{ display: 'flex', gap: 4 }}>{[3,4,5,3,6,4,2,5,3].map((h,i) => (
            <div key={i} style={{ width: 3, height: h * 3, background: '#ec4899', borderRadius: 2, alignSelf: 'center' }} />
          ))}</div>
        </div>
      );
      default: return <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color, fontSize: 12 }}>{el.type}</div>;
    }
  };

  return (
    <div
      onMouseDown={(e) => { e.stopPropagation(); onSelect(el.id); onDragStart(e, el.id); }}
      style={{
        position: 'absolute', left: el.x, top: el.y, width: el.w, height: el.h,
        border: selected ? `2px solid ${color}` : `1px solid ${color}44`,
        boxShadow: selected ? `0 0 0 1px ${color}44` : 'none',
        cursor: 'move', userSelect: 'none', overflow: 'hidden',
        borderRadius: el.props?.borderRadius || 0,
        opacity: el.props?.opacity !== undefined ? el.props.opacity : 1,
        background: el.type === 'text' || el.type === 'clock' || el.type === 'weather' || el.type === 'rss' ? 'transparent' : undefined,
        zIndex: el.zIndex || 1,
        display: el.hidden ? 'none' : undefined,
      }}
    >
      {renderContent()}
      {selected && (
        <>
          {/* Resize handles */}
          {[['nw',-2,-2,'nwse-resize'],['ne',el.w-6,-2,'nesw-resize'],['se',el.w-6,el.h-6,'nwse-resize'],['sw',-2,el.h-6,'nesw-resize']].map(([pos,rx,ry,cur]) => (
            <div key={pos} onMouseDown={(e) => { e.stopPropagation(); }} style={{ position: 'absolute', left: rx, top: ry, width: 8, height: 8, background: '#fff', border: `1px solid ${color}`, borderRadius: 1, cursor: cur, zIndex: 10 }} />
          ))}
          {/* Top label */}
          <div style={{ position: 'absolute', top: -20, left: 0, background: color, color: '#fff', fontSize: 9, padding: '2px 5px', borderRadius: '3px 3px 0 0', fontWeight: 600, whiteSpace: 'nowrap' }}>
            {el_type?.label || el.type}
          </div>
        </>
      )}
    </div>
  );
}

// ─── PROPERTIES PANEL ────────────────────────────────────────────────────────
function PropertiesPanel({ element, onChange, T }) {
  if (!element) return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: T.textDim, fontSize: 13, textAlign: 'center', padding: 20 }}>
      Select an element to edit its properties
    </div>
  );

  const p = element.props || {};
  const set = (key, val) => onChange({ ...element, props: { ...p, [key]: val } });
  const et = ELEMENT_TYPES.find(e => e.id === element.type);

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 14 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: et?.color || T.teal, textTransform: 'uppercase', letterSpacing: 0.7, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
        {et && <et.icon size={12} />} {et?.label || element.type}
      </div>

      {/* Position & Size */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>Position & Size</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          {[['X', 'x', element.x], ['Y', 'y', element.y], ['W', 'w', element.w], ['H', 'h', element.h]].map(([label, key, val]) => (
            <div key={key}>
              <div style={{ fontSize: 10, color: T.textDim, marginBottom: 3 }}>{label}</div>
              <input type='number' value={Math.round(val)} onChange={e => onChange({ ...element, [key]: parseInt(e.target.value) || 0 })}
                style={{ width: '100%', padding: '6px 8px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit', boxSizing: 'border-box' }} />
            </div>
          ))}
        </div>
      </div>

      {/* Opacity */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6, display: 'flex', justifyContent: 'space-between' }}>
          <span>Opacity</span><span style={{ color: T.teal }}>{Math.round((p.opacity ?? 1) * 100)}%</span>
        </div>
        <input type='range' min='0' max='1' step='0.05' value={p.opacity ?? 1} onChange={e => set('opacity', parseFloat(e.target.value))}
          style={{ width: '100%', accentColor: T.teal }} />
      </div>

      {/* Text properties */}
      {(element.type === 'text' || element.type === 'clock' || element.type === 'rss') && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>Typography</div>
          {element.type === 'text' && (
            <textarea value={p.text || ''} onChange={e => set('text', e.target.value)}
              rows={3} placeholder='Enter text...'
              style={{ width: '100%', marginBottom: 7, padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 6, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit', resize: 'vertical', boxSizing: 'border-box' }} />
          )}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 8 }}>
            <div>
              <div style={{ fontSize: 10, color: T.textDim, marginBottom: 3 }}>Font</div>
              <select value={p.fontFamily || 'DM Sans'} onChange={e => set('fontFamily', e.target.value)}
                style={{ width: '100%', padding: '6px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 11, fontFamily: 'inherit' }}>
                {FONTS.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            <div>
              <div style={{ fontSize: 10, color: T.textDim, marginBottom: 3 }}>Size (px)</div>
              <input type='number' value={p.fontSize || 32} onChange={e => set('fontSize', parseInt(e.target.value))}
                style={{ width: '100%', padding: '6px 8px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit', boxSizing: 'border-box' }} />
            </div>
          </div>
          {/* Font style buttons */}
          <div style={{ display: 'flex', gap: 5, marginBottom: 8 }}>
            {[['700','B',Bold],['400',null,null],['italic','I',Italic],['underline','U',Underline]].filter(x=>x[0]).map(([val,label,Icon]) => (
              Icon && <button key={val} onClick={() => {
                if (val === 'italic') set('italic', !p.italic);
                else if (val === 'underline') set('underline', !p.underline);
                else set('fontWeight', val);
              }} style={{ padding: '5px 9px', borderRadius: 5, border: `1px solid ${T.border}`, background: (val === '700' && p.fontWeight === '700') || (val === 'italic' && p.italic) || (val === 'underline' && p.underline) ? T.teal + '33' : T.inputBg, color: T.textPrimary, cursor: 'pointer', fontFamily: label === 'I' ? 'Georgia' : label === 'B' ? 'inherit' : 'inherit', fontWeight: label === 'B' ? 700 : 400, fontStyle: label === 'I' ? 'italic' : 'normal', textDecoration: label === 'U' ? 'underline' : 'none' }}>
                <Icon size={13} />
              </button>
            ))}
            <div style={{ flex: 1 }} />
            {[['left',AlignLeft],['center',AlignCenter],['right',AlignRight]].map(([align, Icon]) => (
              <button key={align} onClick={() => set('align', align)} style={{ padding: '5px 8px', borderRadius: 5, border: `1px solid ${T.border}`, background: p.align === align ? T.teal + '33' : T.inputBg, color: T.textPrimary, cursor: 'pointer' }}>
                <Icon size={13} />
              </button>
            ))}
          </div>
          {/* Color */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ fontSize: 11, color: T.textSecondary }}>Color</div>
            <input type='color' value={p.color || '#ffffff'} onChange={e => set('color', e.target.value)}
              style={{ width: 32, height: 28, border: `1px solid ${T.border}`, borderRadius: 5, cursor: 'pointer', padding: 2, background: T.inputBg }} />
            <div style={{ fontSize: 11, color: T.textDim }}>{p.color || '#ffffff'}</div>
            <div style={{ flex: 1 }} />
            <label style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: T.textSecondary, cursor: 'pointer' }}>
              <input type='checkbox' checked={!!p.shadow} onChange={e => set('shadow', e.target.checked)} />Shadow
            </label>
          </div>
        </div>
      )}

      {/* Shape properties */}
      {element.type === 'shape' && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>Shape</div>
          <select value={p.shape || 'rect'} onChange={e => set('shape', e.target.value)}
            style={{ width: '100%', marginBottom: 8, padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit' }}>
            {['rect','circle','rounded'].map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
          </select>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: 11, color: T.textSecondary }}>Fill</span>
            <input type='color' value={p.fill?.slice(0,7) || '#3b82f6'} onChange={e => set('fill', e.target.value)}
              style={{ width: 32, height: 28, border: 'none', borderRadius: 4, cursor: 'pointer', padding: 2, background: 'none' }} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: T.textSecondary, cursor: 'pointer' }}>
              <input type='checkbox' checked={!!p.border} onChange={e => set('border', e.target.checked)} /> Border
            </label>
            {p.border && <input type='color' value={p.borderColor || '#ffffff'} onChange={e => set('borderColor', e.target.value)}
              style={{ width: 28, height: 24, border: 'none', borderRadius: 3, cursor: 'pointer', padding: 1, background: 'none' }} />}
          </div>
        </div>
      )}

      {/* Clock properties */}
      {element.type === 'clock' && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>Clock Options</div>
          <select value={p.format || '12h'} onChange={e => set('format', e.target.value)}
            style={{ width: '100%', marginBottom: 8, padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit' }}>
            <option value='12h'>12-hour (12:34 PM)</option>
            <option value='24h'>24-hour (12:34)</option>
          </select>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 11, color: T.textSecondary }}>Color</span>
            <input type='color' value={p.color || '#ffffff'} onChange={e => set('color', e.target.value)}
              style={{ width: 32, height: 28, border: 'none', borderRadius: 4, cursor: 'pointer', background: 'none' }} />
          </div>
        </div>
      )}

      {/* Weather */}
      {element.type === 'weather' && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>Weather</div>
          <input value={p.city || ''} onChange={e => set('city', e.target.value)} placeholder='City name'
            style={{ width: '100%', marginBottom: 7, padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit', boxSizing: 'border-box' }} />
          <select value={p.units || 'celsius'} onChange={e => set('units', e.target.value)}
            style={{ width: '100%', padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit' }}>
            <option value='celsius'>Celsius (°C)</option>
            <option value='fahrenheit'>Fahrenheit (°F)</option>
          </select>
        </div>
      )}

      {/* RSS */}
      {element.type === 'rss' && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>RSS Feed</div>
          <input value={p.feed || ''} onChange={e => set('feed', e.target.value)} placeholder='Feed URL or source'
            style={{ width: '100%', marginBottom: 7, padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit', boxSizing: 'border-box' }} />
          <select value={p.source || 'custom'} onChange={e => set('source', e.target.value)}
            style={{ width: '100%', padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit' }}>
            <option value='custom'>Custom URL</option>
            <option value='abc'>ABC News Australia</option>
            <option value='bbc'>BBC World News</option>
            <option value='reuters'>Reuters</option>
          </select>
        </div>
      )}

      {/* Live TV */}
      {element.type === 'livetv' && (
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>Live TV Channel</div>
          <input value={p.channel || ''} onChange={e => set('channel', e.target.value)} placeholder='e.g. Ch 10, ABC, SBS'
            style={{ width: '100%', padding: '7px', background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textPrimary, fontSize: 12, fontFamily: 'inherit', boxSizing: 'border-box' }} />
        </div>
      )}

      {/* Transition */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 11, color: T.textSecondary, fontWeight: 600, marginBottom: 7, textTransform: 'uppercase', letterSpacing: 0.6 }}>Layer & Visibility</div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={() => onChange({ ...element, zIndex: (element.zIndex || 1) + 1 })} style={{ flex: 1, padding: '6px', fontSize: 11, background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textSecondary, cursor: 'pointer', fontFamily: 'inherit' }}>
            Bring Forward
          </button>
          <button onClick={() => onChange({ ...element, zIndex: Math.max(0, (element.zIndex || 1) - 1) })} style={{ flex: 1, padding: '6px', fontSize: 11, background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: 5, color: T.textSecondary, cursor: 'pointer', fontFamily: 'inherit' }}>
            Send Back
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── SIGNAGE EDITOR ───────────────────────────────────────────────────────────
function SignageEditor({ slide, onSave, onClose, T }) {
  const [elements, setElements] = useState(slide?.elements || []);
  const [selectedId, setSelectedId] = useState(null);
  const [resolution, setResolution] = useState(slide?.resolution || RESOLUTIONS[0]);
  const [snap, setSnap] = useState(true);
  const [zoom, setZoom] = useState(0.45);
  const [bgColor, setBgColor] = useState(slide?.bgColor || '#0a0f1e');
  const [bgImage, setBgImage] = useState(slide?.bgImage || '');
  const [dragging, setDragging] = useState(null);
  const [slideName, setSlideName] = useState(slide?.name || 'New Slide');
  const canvasRef = useRef(null);
  const dragOffset = useRef({ x: 0, y: 0 });
  const SNAP_SIZE = 20;

  const snapVal = (v) => snap ? Math.round(v / SNAP_SIZE) * SNAP_SIZE : v;

  const handleMouseMove = useCallback((e) => {
    if (!dragging || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const rawX = (e.clientX - rect.left) / zoom - dragOffset.current.x;
    const rawY = (e.clientY - rect.top) / zoom - dragOffset.current.y;
    const x = Math.max(0, Math.min(snapVal(rawX), resolution.w - (elements.find(el=>el.id===dragging)?.w||100)));
    const y = Math.max(0, Math.min(snapVal(rawY), resolution.h - (elements.find(el=>el.id===dragging)?.h||100)));
    setElements(prev => prev.map(el => el.id === dragging ? { ...el, x, y } : el));
  }, [dragging, zoom, snap, resolution]);

  const handleMouseUp = useCallback(() => setDragging(null), []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => { window.removeEventListener('mousemove', handleMouseMove); window.removeEventListener('mouseup', handleMouseUp); };
  }, [handleMouseMove, handleMouseUp]);

  const addElement = (type) => {
    const et = ELEMENT_TYPES.find(e => e.id === type);
    const newEl = {
      id: `el_${Date.now()}`, type,
      x: snapVal(Math.floor(Math.random() * (resolution.w - et.defaultW - 100) + 50)),
      y: snapVal(Math.floor(Math.random() * (resolution.h - et.defaultH - 100) + 50)),
      w: et.defaultW, h: et.defaultH, zIndex: elements.length + 1,
      props: type === 'text' ? { text: 'New Text', fontSize: 32, fontFamily: 'DM Sans', color: '#ffffff', align: 'left' } : {}
    };
    setElements([...elements, newEl]);
    setSelectedId(newEl.id);
  };

  const applyTemplate = (tmpl) => {
    setElements(tmpl.elements.map(el => ({ ...el, id: `el_${Date.now()}_${Math.random().toString(36).slice(2)}` })));
    setSelectedId(null);
  };

  const deleteSelected = () => {
    if (!selectedId) return;
    setElements(elements.filter(e => e.id !== selectedId));
    setSelectedId(null);
  };

  const duplicateSelected = () => {
    const el = elements.find(e => e.id === selectedId);
    if (!el) return;
    const copy = { ...el, id: `el_${Date.now()}`, x: el.x + 20, y: el.y + 20 };
    setElements([...elements, copy]);
    setSelectedId(copy.id);
  };

  const selected = elements.find(e => e.id === selectedId);

  const updateElement = (updated) => {
    setElements(elements.map(e => e.id === updated.id ? updated : e));
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: T.bg, zIndex: 300, display: 'flex', flexDirection: 'column', fontFamily: "'DM Sans', sans-serif" }}>
      {/* TOP TOOLBAR */}
      <div style={{ height: 50, background: T.sidebar, borderBottom: `1px solid ${T.border}`, display: 'flex', alignItems: 'center', gap: 8, padding: '0 12px', flexShrink: 0 }}>
        <button onClick={onClose} style={{ background: T.red + '18', border: `1px solid ${T.red}33`, color: T.red, borderRadius: 6, padding: '5px 10px', cursor: 'pointer', fontSize: 12, fontFamily: 'inherit' }}>← Back</button>
        <div style={{ width: 1, height: 24, background: T.border }} />
        <input value={slideName} onChange={e => setSlideName(e.target.value)}
          style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 6, padding: '5px 10px', color: T.textPrimary, fontSize: 13, fontFamily: 'inherit', fontWeight: 600, width: 220 }} />
        <div style={{ width: 1, height: 24, background: T.border }} />
        {/* Resolution */}
        <select value={`${resolution.w}x${resolution.h}`} onChange={e => { const res = RESOLUTIONS.find(r => `${r.w}x${r.h}` === e.target.value); if (res) setResolution(res); }}
          style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 6, padding: '5px 8px', color: T.textPrimary, fontSize: 12, fontFamily: 'inherit' }}>
          {RESOLUTIONS.map(r => <option key={r.label} value={`${r.w}x${r.h}`}>{r.label}</option>)}
        </select>
        {/* Snap toggle */}
        <button onClick={() => setSnap(!snap)} title='Snap to Grid' style={{ padding: '5px 10px', borderRadius: 6, border: `1px solid ${snap ? T.teal : T.border}`, background: snap ? T.tealDim : T.card, color: snap ? T.teal : T.textSecondary, cursor: 'pointer', fontSize: 12, fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 5 }}>
          <Magnet size={13} /> Snap {snap ? 'ON' : 'OFF'}
        </button>
        {/* Zoom */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <button onClick={() => setZoom(z => Math.max(0.1, z - 0.05))} style={{ background: T.card, border: `1px solid ${T.border}`, color: T.textSecondary, borderRadius: 5, padding: '4px 7px', cursor: 'pointer' }}><ZoomOut size={13} /></button>
          <span style={{ fontSize: 12, color: T.textSecondary, minWidth: 42, textAlign: 'center' }}>{Math.round(zoom * 100)}%</span>
          <button onClick={() => setZoom(z => Math.min(1, z + 0.05))} style={{ background: T.card, border: `1px solid ${T.border}`, color: T.textSecondary, borderRadius: 5, padding: '4px 7px', cursor: 'pointer' }}><ZoomIn size={13} /></button>
        </div>
        <div style={{ flex: 1 }} />
        {/* Background */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 11, color: T.textSecondary }}>BG:</span>
          <input type='color' value={bgColor} onChange={e => setBgColor(e.target.value)} style={{ width: 28, height: 26, border: `1px solid ${T.border}`, borderRadius: 4, cursor: 'pointer', padding: 2, background: 'none' }} />
        </div>
        {selectedId && (
          <>
            <button onClick={duplicateSelected} title='Duplicate' style={{ padding: '5px 9px', background: T.card, border: `1px solid ${T.border}`, color: T.textSecondary, borderRadius: 6, cursor: 'pointer' }}><Copy size={13} /></button>
            <button onClick={deleteSelected} title='Delete' style={{ padding: '5px 9px', background: T.red + '18', border: `1px solid ${T.red}33`, color: T.red, borderRadius: 6, cursor: 'pointer' }}><Trash2 size={13} /></button>
          </>
        )}
        <div style={{ width: 1, height: 24, background: T.border }} />
        <button onClick={() => onSave({ ...slide, name: slideName, elements, bgColor, resolution })} style={{ padding: '6px 16px', background: T.teal, border: 'none', borderRadius: 7, color: T.name === 'dark' ? '#07080f' : '#fff', fontWeight: 700, cursor: 'pointer', fontSize: 13, fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 5 }}>
          <Save size={13} /> Save
        </button>
      </div>

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* LEFT: ELEMENT PALETTE */}
        <div style={{ width: 180, background: T.sidebar, borderRight: `1px solid ${T.border}`, display: 'flex', flexDirection: 'column', flexShrink: 0, overflowY: 'auto' }}>
          <div style={{ padding: '10px 12px 6px', fontSize: 10, fontWeight: 700, color: T.textDim, textTransform: 'uppercase', letterSpacing: 0.7 }}>Elements</div>
          <div style={{ padding: '0 8px 10px' }}>
            {ELEMENT_TYPES.map(et => (
              <button key={et.id} onClick={() => addElement(et.id)} style={{
                display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '8px 10px',
                background: T.card, border: `1px solid ${T.cardBorder}`, borderRadius: 7, marginBottom: 4,
                cursor: 'pointer', fontFamily: 'inherit', color: T.textSecondary, fontSize: 12, fontWeight: 500,
                transition: 'all 0.1s',
              }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = et.color; e.currentTarget.style.color = et.color; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = T.cardBorder; e.currentTarget.style.color = T.textSecondary; }}
              >
                <et.icon size={14} color={et.color} />
                {et.label}
              </button>
            ))}
          </div>

          <div style={{ padding: '8px 12px 6px', borderTop: `1px solid ${T.border}`, fontSize: 10, fontWeight: 700, color: T.textDim, textTransform: 'uppercase', letterSpacing: 0.7 }}>Templates</div>
          <div style={{ padding: '0 8px 10px' }}>
            {TEMPLATES.map(t => (
              <button key={t.id} onClick={() => applyTemplate(t)} style={{
                display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '7px 10px',
                background: 'transparent', border: `1px solid ${T.border}`, borderRadius: 7, marginBottom: 3,
                cursor: 'pointer', fontFamily: 'inherit', color: T.textSecondary, fontSize: 11,
              }}>
                <span>{t.thumb}</span>{t.name}
              </button>
            ))}
          </div>
        </div>

        {/* CENTER: CANVAS */}
        <div style={{ flex: 1, overflow: 'auto', background: T.name === 'dark' ? '#050709' : '#e2e8f0', display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-start', padding: 30 }}>
          <div style={{ position: 'relative', transformOrigin: 'top left', transform: `scale(${zoom})`, flexShrink: 0 }}>
            {/* Snap grid (when snap on) */}
            {snap && (
              <div style={{
                position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 0,
                backgroundImage: `linear-gradient(${T.name === 'dark' ? '#ffffff08' : '#00000008'} 1px, transparent 1px), linear-gradient(90deg, ${T.name === 'dark' ? '#ffffff08' : '#00000008'} 1px, transparent 1px)`,
                backgroundSize: `${SNAP_SIZE}px ${SNAP_SIZE}px`,
              }} />
            )}
            {/* Canvas */}
            <div
              ref={canvasRef}
              onClick={() => setSelectedId(null)}
              style={{
                width: resolution.w, height: resolution.h, position: 'relative', overflow: 'hidden',
                background: bgColor, boxShadow: '0 8px 40px rgba(0,0,0,0.4)', cursor: 'default',
                ...(bgImage ? { backgroundImage: `url(${bgImage})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {})
              }}
            >
              {elements.map(el => (
                <CanvasElement key={el.id} el={el} selected={selectedId === el.id} T={T}
                  onSelect={setSelectedId}
                  onDragStart={(e, id) => {
                    const rect = canvasRef.current.getBoundingClientRect();
                    const elData = elements.find(el => el.id === id);
                    dragOffset.current = { x: (e.clientX - rect.left) / zoom - elData.x, y: (e.clientY - rect.top) / zoom - elData.y };
                    setDragging(id);
                  }}
                  snap={snap}
                />
              ))}
            </div>
            {/* Rulers */}
            <div style={{ position: 'absolute', bottom: -20, left: 0, right: 0, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 4px' }}>
              <span style={{ fontSize: 10, color: T.textDim }}>{resolution.w}px</span>
            </div>
            <div style={{ position: 'absolute', right: -24, top: 0, bottom: 0, width: 20, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: 10, color: T.textDim, transform: 'rotate(90deg)' }}>{resolution.h}px</span>
            </div>
          </div>
        </div>

        {/* RIGHT: PROPERTIES */}
        <div style={{ width: 230, background: T.sidebar, borderLeft: `1px solid ${T.border}`, display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
          <div style={{ padding: '10px 12px 6px', fontSize: 10, fontWeight: 700, color: T.textDim, textTransform: 'uppercase', letterSpacing: 0.7, borderBottom: `1px solid ${T.border}` }}>Properties</div>
          <PropertiesPanel element={selected} onChange={updateElement} T={T} />

          {/* Layers panel */}
          <div style={{ borderTop: `1px solid ${T.border}`, padding: '8px 12px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: T.textDim, textTransform: 'uppercase', letterSpacing: 0.7, marginBottom: 6 }}>Layers ({elements.length})</div>
            <div style={{ maxHeight: 140, overflowY: 'auto' }}>
              {[...elements].reverse().map(el => {
                const et = ELEMENT_TYPES.find(e => e.id === el.type);
                return (
                  <div key={el.id} onClick={() => setSelectedId(el.id)} style={{
                    display: 'flex', alignItems: 'center', gap: 6, padding: '4px 6px', borderRadius: 5, marginBottom: 2, cursor: 'pointer',
                    background: selectedId === el.id ? T.tealDim : T.card, border: `1px solid ${selectedId === el.id ? T.teal : T.cardBorder}`
                  }}>
                    {et && <et.icon size={11} color={et.color} />}
                    <span style={{ fontSize: 11, color: T.textPrimary, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {el.props?.text ? el.props.text.slice(0, 20) : el.type}
                    </span>
                    <button onClick={(e) => { e.stopPropagation(); setElements(elements.filter(e => e.id !== el.id)); if (selectedId === el.id) setSelectedId(null); }}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: T.textDim, padding: 0 }}><X size={10} /></button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── ASSETS TAB ──────────────────────────────────────────────────────────────
function AssetsTab({ T }) {
  const [assets, setAssets] = useState(ASSETS_MOCK);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [view, setView] = useState('grid');

  const filtered = assets.filter(a =>
    (filter === 'all' || a.type === filter) &&
    a.name.toLowerCase().includes(search.toLowerCase())
  );

  const typeColor = (t) => ({ image: T.green, video: T.purple, pdf: T.red, pptx: T.amber }[t] || T.blue);

  return (
    <div>
      <SectionHeader title='Asset Library' sub='Manage images, videos, documents and media files' />

      <div style={{ display: 'flex', gap: 8, marginBottom: 18, alignItems: 'center', flexWrap: 'wrap' }}>
        {[['all','All'],['image','Images'],['video','Videos'],['pdf','PDFs'],['pptx','PowerPoint']].map(([k,l]) => (
          <button key={k} onClick={() => setFilter(k)} style={{ padding: '6px 13px', borderRadius: 6, border: `1px solid ${filter === k ? T.teal : T.border}`, background: filter === k ? T.tealDim : 'transparent', color: filter === k ? T.teal : T.textSecondary, cursor: 'pointer', fontSize: 12, fontWeight: 500, fontFamily: 'inherit' }}>{l}</button>
        ))}
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 6, background: T.card, border: `1px solid ${T.border}`, borderRadius: 6, overflow: 'hidden' }}>
          {[['grid', Grid],['list', List]].map(([v, Icon]) => (
            <button key={v} onClick={() => setView(v)} style={{ padding: '6px 10px', background: view === v ? T.tealDim : 'transparent', border: 'none', cursor: 'pointer', color: view === v ? T.teal : T.textSecondary }}><Icon size={14} /></button>
          ))}
        </div>
        <Btn icon={Upload} variant='primary'>Upload Files</Btn>
      </div>

      {/* Upload drop zone */}
      <div style={{ border: `2px dashed ${T.border}`, borderRadius: 10, padding: '20px', textAlign: 'center', marginBottom: 18, background: T.card }}>
        <Upload size={24} color={T.textDim} style={{ margin: '0 auto 8px' }} />
        <div style={{ fontSize: 13, color: T.textSecondary, marginBottom: 4 }}>Drop files here or click to upload</div>
        <div style={{ fontSize: 11, color: T.textDim }}>Supports: JPG, PNG, GIF, SVG, MP4, MOV, AVI, PDF, PPTX, DOCX</div>
      </div>

      {view === 'grid' ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
          {filtered.map(a => (
            <div key={a.id} style={{ background: T.card, border: `1px solid ${T.cardBorder}`, borderRadius: 10, overflow: 'hidden', cursor: 'pointer' }}>
              <div style={{ height: 90, background: T.cardAlt, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40 }}>{a.thumb}</div>
              <div style={{ padding: '8px 10px' }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: T.textPrimary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 4 }}>{a.name}</div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Badge label={a.type.toUpperCase()} color={typeColor(a.type)} />
                  <span style={{ fontSize: 11, color: T.textDim }}>{a.size}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ background: T.card, border: `1px solid ${T.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${T.border}` }}>
                {['Name', 'Type', 'Size', 'Duration', 'Date', ''].map(h => (
                  <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: T.textSecondary, textTransform: 'uppercase', letterSpacing: 0.6 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(a => (
                <tr key={a.id} style={{ borderBottom: `1px solid ${T.border}` }}>
                  <td style={{ padding: '10px 14px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 20 }}>{a.thumb}</span>
                      <span style={{ fontSize: 13, fontWeight: 600, color: T.textPrimary }}>{a.name}</span>
                    </div>
                  </td>
                  <td style={{ padding: '10px 14px' }}><Badge label={a.type.toUpperCase()} color={typeColor(a.type)} /></td>
                  <td style={{ padding: '10px 14px', color: T.textSecondary, fontSize: 13 }}>{a.size}</td>
                  <td style={{ padding: '10px 14px', color: T.textSecondary, fontSize: 13 }}>{a.duration || '—'}</td>
                  <td style={{ padding: '10px 14px', color: T.textDim, fontSize: 12 }}>{a.created}</td>
                  <td style={{ padding: '10px 14px' }}>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <Btn variant='ghost' size='sm' icon={Eye}>Preview</Btn>
                      <Btn variant='ghost' size='sm' icon={Trash2} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── PLAYLISTS TAB ────────────────────────────────────────────────────────────
function PlaylistsTab({ T, onEditSlide }) {
  const [playlists, setPlaylists] = useState(PLAYLISTS_MOCK);
  const [selected, setSelected] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [editingSlide, setEditingSlide] = useState(null);

  const statusColor = (s) => ({ active: T.green, scheduled: T.blue, paused: T.amber, inactive: T.textDim }[s] || T.textDim);

  if (showEditor) {
    return (
      <SignageEditor
        slide={editingSlide}
        T={T}
        onClose={() => { setShowEditor(false); setEditingSlide(null); }}
        onSave={(saved) => {
          console.log('Saved slide:', saved);
          setShowEditor(false);
        }}
      />
    );
  }

  return (
    <div>
      <SectionHeader title='Playlists' sub='Manage slide sequences and scheduling for each screen'
        action={<Btn icon={Plus} variant='primary'>New Playlist</Btn>}
      />

      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 18 }}>
        {/* Playlist list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {playlists.map(pl => (
            <div key={pl.id} onClick={() => setSelected(pl.id)} style={{
              background: selected === pl.id ? T.tealDim : T.card, border: `1px solid ${selected === pl.id ? T.teal : T.cardBorder}`,
              borderRadius: 10, padding: '12px 14px', cursor: 'pointer'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontWeight: 700, fontSize: 14, color: T.textPrimary }}>{pl.name}</span>
                <Badge label={pl.status} color={statusColor(pl.status)} />
              </div>
              <div style={{ fontSize: 12, color: T.textSecondary }}>{pl.screen} · {pl.slides} slides · {pl.duration}</div>
            </div>
          ))}
          <button style={{ padding: '10px', borderRadius: 10, border: `2px dashed ${T.border}`, background: 'transparent', color: T.textDim, cursor: 'pointer', fontSize: 13, fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Plus size={14} /> New Playlist
          </button>
        </div>

        {/* Playlist detail */}
        <div style={{ background: T.card, border: `1px solid ${T.cardBorder}`, borderRadius: 12, padding: 20 }}>
          {!selected ? (
            <div style={{ height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', color: T.textDim, fontSize: 14 }}>
              Select a playlist to manage its slides
            </div>
          ) : (() => {
            const pl = playlists.find(p => p.id === selected);
            return (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
                  <div>
                    <h3 style={{ margin: 0, color: T.textPrimary }}>{pl.name}</h3>
                    <p style={{ margin: '3px 0 0', fontSize: 12, color: T.textSecondary }}>Assigned to: {pl.screen}</p>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <Btn variant='secondary' icon={Calendar} size='sm'>Schedule</Btn>
                    <Btn variant='primary' icon={Play} size='sm'>Preview</Btn>
                  </div>
                </div>

                {/* Slide grid */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 12, marginBottom: 16 }}>
                  {['Welcome Slide', 'Amenities', 'Restaurant', 'Pool Area'].map((name, i) => (
                    <div key={i} style={{ background: T.cardAlt, border: `1px solid ${T.border}`, borderRadius: 8, overflow: 'hidden', cursor: 'pointer' }}
                      onDoubleClick={() => { setEditingSlide({ name, elements: [] }); setShowEditor(true); }}>
                      <div style={{ aspectRatio: '16/9', background: `hsl(${i * 60}, 50%, 15%)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>
                        {['🏨','🏊','🍽️','🌴'][i]}
                      </div>
                      <div style={{ padding: '6px 8px' }}>
                        <div style={{ fontSize: 11, fontWeight: 600, color: T.textPrimary, marginBottom: 2 }}>{name}</div>
                        <div style={{ fontSize: 10, color: T.textDim }}>10s · 1920×1080</div>
                      </div>
                    </div>
                  ))}
                  <button onClick={() => { setEditingSlide(null); setShowEditor(true); }} style={{ aspectRatio: '16/9', borderRadius: 8, border: `2px dashed ${T.border}`, background: 'transparent', cursor: 'pointer', color: T.textDim, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, gridColumn: 'auto' }}>
                    <Plus size={20} />
                    <span style={{ fontSize: 11, fontFamily: 'inherit' }}>Add Slide</span>
                  </button>
                </div>
                <p style={{ fontSize: 12, color: T.textDim, margin: 0 }}>Double-click a slide to open the editor</p>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
}

// ─── SCREENS TAB ─────────────────────────────────────────────────────────────
function ScreensTab({ T }) {
  const statusColor = (s) => ({ online: T.green, offline: T.red }[s] || T.textDim);
  return (
    <div>
      <SectionHeader title='Display Screens' sub='Connected digital signage screens and their status'
        action={<Btn icon={Plus} variant='primary'>Add Screen</Btn>}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 14 }}>
        {SCREENS_MOCK.map(s => (
          <div key={s.id} style={{ background: T.card, border: `1px solid ${T.cardBorder}`, borderRadius: 12, padding: 18 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <div style={{ width: 40, height: 40, borderRadius: 8, background: T.tealDim, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Monitor size={20} color={T.teal} />
              </div>
              <Badge label={s.status} color={statusColor(s.status)} />
            </div>
            <div style={{ fontWeight: 700, color: T.textPrimary, marginBottom: 3 }}>{s.name}</div>
            <div style={{ fontSize: 12, color: T.textSecondary, marginBottom: 8 }}>{s.location} · {s.resolution}</div>
            <div style={{ fontSize: 11, color: T.textDim, padding: '6px 10px', background: T.cardAlt, borderRadius: 6 }}>
              📋 {s.playlist}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── SCHEDULE TAB ────────────────────────────────────────────────────────────
function ScheduleTab({ T }) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const events = [
    { day: 0, start: 7, end: 12, name: 'Morning Welcome', color: T.blue },
    { day: 0, start: 12, end: 14, name: 'Lunch Promo', color: T.amber },
    { day: 0, start: 18, end: 22, name: 'Dinner Menu', color: T.purple },
    { day: 1, start: 9, end: 17, name: 'Pool Area', color: T.green },
    { day: 2, start: 7, end: 12, name: 'Morning Welcome', color: T.blue },
    { day: 5, start: 11, end: 23, name: 'Weekend Brunch', color: T.teal },
    { day: 6, start: 10, end: 23, name: 'Weekend Promo', color: T.teal },
  ];

  return (
    <div>
      <SectionHeader title='Schedule' sub='Plan when each playlist displays on each screen'
        action={<div style={{ display: 'flex', gap: 8 }}>
          <Btn variant='secondary' size='sm' icon={ChevronDown}>This Week</Btn>
          <Btn variant='primary' icon={Plus}>Add Schedule</Btn>
        </div>}
      />
      <div style={{ background: T.card, border: `1px solid ${T.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '48px repeat(7, 1fr)' }}>
          <div style={{ background: T.cardAlt, padding: '10px 6px', borderBottom: `1px solid ${T.border}` }} />
          {days.map(d => (
            <div key={d} style={{ background: T.cardAlt, padding: '10px 8px', textAlign: 'center', fontSize: 12, fontWeight: 600, color: T.textSecondary, borderBottom: `1px solid ${T.border}`, borderLeft: `1px solid ${T.border}` }}>{d}</div>
          ))}
          {hours.map(h => (
            <>
              <div key={`h${h}`} style={{ padding: '0 6px', borderBottom: `1px solid ${T.border}`, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', height: 36 }}>
                <span style={{ fontSize: 10, color: T.textDim }}>{h}:00</span>
              </div>
              {days.map((d, di) => {
                const event = events.find(e => e.day === di && e.start === h);
                return (
                  <div key={`${h}-${di}`} style={{ borderBottom: `1px solid ${T.border}`, borderLeft: `1px solid ${T.border}`, height: 36, position: 'relative', background: events.some(e => e.day === di && h >= e.start && h < e.end) ? (events.find(e => e.day === di && h >= e.start && h < e.end)?.color + '15') : 'transparent' }}>
                    {event && (
                      <div style={{ position: 'absolute', top: 2, left: 2, right: 2, background: event.color, borderRadius: 4, padding: '2px 5px', fontSize: 9, fontWeight: 600, color: '#fff', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', zIndex: 2 }}>{event.name}</div>
                    )}
                  </div>
                );
              })}
            </>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── MAIN DIGITAL SIGNAGE VIEW ────────────────────────────────────────────────
export default function SignageView() {
  const { theme: T } = useTheme();
  const [tab, setTab] = useState('playlists');

  return (
    <div>
      <div style={{ display: 'flex', gap: 2, marginBottom: 22, background: T.card, padding: 4, borderRadius: 10, width: 'fit-content', border: `1px solid ${T.border}` }}>
        {[['playlists', Layers, 'Playlists'], ['assets', Image, 'Assets'], ['screens', Monitor, 'Screens'], ['schedule', Calendar, 'Schedule']].map(([k, Icon, label]) => (
          <button key={k} onClick={() => setTab(k)} style={{
            display: 'flex', alignItems: 'center', gap: 6, padding: '7px 16px', borderRadius: 7,
            background: tab === k ? T.teal : 'transparent', color: tab === k ? (T.name === 'dark' ? '#07080f' : '#fff') : T.textSecondary,
            border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 13, fontFamily: "'DM Sans', sans-serif"
          }}><Icon size={13} />{label}</button>
        ))}
      </div>

      {tab === 'playlists' && <PlaylistsTab T={T} />}
      {tab === 'assets' && <AssetsTab T={T} />}
      {tab === 'screens' && <ScreensTab T={T} />}
      {tab === 'schedule' && <ScheduleTab T={T} />}
    </div>
  );
}
