import { useState, useEffect, useCallback } from 'react';
import { useTheme } from '../context/ThemeContext.jsx';
import { api } from '../api/client.js';
import CanvasEditor from '../components/CanvasEditor.jsx';
import {
  Monitor, Plus, Play, Trash2, Edit, Clock, Calendar,
  Upload, Film, Image, FileText, Search,
  Wifi, WifiOff, ChevronRight, Layers,
  BarChart2, Archive, Zap, RefreshCw,
} from 'lucide-react';

// ── Shared mini-components ────────────────────────────────────────────────────
function Btn({ children, variant = 'primary', size = 'md', onClick, icon: Icon, disabled, style: s = {} }) {
  const { C, isDark } = useTheme();
  const v = {
    primary:   { background: C.teal,      color: isDark ? '#07080f' : '#fff', border: 'none' },
    secondary: { background: C.card,      color: C.textPrimary,               border: `1px solid ${C.border}` },
    danger:    { background: C.red+'18',  color: C.red,                        border: `1px solid ${C.red}33` },
    ghost:     { background: 'transparent', color: C.textSecondary,            border: `1px solid transparent` },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, borderRadius: 8,
      fontWeight: 600, fontFamily: "'DM Sans', sans-serif", cursor: disabled ? 'not-allowed' : 'pointer',
      fontSize: size === 'sm' ? 12 : 14, padding: size === 'sm' ? '5px 11px' : '9px 16px',
      opacity: disabled ? 0.6 : 1, transition: 'opacity 0.15s', ...v[variant], ...s,
    }}>
      {Icon && <Icon size={size === 'sm' ? 13 : 15} />}{children}
    </button>
  );
}

function Badge({ label, color }) {
  return <span style={{ background: color+'22', color, border: `1px solid ${color}33`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600, whiteSpace: 'nowrap' }}>{label}</span>;
}

function Modal({ title, onClose, children, width = 480 }) {
  const { C } = useTheme();
  return (
    <div style={{ position: 'fixed', inset: 0, background: '#00000066', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
      onClick={e => e.target === e.currentTarget && onClose?.()}>
      <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: 28, width: '100%', maxWidth: width, maxHeight: '90vh', overflowY: 'auto', boxShadow: C.shadowLg }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 }}>
          <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: C.textPrimary }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: C.textSecondary, lineHeight: 1 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  const { C } = useTheme();
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 12, color: C.textSecondary, display: 'block', marginBottom: 5, fontWeight: 500 }}>{label}</label>
      {children}
    </div>
  );
}

function CInput({ style: s = {}, ...props }) {
  const { C } = useTheme();
  return <input {...props} style={{ width: '100%', padding: '9px 11px', background: C.input, border: `1px solid ${C.inputBorder}`, borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans',sans-serif", boxSizing: 'border-box', outline: 'none', ...s }} />;
}

function CSelect({ children, style: s = {}, ...props }) {
  const { C } = useTheme();
  return <select {...props} style={{ width: '100%', padding: '9px 11px', background: C.input, border: `1px solid ${C.inputBorder}`, borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans',sans-serif", boxSizing: 'border-box', ...s }}>{children}</select>;
}

// ── Helpers ────────────────────────────────────────────────────────────────────
const ASSET_ICON = { video: '🎥', image: '🖼', document: '📄', presentation: '📊', text: '📝' };
const ASSET_CAT  = { video: 'videos', image: 'images', document: 'documents', presentation: 'documents', text: 'text' };
const ALL_DAYS   = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

const EMPTY_SCREEN   = { name: '', location: '', resolution: '1920x1080', ip: '' };
const EMPTY_SCHEDULE = { screen_id: '', playlist_id: '', start_time: '06:00', end_time: '18:00', days_of_week: 'Mon,Tue,Wed,Thu,Fri,Sat,Sun' };

// ─────────────────────────────────────────────────────────────────────────────
export default function SignageModule({ hotelId }) {
  const { C, isDark } = useTheme();
  const [tab, setTab]           = useState('assets');
  const [assetFilter, setAF]   = useState('all');
  const [searchQ, setSearchQ]  = useState('');
  const [showEditor, setShowEditor] = useState(false);
  const [editingPlaylist, setEditingPlaylist] = useState(null);

  // Data
  const [assets,    setAssets]    = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [screens,   setScreens]   = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [busy, setBusy] = useState({});

  // Modals
  const [newPL,    setNewPL]    = useState(false);
  const [plName,   setPlName]   = useState('');
  const [newSC,    setNewSC]    = useState(false);
  const [scForm,   setScForm]   = useState(EMPTY_SCREEN);
  const [editSC,   setEditSC]   = useState(null);
  const [newSched, setNewSched] = useState(false);
  const [schedForm,setSchedF]  = useState(EMPTY_SCHEDULE);

  // ── Loaders ────────────────────────────────────────────────────────────────
  const loadAll = useCallback(() => {
    setBusy(b => ({ ...b, assets: true, playlists: true, screens: true, schedules: true }));
    api.hotels.signageAssets(hotelId).then(setAssets).catch(()=>{}).finally(()=>setBusy(b=>({...b,assets:false})));
    api.hotels.signagePlaylists(hotelId).then(setPlaylists).catch(()=>{}).finally(()=>setBusy(b=>({...b,playlists:false})));
    api.hotels.signageScreens(hotelId).then(setScreens).catch(()=>{}).finally(()=>setBusy(b=>({...b,screens:false})));
    api.hotels.signageSchedules(hotelId).then(setSchedules).catch(()=>{}).finally(()=>setBusy(b=>({...b,schedules:false})));
  }, [hotelId]);

  useEffect(() => { loadAll(); }, [loadAll]);

  // ── Actions ────────────────────────────────────────────────────────────────
  const deleteAsset = async (id) => {
    if (!confirm('Delete this asset?')) return;
    await api.hotels.deleteSignageAsset(hotelId, id);
    setAssets(a => a.filter(x => x.id !== id));
  };

  const createPlaylist = async () => {
    if (!plName.trim()) return;
    const pl = await api.hotels.createSignagePlaylist(hotelId, { name: plName.trim(), items: [] });
    setNewPL(false); setPlName('');
    api.hotels.signagePlaylists(hotelId).then(setPlaylists).catch(()=>{});
  };

  const deletePlaylist = async (id) => {
    if (!confirm('Delete this playlist and all its slides?')) return;
    await api.hotels.deleteSignagePlaylist(hotelId, id);
    setPlaylists(p => p.filter(x => x.id !== id));
  };

  const createScreen = async () => {
    if (!scForm.name.trim()) return;
    await api.hotels.createSignageScreen(hotelId, scForm);
    setNewSC(false); setScForm(EMPTY_SCREEN);
    api.hotels.signageScreens(hotelId).then(setScreens).catch(()=>{});
  };

  const updateScreen = async () => {
    await api.hotels.updateSignageScreen(hotelId, editSC.id, editSC);
    setEditSC(null);
    api.hotels.signageScreens(hotelId).then(setScreens).catch(()=>{});
  };

  const deleteScreen = async (id) => {
    if (!confirm('Remove this screen?')) return;
    await api.hotels.deleteSignageScreen(hotelId, id);
    setScreens(s => s.filter(x => x.id !== id));
  };

  const createSchedule = async () => {
    if (!schedForm.screen_id || !schedForm.playlist_id) return;
    await api.hotels.createSignageSchedule(hotelId, schedForm);
    setNewSched(false); setSchedF(EMPTY_SCHEDULE);
    api.hotels.signageSchedules(hotelId).then(setSchedules).catch(()=>{});
  };

  const toggleSchedule = async (sc) => {
    await api.hotels.updateSignageSchedule(hotelId, sc.id, { ...sc, active: sc.active ? 0 : 1 });
    api.hotels.signageSchedules(hotelId).then(setSchedules).catch(()=>{});
  };

  const deleteSchedule = async (id) => {
    if (!confirm('Delete this schedule?')) return;
    await api.hotels.deleteSignageSchedule(hotelId, id);
    setSchedules(s => s.filter(x => x.id !== id));
  };

  const toggleDay = (day) => {
    const days = schedForm.days_of_week ? schedForm.days_of_week.split(',').filter(Boolean) : [];
    const next = days.includes(day) ? days.filter(d => d !== day) : [...days, day];
    setSchedF(s => ({ ...s, days_of_week: next.join(',') }));
  };

  // ── Canvas editor ──────────────────────────────────────────────────────────
  if (showEditor) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 54px)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 16px', background: '#0d1117', borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
          <button onClick={() => setShowEditor(false)} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, padding: '6px 12px', color: C.textSecondary, cursor: 'pointer', fontSize: 12, fontFamily: "'DM Sans',sans-serif", display: 'flex', alignItems: 'center', gap: 5 }}>
            <ChevronRight size={13} style={{ transform: 'rotate(180deg)' }} /> Back
          </button>
          <span style={{ fontSize: 13, color: '#f1f5f9', fontWeight: 600 }}>{editingPlaylist?.name || 'New Slide'} — Slide Editor</span>
          <span style={{ fontSize: 11, color: '#8899b4' }}>1920×1080</span>
        </div>
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <CanvasEditor mode="signage" onSave={() => setShowEditor(false)} onSaveTemplate={() => alert('Template saved!')} />
        </div>
      </div>
    );
  }

  // ── Derived ────────────────────────────────────────────────────────────────
  const onlineCount = screens.filter(s => s.status === 'online').length;
  const activePL    = playlists.filter(p => p.active !== 0).length;
  const filteredAssets = assets.filter(a => {
    const matchCat = assetFilter === 'all' || ASSET_CAT[a.type] === assetFilter;
    const matchQ   = !searchQ || a.name.toLowerCase().includes(searchQ.toLowerCase());
    return matchCat && matchQ;
  });

  const TABS = [
    ['assets','Asset Library',Archive],
    ['playlists','Playlists',Layers],
    ['schedules','Schedules',Calendar],
    ['screens','Screens',Monitor],
    ['analytics','Analytics',BarChart2],
  ];

  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif", color: C.textPrimary }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Digital Signage</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>
            {onlineCount}/{screens.length} screens online · {activePL} active playlists
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn icon={RefreshCw} variant="secondary" onClick={loadAll}>Refresh</Btn>
          <Btn icon={Plus} onClick={() => { setEditingPlaylist(null); setShowEditor(true); }}>New Slide</Btn>
        </div>
      </div>

      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        {[
          [Monitor, `${onlineCount}/${screens.length}`, 'Screens Online', C.green],
          [Layers,  String(playlists.length),           'Total Playlists', C.teal],
          [Film,    String(assets.filter(a=>a.type==='video').length), 'Video Assets', C.blue],
          [Image,   String(assets.filter(a=>a.type==='image').length), 'Image Assets', C.purple],
        ].map(([Icon, val, lbl, color]) => (
          <div key={lbl} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 38, height: 38, borderRadius: 9, background: color+'18', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon size={18} color={color} />
            </div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, color: C.textPrimary, lineHeight: 1 }}>{val}</div>
              <div style={{ fontSize: 11, color: C.textSecondary, marginTop: 2 }}>{lbl}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 2, marginBottom: 20, background: C.card, padding: 4, borderRadius: 10, width: 'fit-content', border: `1px solid ${C.border}` }}>
        {TABS.map(([k, label, Icon]) => (
          <button key={k} onClick={() => setTab(k)} style={{
            display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', borderRadius: 7,
            background: tab === k ? C.teal : 'transparent',
            color: tab === k ? (isDark ? '#07080f' : '#fff') : C.textSecondary,
            border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 13, fontFamily: "'DM Sans',sans-serif",
          }}>
            <Icon size={13} />{label}
          </button>
        ))}
      </div>

      {/* ═══ ASSETS ═══════════════════════════════════════════════════════════ */}
      {tab === 'assets' && (
        <div>
          <div style={{ display: 'flex', gap: 8, marginBottom: 16, alignItems: 'center', flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: C.input, border: `1px solid ${C.border}`, borderRadius: 8, padding: '7px 11px', minWidth: 200 }}>
              <Search size={13} color={C.textDim} />
              <input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="Search assets..." style={{ background: 'none', border: 'none', color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans',sans-serif", outline: 'none', width: '100%' }} />
            </div>
            {[['all','All'],['videos','Videos'],['images','Images'],['documents','Documents']].map(([k,l]) => (
              <button key={k} onClick={() => setAF(k)} style={{ padding: '6px 12px', borderRadius: 6, border: `1px solid ${assetFilter===k?C.teal:C.border}`, background: assetFilter===k?C.tealDim:'transparent', color: assetFilter===k?C.teal:C.textSecondary, cursor: 'pointer', fontSize: 12, fontFamily: "'DM Sans',sans-serif" }}>{l}</button>
            ))}
          </div>

          <div style={{ background: C.card, border: `2px dashed ${C.border}`, borderRadius: 12, padding: 20, textAlign: 'center', marginBottom: 16, cursor: 'pointer' }}>
            <Upload size={24} color={C.textDim} style={{ marginBottom: 8 }} />
            <p style={{ margin: 0, fontSize: 14, color: C.textSecondary }}>Drag & drop files here, or click to browse</p>
            <p style={{ margin: '6px 0 0', fontSize: 11, color: C.textDim }}>Supports MP4, MOV, JPG, PNG, PDF, PPTX, SVG · Max 500MB per file</p>
          </div>

          {busy.assets ? (
            <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading assets...</div>
          ) : filteredAssets.length === 0 ? (
            <div style={{ textAlign: 'center', color: C.textDim, padding: 40, fontSize: 14 }}>
              {assets.length === 0 ? 'No assets uploaded yet.' : 'No assets match the current filter.'}
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', gap: 12 }}>
              {filteredAssets.map(a => (
                <div key={a.id} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, overflow: 'hidden', cursor: 'pointer', transition: 'border-color 0.15s' }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = C.teal}
                  onMouseLeave={e => e.currentTarget.style.borderColor = C.cardBorder}>
                  <div style={{ height: 110, background: isDark ? '#0e1623' : '#e8eef5', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 44, position: 'relative' }}>
                    {ASSET_ICON[a.type] || '📁'}
                    <button onClick={(e) => { e.stopPropagation(); deleteAsset(a.id); }} title="Delete" style={{ position: 'absolute', top: 6, right: 6, background: C.red+'22', border: 'none', borderRadius: 4, padding: '3px 5px', cursor: 'pointer', color: C.red }}>
                      <Trash2 size={11} />
                    </button>
                  </div>
                  <div style={{ padding: '10px 12px' }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: C.textPrimary, marginBottom: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 10, color: C.textDim }}>{a.size || '—'}</span>
                      <Badge label={a.type} color={C.blue} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ═══ PLAYLISTS ════════════════════════════════════════════════════════ */}
      {tab === 'playlists' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <span style={{ fontSize: 14, color: C.textSecondary }}>{playlists.length} playlist{playlists.length !== 1 ? 's' : ''}</span>
            <Btn icon={Plus} size="sm" onClick={() => setNewPL(true)}>New Playlist</Btn>
          </div>

          {busy.playlists ? (
            <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div>
          ) : playlists.length === 0 ? (
            <div style={{ textAlign: 'center', color: C.textDim, padding: 40, fontSize: 14 }}>No playlists yet — create one to get started.</div>
          ) : (
            <div style={{ display: 'grid', gap: 10 }}>
              {playlists.map(pl => {
                const isActive = pl.active !== 0;
                const items = pl.items?.length || 0;
                return (
                  <div key={pl.id} style={{ background: C.card, border: `1px solid ${isActive ? C.teal+'44' : C.cardBorder}`, borderRadius: 10, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ width: 44, height: 44, borderRadius: 8, background: isActive ? C.tealDim : C.panel, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Layers size={20} color={isActive ? C.teal : C.textDim} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                        <span style={{ fontWeight: 700, fontSize: 15, color: C.textPrimary }}>{pl.name}</span>
                        <Badge label={isActive ? 'Active' : 'Inactive'} color={isActive ? C.green : C.textDim} />
                      </div>
                      <div style={{ fontSize: 12, color: C.textSecondary }}>
                        {items} item{items !== 1 ? 's' : ''} · Created {pl.created_at ? new Date(pl.created_at).toLocaleDateString() : '—'}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <Btn variant="secondary" size="sm" icon={Edit} onClick={() => { setEditingPlaylist(pl); setShowEditor(true); }}>Edit Slides</Btn>
                      <button onClick={() => deletePlaylist(pl.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.textDim, padding: 4 }} title="Delete">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ═══ SCHEDULES ════════════════════════════════════════════════════════ */}
      {tab === 'schedules' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <span style={{ fontSize: 14, color: C.textSecondary }}>Time-based content scheduling</span>
            <Btn icon={Plus} size="sm" onClick={() => setNewSched(true)}>Add Schedule</Btn>
          </div>

          {busy.schedules ? (
            <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div>
          ) : schedules.length === 0 ? (
            <div style={{ textAlign: 'center', color: C.textDim, padding: 40, fontSize: 14 }}>No schedules yet. Add one to automate your signage.</div>
          ) : (
            <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: C.tableHeader, borderBottom: `1px solid ${C.border}` }}>
                    {['Screen','Playlist','Days','Time Slot','Status','Actions'].map(h => (
                      <th key={h} style={{ padding: '11px 14px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: 0.6 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {schedules.map((sc, i) => {
                    const screen   = screens.find(s => s.id === sc.screen_id);
                    const playlist = playlists.find(p => p.id === sc.playlist_id);
                    const isActive = sc.active !== 0;
                    return (
                      <tr key={sc.id} style={{ background: i % 2 === 0 ? C.tableRow : C.tableRowAlt, borderBottom: `1px solid ${C.border}` }}>
                        <td style={{ padding: '11px 14px', fontWeight: 600, color: C.textPrimary, fontSize: 13 }}>{screen?.name || `Screen #${sc.screen_id}`}</td>
                        <td style={{ padding: '11px 14px', color: C.textSecondary, fontSize: 13 }}>{playlist?.name || `Playlist #${sc.playlist_id}`}</td>
                        <td style={{ padding: '11px 14px', color: C.textSecondary, fontSize: 12 }}>{(sc.days_of_week || '').replace(/,/g, ' · ')}</td>
                        <td style={{ padding: '11px 14px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, fontWeight: 600, color: C.teal }}>
                            <Clock size={12} />{sc.start_time} – {sc.end_time}
                          </div>
                        </td>
                        <td style={{ padding: '11px 14px' }}><Badge label={isActive ? 'Active' : 'Paused'} color={isActive ? C.green : C.textDim} /></td>
                        <td style={{ padding: '11px 14px' }}>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <Btn variant="ghost" size="sm" onClick={() => toggleSchedule(sc)}>{isActive ? 'Pause' : 'Enable'}</Btn>
                            <Btn variant="danger" size="sm" icon={Trash2} onClick={() => deleteSchedule(sc.id)}>Del</Btn>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ═══ SCREENS ══════════════════════════════════════════════════════════ */}
      {tab === 'screens' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <span style={{ fontSize: 14, color: C.textSecondary }}>{screens.length} registered screen{screens.length !== 1 ? 's' : ''}</span>
            <Btn icon={Plus} size="sm" onClick={() => setNewSC(true)}>Register Screen</Btn>
          </div>

          {busy.screens ? (
            <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div>
          ) : screens.length === 0 ? (
            <div style={{ textAlign: 'center', color: C.textDim, padding: 40, fontSize: 14 }}>No screens registered yet. Register your first display to get started.</div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 12 }}>
              {screens.map(sc => (
                <div key={sc.id} style={{ background: C.card, border: `1px solid ${sc.status === 'online' ? C.teal+'33' : C.red+'22'}`, borderRadius: 12, padding: 16 }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 15, color: C.textPrimary }}>{sc.name}</div>
                      <div style={{ fontSize: 12, color: C.textSecondary }}>{sc.location || '—'}</div>
                    </div>
                    {sc.status === 'online'
                      ? <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: C.green, fontWeight: 600 }}><Wifi size={12}/>Online</div>
                      : <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: C.textDim, fontWeight: 600 }}><WifiOff size={12}/>Offline</div>
                    }
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 12 }}>
                    {[['Resolution', sc.resolution || '—'],['IP Address', sc.ip || '—']].map(([k,v]) => (
                      <div key={k}>
                        <div style={{ fontSize: 10, color: C.textDim, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 2 }}>{k}</div>
                        <div style={{ fontSize: 12, color: C.textPrimary, fontWeight: 500 }}>{v}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <Btn variant="secondary" size="sm" icon={Edit} style={{ flex: 1, justifyContent: 'center' }} onClick={() => setEditSC({ ...sc })}>Edit</Btn>
                    <Btn variant="danger" size="sm" icon={Trash2} onClick={() => deleteScreen(sc.id)}>Remove</Btn>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ═══ ANALYTICS ════════════════════════════════════════════════════════ */}
      {tab === 'analytics' && (
        <div style={{ display: 'grid', gap: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
            {[
              ['Screens Online', `${onlineCount}/${screens.length}`, C.green, Monitor],
              ['Active Playlists', String(activePL), C.teal, Layers],
              ['Total Assets', String(assets.length), C.blue, Archive],
            ].map(([l,v,c,Icon]) => (
              <div key={l} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: '18px 20px', display: 'flex', gap: 14 }}>
                <div style={{ width: 44, height: 44, borderRadius: 10, background: c+'18', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon size={20} color={c} />
                </div>
                <div>
                  <div style={{ fontSize: 26, fontWeight: 700, color: C.textPrimary, lineHeight: 1 }}>{v}</div>
                  <div style={{ fontSize: 11, color: C.textSecondary, marginTop: 4 }}>{l}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ background: C.tealDim, border: `1px solid ${C.tealMid}`, borderRadius: 12, padding: 20, display: 'flex', alignItems: 'center', gap: 14 }}>
            <Zap size={24} color={C.teal} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: C.teal }}>Full Analytics Coming Soon</div>
              <div style={{ fontSize: 13, color: C.textSecondary }}>Impression tracking, content performance, and screen uptime analytics are planned for a future release.</div>
            </div>
          </div>
        </div>
      )}

      {/* ═══ MODALS ═══════════════════════════════════════════════════════════ */}

      {newPL && (
        <Modal title="New Playlist" onClose={() => setNewPL(false)}>
          <Field label="Playlist Name">
            <CInput value={plName} onChange={e => setPlName(e.target.value)} placeholder="e.g. Morning Welcome" autoFocus />
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setNewPL(false)}>Cancel</Btn>
            <Btn size="sm" onClick={createPlaylist} disabled={!plName.trim()}>Create Playlist</Btn>
          </div>
        </Modal>
      )}

      {newSC && (
        <Modal title="Register Screen" onClose={() => setNewSC(false)}>
          <Field label="Screen Name"><CInput value={scForm.name} onChange={e => setScForm(s=>({...s,name:e.target.value}))} placeholder="e.g. Lobby Main" /></Field>
          <Field label="Location"><CInput value={scForm.location} onChange={e => setScForm(s=>({...s,location:e.target.value}))} placeholder="e.g. Main Entrance" /></Field>
          <Field label="Resolution">
            <CSelect value={scForm.resolution} onChange={e => setScForm(s=>({...s,resolution:e.target.value}))}>
              <option value="1920x1080">1080p — 1920×1080</option>
              <option value="3840x2160">4K — 3840×2160</option>
              <option value="1280x720">720p — 1280×720</option>
              <option value="1080x1920">Portrait — 1080×1920</option>
            </CSelect>
          </Field>
          <Field label="IP Address (optional)"><CInput value={scForm.ip} onChange={e => setScForm(s=>({...s,ip:e.target.value}))} placeholder="192.168.1.x" /></Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setNewSC(false)}>Cancel</Btn>
            <Btn size="sm" onClick={createScreen} disabled={!scForm.name.trim()}>Register</Btn>
          </div>
        </Modal>
      )}

      {editSC && (
        <Modal title={`Edit — ${editSC.name}`} onClose={() => setEditSC(null)}>
          <Field label="Screen Name"><CInput value={editSC.name} onChange={e => setEditSC(s=>({...s,name:e.target.value}))} /></Field>
          <Field label="Location"><CInput value={editSC.location||''} onChange={e => setEditSC(s=>({...s,location:e.target.value}))} /></Field>
          <Field label="Resolution">
            <CSelect value={editSC.resolution} onChange={e => setEditSC(s=>({...s,resolution:e.target.value}))}>
              <option value="1920x1080">1080p — 1920×1080</option>
              <option value="3840x2160">4K — 3840×2160</option>
              <option value="1280x720">720p — 1280×720</option>
              <option value="1080x1920">Portrait — 1080×1920</option>
            </CSelect>
          </Field>
          <Field label="IP Address"><CInput value={editSC.ip||''} onChange={e => setEditSC(s=>({...s,ip:e.target.value}))} placeholder="192.168.1.x" /></Field>
          <Field label="Status">
            <CSelect value={editSC.status||'offline'} onChange={e => setEditSC(s=>({...s,status:e.target.value}))}>
              <option value="online">Online</option>
              <option value="offline">Offline</option>
              <option value="fault">Fault</option>
            </CSelect>
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setEditSC(null)}>Cancel</Btn>
            <Btn size="sm" onClick={updateScreen}>Save Changes</Btn>
          </div>
        </Modal>
      )}

      {newSched && (
        <Modal title="Add Schedule" onClose={() => setNewSched(false)}>
          <Field label="Screen">
            <CSelect value={schedForm.screen_id} onChange={e => setSchedF(s=>({...s,screen_id:e.target.value}))}>
              <option value="">— Select screen —</option>
              {screens.map(sc => <option key={sc.id} value={sc.id}>{sc.name}</option>)}
            </CSelect>
          </Field>
          <Field label="Playlist">
            <CSelect value={schedForm.playlist_id} onChange={e => setSchedF(s=>({...s,playlist_id:e.target.value}))}>
              <option value="">— Select playlist —</option>
              {playlists.map(pl => <option key={pl.id} value={pl.id}>{pl.name}</option>)}
            </CSelect>
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Start Time"><CInput type="time" value={schedForm.start_time} onChange={e => setSchedF(s=>({...s,start_time:e.target.value}))} /></Field>
            <Field label="End Time"><CInput type="time" value={schedForm.end_time} onChange={e => setSchedF(s=>({...s,end_time:e.target.value}))} /></Field>
          </div>
          <Field label="Days of Week">
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {ALL_DAYS.map(day => {
                const on = (schedForm.days_of_week||'').split(',').includes(day);
                return (
                  <button key={day} onClick={() => toggleDay(day)} style={{ padding: '5px 10px', borderRadius: 6, border: `1px solid ${on?C.teal:C.border}`, background: on?C.tealDim:'transparent', color: on?C.teal:C.textSecondary, cursor: 'pointer', fontSize: 12, fontFamily: "'DM Sans',sans-serif", fontWeight: 600 }}>{day}</button>
                );
              })}
            </div>
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setNewSched(false)}>Cancel</Btn>
            <Btn size="sm" onClick={createSchedule} disabled={!schedForm.screen_id || !schedForm.playlist_id}>Add Schedule</Btn>
          </div>
        </Modal>
      )}

    </div>
  );
}
