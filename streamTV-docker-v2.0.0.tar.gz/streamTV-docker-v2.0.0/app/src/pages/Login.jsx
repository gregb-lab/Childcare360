import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { Tv, Mail, Lock, AlertCircle, Chrome, Apple } from 'lucide-react';

export default function LoginPage() {
  const { C } = useTheme();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password);
    } catch (err) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const demoAccounts = [
    { label: 'Streamvision Admin', email: 'admin@streamvision.com.au', pw: 'StreamTV2026!', color: C.teal },
    { label: 'Group Admin (Hilton)', email: 'portfolio@hilton.com', pw: 'Hilton2026!', color: '#a855f7' },
    { label: 'Hotel Admin (Darwin)', email: 'manager@hgidarwin.com.au', pw: 'HotelDemo2026!', color: '#3b82f6' },
  ];

  return (
    <div style={{
      minHeight: '100vh', background: C.bg, display: 'flex', alignItems: 'center',
      justifyContent: 'center', padding: 20, position: 'relative', overflow: 'hidden'
    }}>
      {/* Background glow */}
      <div style={{
        position: 'fixed', top: '-20%', left: '50%', transform: 'translateX(-50%)',
        width: '60vw', height: '50vh',
        background: 'radial-gradient(ellipse, #00d4aa14 0%, transparent 70%)',
        pointerEvents: 'none'
      }} />
      <div style={{
        position: 'fixed', bottom: '-10%', right: '-10%',
        width: '40vw', height: '40vh',
        background: 'radial-gradient(ellipse, #3b82f610 0%, transparent 70%)',
        pointerEvents: 'none'
      }} />

      <div style={{ width: '100%', maxWidth: 420, position: 'relative' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 14, background: C.teal,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 14px',
            boxShadow: '0 0 32px #00d4aa44'
          }}>
            <Tv size={28} color='#07080f' />
          </div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: C.textPrimary, letterSpacing: -0.5, margin: '0 0 4px' }}>
            streamvision
          </h1>
          <p style={{ fontSize: 13, color: C.textDim, letterSpacing: 1, textTransform: 'uppercase' }}>
            Property CMS · v1.0.0
          </p>
        </div>

        {/* Login Card */}
        <div style={{
          background: C.panel, border: `1px solid ${C.cardBorder}`, borderRadius: 16,
          padding: 32, marginBottom: 16
        }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, color: C.textPrimary, marginBottom: 24, textAlign: 'center' }}>
            Sign in to your account
          </h2>

          {/* Social Logins */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
            {[
              { label: 'Google', icon: Chrome, color: '#ea4335' },
              { label: 'Apple', icon: Apple, color: C.textPrimary },
            ].map(({ label, icon: Icon, color }) => (
              <button key={label} onClick={() => setError('OAuth configuration required — use email login below')}
                style={{
                  flex: 1, padding: '10px 14px', background: C.card,
                  border: `1px solid ${C.border}`, borderRadius: 8, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                  color: C.textSecondary, fontFamily: 'inherit', fontSize: 13, fontWeight: 500
                }}>
                <Icon size={16} color={color} />
                <span>Continue with {label}</span>
              </button>
            ))}
          </div>

          {/* Divider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
            <div style={{ flex: 1, height: 1, background: C.border }} />
            <span style={{ fontSize: 12, color: C.textDim }}>or continue with email</span>
            <div style={{ flex: 1, height: 1, background: C.border }} />
          </div>

          <form onSubmit={handleSubmit}>
            {/* Email */}
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: C.textSecondary, display: 'block', marginBottom: 6, fontWeight: 500 }}>
                Email Address
              </label>
              <div style={{ position: 'relative' }}>
                <Mail size={15} color={C.textDim} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} />
                <input
                  type='email' value={email} onChange={e => setEmail(e.target.value)}
                  placeholder='you@example.com' required
                  style={{
                    width: '100%', padding: '10px 12px 10px 36px', background: C.card,
                    border: `1px solid ${C.border}`, borderRadius: 8, color: C.textPrimary,
                    fontSize: 14, outline: 'none', boxSizing: 'border-box'
                  }}
                />
              </div>
            </div>

            {/* Password */}
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 12, color: C.textSecondary, display: 'block', marginBottom: 6, fontWeight: 500 }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <Lock size={15} color={C.textDim} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} />
                <input
                  type='password' value={password} onChange={e => setPassword(e.target.value)}
                  placeholder='••••••••••' required
                  style={{
                    width: '100%', padding: '10px 12px 10px 36px', background: C.card,
                    border: `1px solid ${C.border}`, borderRadius: 8, color: C.textPrimary,
                    fontSize: 14, outline: 'none', boxSizing: 'border-box'
                  }}
                />
              </div>
            </div>

            {error && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16,
                padding: '10px 12px', background: '#ef444418', border: `1px solid #ef444433`,
                borderRadius: 8
              }}>
                <AlertCircle size={14} color={C.red} />
                <span style={{ fontSize: 13, color: C.red }}>{error}</span>
              </div>
            )}

            <button type='submit' disabled={loading} style={{
              width: '100%', padding: '12px', background: C.teal, border: 'none',
              borderRadius: 8, color: '#07080f', fontSize: 15, fontWeight: 700,
              cursor: loading ? 'not-allowed' : 'pointer', fontFamily: 'inherit',
              opacity: loading ? 0.7 : 1, letterSpacing: 0.2
            }}>
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>

        {/* Demo Accounts */}
        <div style={{
          background: C.panel, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 16
        }}>
          <p style={{ fontSize: 11, color: C.textDim, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10, textAlign: 'center' }}>
            Demo Accounts — Click to auto-fill
          </p>
          {demoAccounts.map(acc => (
            <button key={acc.email} onClick={() => { setEmail(acc.email); setPassword(acc.pw); setError(''); }}
              style={{
                width: '100%', padding: '9px 12px', background: C.card,
                border: `1px solid ${acc.color}33`, borderRadius: 8,
                cursor: 'pointer', marginBottom: 6, textAlign: 'left', fontFamily: 'inherit',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: acc.color }}>{acc.label}</span>
              <span style={{ fontSize: 11, color: C.textDim }}>{acc.email}</span>
            </button>
          ))}
        </div>

        <p style={{ textAlign: 'center', marginTop: 20, fontSize: 12, color: C.textDim }}>
          © 2026 Streamvision Pty Ltd · streamvision.com.au
        </p>
      </div>
    </div>
  );
}
