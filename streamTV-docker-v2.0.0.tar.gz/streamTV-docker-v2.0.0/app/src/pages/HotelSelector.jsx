import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { Building2, ChevronRight, Search, LogOut, Users, Globe, Tv } from 'lucide-react';

export default function HotelSelector() {
  const { C } = useTheme();
  const { user, logout, setActiveHotel, version } = useAuth();
  const [search, setSearch] = useState('');

  const hotels = (user.accessibleHotels || []).filter(h =>
    h.name.toLowerCase().includes(search.toLowerCase()) ||
    h.city?.toLowerCase().includes(search.toLowerCase()) ||
    h.code?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{
      minHeight: '100vh', background: C.bg, display: 'flex', alignItems: 'center',
      justifyContent: 'center', padding: 20, fontFamily: "'DM Sans', sans-serif"
    }}>
      {/* BG glow */}
      <div style={{
        position: 'fixed', top: 0, left: '50%', transform: 'translateX(-50%)',
        width: '80vw', height: '40vh',
        background: 'radial-gradient(ellipse, #00d4aa0d 0%, transparent 70%)',
        pointerEvents: 'none'
      }} />

      <div style={{ width: '100%', maxWidth: 640 }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: C.teal, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Tv size={22} color='#07080f' />
            </div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 800, color: C.textPrimary }}>streamvision</div>
              <div style={{ fontSize: 11, color: C.textDim, letterSpacing: 0.5 }}>v{version} · Select a Property</div>
            </div>
          </div>
          <button onClick={logout} style={{
            display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px',
            background: C.panel, border: `1px solid ${C.border}`, borderRadius: 8,
            color: C.textSecondary, cursor: 'pointer', fontSize: 13, fontFamily: 'inherit'
          }}>
            <LogOut size={13} /> Sign Out
          </button>
        </div>

        {/* Welcome */}
        <div style={{ background: C.panel, border: `1px solid ${C.cardBorder}`, borderRadius: 14, padding: '16px 20px', marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: C.teal, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, fontWeight: 700, color: '#07080f' }}>
              {user.name[0]}
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: C.textPrimary }}>Welcome back, {user.name.split(' ')[0]}</div>
              <div style={{ fontSize: 12, color: C.textSecondary }}>
                {user.role === 'superadmin' ? 'Streamvision Administrator' : user.role === 'group_admin' ? 'Group Administrator' : 'Hotel Administrator'}
                {user.group && ` · ${user.group.name}`}
              </div>
            </div>
          </div>
        </div>

        {/* Search */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
          background: C.panel, border: `1px solid ${C.border}`, borderRadius: 10, marginBottom: 16
        }}>
          <Search size={15} color={C.textDim} />
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder='Search properties by name, city or code...'
            style={{ flex: 1, background: 'none', border: 'none', color: C.textPrimary, fontSize: 14, fontFamily: 'inherit', outline: 'none' }}
          />
        </div>

        {/* Hotel List */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {hotels.length === 0 && (
            <div style={{ textAlign: 'center', padding: 32, color: C.textDim, fontSize: 14 }}>No properties found</div>
          )}
          {hotels.map(h => (
            <button key={h.id} onClick={() => setActiveHotel(h)} style={{
              display: 'flex', alignItems: 'center', gap: 14, padding: '16px 18px',
              background: C.panel, border: `1px solid ${C.cardBorder}`, borderRadius: 12,
              cursor: 'pointer', textAlign: 'left', width: '100%', fontFamily: 'inherit',
              transition: 'all 0.15s'
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = C.teal + '66'; e.currentTarget.style.background = C.tealDim; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = C.cardBorder; e.currentTarget.style.background = C.panel; }}
            >
              <div style={{
                width: 48, height: 48, borderRadius: 10, background: C.tealDim, border: `1px solid ${C.teal}33`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
              }}>
                <Building2 size={22} color={C.teal} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: C.textPrimary, marginBottom: 3 }}>{h.name}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontSize: 12, color: C.textSecondary }}>{h.city}, {h.country}</span>
                  {h.total_rooms > 0 && <span style={{ fontSize: 12, color: C.textDim }}>{h.total_rooms} rooms</span>}
                  <span style={{
                    fontSize: 10, fontWeight: 700, padding: '2px 6px', borderRadius: 4,
                    background: C.tealDim, color: C.teal, border: `1px solid ${C.teal}33`
                  }}>{h.code}</span>
                </div>
              </div>
              <ChevronRight size={18} color={C.textDim} />
            </button>
          ))}
        </div>

        <p style={{ textAlign: 'center', marginTop: 20, fontSize: 12, color: C.textDim }}>
          {hotels.length} {hotels.length === 1 ? 'property' : 'properties'} accessible · streamvision.com.au
        </p>
      </div>
    </div>
  );
}
