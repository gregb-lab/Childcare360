import { useState, useRef } from 'react';
import { useTheme } from '../context/ThemeContext.jsx';
import CanvasEditor from '../components/CanvasEditor.jsx';
import {
  Plus, Edit, Trash2, ChevronRight, Eye, Settings, Layers, ArrowRight,
  Sun, Moon, Home, Image, Video, Sliders, Calendar, Clock, X, Check, Copy
} from 'lucide-react';

let pageIdCounter = 1;
const newPageId = () => `page_${++pageIdCounter}_${Date.now()}`;

const DEFAULT_PAGES = [
  { id: 'home', name: 'Home / Welcome', isHome: true, elements: [], bg: { type: 'color', value: '#0a0f1e' } },
  { id: 'services', name: 'Guest Services', isHome: false, elements: [], bg: { type: 'color', value: '#0e1623' } },
  { id: 'movies', name: 'Movies & VOD', isHome: false, elements: [], bg: { type: 'color', value: '#0a0a14' } },
];

export default function PortalDesigner({ hotelId }) {
  const { C, isDark } = useTheme();
  const [tab, setTab] = useState('pages');
  const [pages, setPages] = useState(DEFAULT_PAGES);
  const [editingPageId, setEditingPageId] = useState(null);
  const [amPm, setAmPm] = useState('am');
  const [showEditor, setShowEditor] = useState(false);

  const editingPage = pages.find(p => p.id === editingPageId);

  const Btn = ({ children, variant='primary', size='md', onClick, icon: Icon, style: s={} }) => {
    const v = {
      primary: { background: C.teal, color: isDark?'#07080f':'#fff', border:'none' },
      secondary: { background: C.card, color: C.textPrimary, border:`1px solid ${C.border}` },
      danger: { background: C.red+'18', color: C.red, border:`1px solid ${C.red}33` },
      ghost: { background:'transparent', color: C.textSecondary, border:`1px solid transparent` },
    };
    return <button onClick={onClick} style={{ display:'inline-flex', alignItems:'center', gap:6, borderRadius:8, fontWeight:600, fontFamily:'DM Sans', cursor:'pointer', fontSize:size==='sm'?12:14, padding:size==='sm'?'5px 11px':'9px 16px', ...v[variant], ...s }}>{Icon&&<Icon size={size==='sm'?13:15}/>}{children}</button>;
  };

  const addPage = () => {
    const id = newPageId();
    setPages(p => [...p, { id, name: `Page ${p.length + 1}`, isHome: false, elements: [], bg: { type: 'color', value: '#0e1623' } }]);
  };

  const deletePage = (id) => {
    if (id === 'home') return;
    setPages(p => p.filter(pg => pg.id !== id));
    if (editingPageId === id) setEditingPageId(null);
  };

  const openEditor = (pageId) => {
    setEditingPageId(pageId);
    setShowEditor(true);
  };

  const savePageElements = (elements) => {
    setPages(p => p.map(pg => pg.id === editingPageId ? { ...pg, elements } : pg));
    setShowEditor(false);
  };

  const updatePageBg = (id, bg) => {
    setPages(p => p.map(pg => pg.id === id ? { ...pg, bg } : pg));
  };

  if (showEditor && editingPage) {
    return (
      <div style={{ display:'flex', flexDirection:'column', height:'calc(100vh - 54px)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 16px', background:C.sidebar, borderBottom:`1px solid ${C.border}`, flexShrink:0 }}>
          <button onClick={() => setShowEditor(false)} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:6, padding:'6px 12px', color:C.textSecondary, cursor:'pointer', fontSize:12, fontFamily:'DM Sans', display:'flex', alignItems:'center', gap:5 }}>
            <ChevronRight size={13} style={{ transform:'rotate(180deg)' }}/> Back
          </button>
          <span style={{ fontSize:13, color:C.textPrimary, fontWeight:600 }}>Portal Editor: {editingPage.name}</span>
          <div style={{ display:'flex', gap:4, marginLeft:'auto' }}>
            {pages.map(pg => (
              <button key={pg.id} onClick={() => setEditingPageId(pg.id)}
                style={{ padding:'4px 10px', borderRadius:5, background: pg.id === editingPageId ? C.teal : C.card, color: pg.id === editingPageId ? (isDark?'#07080f':'#fff') : C.textSecondary, border: pg.id === editingPageId ? 'none' : `1px solid ${C.border}`, cursor:'pointer', fontSize:11, fontFamily:'DM Sans', fontWeight:600 }}>
                {pg.isHome ? '🏠' : ''}{pg.name}
              </button>
            ))}
          </div>
        </div>
        <div style={{ flex:1, overflow:'hidden' }}>
          <CanvasEditor
            mode="portal"
            initialElements={editingPage.elements}
            pages={pages.filter(p => p.id !== editingPageId)}
            canvasBackground={editingPage.bg?.value || '#0a0f1e'}
            onSave={savePageElements}
            onSaveTemplate={() => alert('Page saved as template!')}
          />
        </div>
      </div>
    );
  }

  const TABS = [
    ['pages', Layers, 'Pages'],
    ['background', Image, 'Background & Theme'],
    ['schedule', Calendar, 'AM / PM Schedule'],
    ['settings', Settings, 'Portal Settings'],
    ['preview', Eye, 'Preview'],
  ];

  return (
    <div style={{ fontFamily:'DM Sans', color:C.textPrimary }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <div>
          <h2 style={{ margin:0, fontSize:22, fontWeight:700, color:C.textPrimary }}>Portal Designer</h2>
          <p style={{ margin:'4px 0 0', fontSize:13, color:C.textSecondary }}>Build the interactive on-screen TV portal with pages, navigation and widgets</p>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <Btn icon={Eye} variant='secondary'>Preview Portal</Btn>
          <Btn icon={Check}>Publish Live</Btn>
        </div>
      </div>

      <div style={{ display:'flex', gap:2, marginBottom:22, background:C.card, padding:4, borderRadius:10, width:'fit-content', border:`1px solid ${C.border}` }}>
        {TABS.map(([k,Icon,label]) => (
          <button key={k} onClick={() => setTab(k)} style={{ display:'flex', alignItems:'center', gap:6, padding:'7px 14px', borderRadius:7, background:tab===k?C.teal:'transparent', color:tab===k?(isDark?'#07080f':'#fff'):C.textSecondary, border:'none', cursor:'pointer', fontWeight:600, fontSize:13, fontFamily:'DM Sans' }}>
            <Icon size={13}/>{label}
          </button>
        ))}
      </div>

      {/* PAGES TAB */}
      {tab === 'pages' && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 360px', gap:20 }}>
          <div>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
              <p style={{ margin:0, fontSize:13, color:C.textSecondary }}>
                Build pages then link buttons between them. The Home page is the first screen guests see.
              </p>
              <Btn icon={Plus} size='sm' onClick={addPage}>Add Page</Btn>
            </div>
            <div style={{ display:'grid', gap:10 }}>
              {pages.map(pg => (
                <div key={pg.id} style={{ background:C.card, border:`1px solid ${pg.isHome?C.teal+'55':C.cardBorder}`, borderRadius:12, padding:'16px 18px', display:'flex', alignItems:'center', gap:14 }}>
                  <div style={{ width:80, height:46, borderRadius:6, background: pg.bg?.value || '#0e1623', border:`1px solid ${C.border}`, overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:11, color:'#ffffff66' }}>
                    {pg.elements.length > 0 ? `${pg.elements.length} el` : '🖼'}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3 }}>
                      <span style={{ fontWeight:700, fontSize:15, color:C.textPrimary }}>{pg.name}</span>
                      {pg.isHome && <span style={{ background:C.tealDim, color:C.teal, border:`1px solid ${C.tealMid}`, borderRadius:4, padding:'1px 7px', fontSize:10, fontWeight:700 }}>HOME</span>}
                    </div>
                    <div style={{ fontSize:12, color:C.textSecondary }}>
                      {pg.elements.length} element{pg.elements.length !== 1 ? 's' : ''}
                      {' · '}
                      Background: {pg.bg?.type || 'color'}
                      {' · '}
                      Linked from: {pages.filter(other => other.elements.some(el => el.props?.linkTo === pg.id)).length} page{pages.filter(other => other.elements.some(el => el.props?.linkTo === pg.id)).length !== 1 ? 's' : ''}
                    </div>
                  </div>
                  <div style={{ display:'flex', gap:6 }}>
                    <Btn variant='ghost' size='sm' icon={Copy}>Duplicate</Btn>
                    <Btn variant='secondary' size='sm' icon={Edit} onClick={() => openEditor(pg.id)}>Edit Page</Btn>
                    {!pg.isHome && <button onClick={() => deletePage(pg.id)} style={{ background:'none', border:'none', cursor:'pointer', color:C.textDim, padding:4 }}><Trash2 size={14}/></button>}
                  </div>
                </div>
              ))}
            </div>

            {/* Page flow diagram */}
            <div style={{ background:C.card, border:`1px solid ${C.cardBorder}`, borderRadius:12, padding:20, marginTop:20 }}>
              <h4 style={{ margin:'0 0 14px', fontSize:13, fontWeight:600, color:C.textPrimary }}>Page Flow Diagram</h4>
              <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
                {pages.map((pg, i) => (
                  <>
                    <div key={pg.id} style={{ background: pg.isHome ? C.tealDim : isDark?'#1c2a3d':'#f4f6fb', border:`1px solid ${pg.isHome?C.teal:C.border}`, borderRadius:8, padding:'8px 14px', fontSize:12, color: pg.isHome ? C.teal : C.textPrimary, fontWeight: pg.isHome ? 700 : 400 }}>
                      {pg.isHome ? '🏠 ' : ''}{pg.name}
                    </div>
                    {i < pages.length - 1 && <ArrowRight size={14} color={C.textDim} key={`arrow_${i}`}/>}
                  </>
                ))}
              </div>
              <p style={{ margin:'10px 0 0', fontSize:11, color:C.textDim }}>Link buttons between pages using the Portal Editor → select a button element → set Link To in properties panel.</p>
            </div>
          </div>

          {/* Right: Quick editor tips */}
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div style={{ background:C.card, border:`1px solid ${C.cardBorder}`, borderRadius:12, padding:16 }}>
              <h4 style={{ margin:'0 0 12px', fontSize:13, fontWeight:600, color:C.textPrimary }}>How to Build a Portal</h4>
              {[
                ['1', 'Create pages', 'Add the pages guests will see (Home, Services, Movies, etc.)'],
                ['2', 'Edit Home page', 'Open the editor and drag Navigation Buttons/Tiles onto the canvas'],
                ['3', 'Link buttons', 'Select a button → set "Link to Page" in Properties panel'],
                ['4', 'Add content', 'Add clocks, weather, guest name, images and more to each page'],
                ['5', 'Set backgrounds', 'Use the Background tab to set video/image/slideshow backgrounds'],
                ['6', 'Publish', 'Hit Publish Live to push to all hotel guest TVs'],
              ].map(([n, title, desc]) => (
                <div key={n} style={{ display:'flex', gap:10, marginBottom:10 }}>
                  <div style={{ width:22, height:22, borderRadius:'50%', background:C.tealDim, border:`1px solid ${C.tealMid}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700, color:C.teal, flexShrink:0 }}>{n}</div>
                  <div>
                    <div style={{ fontSize:12, fontWeight:600, color:C.textPrimary }}>{title}</div>
                    <div style={{ fontSize:11, color:C.textSecondary }}>{desc}</div>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ background:C.card, border:`1px solid ${C.cardBorder}`, borderRadius:12, padding:16 }}>
              <h4 style={{ margin:'0 0 12px', fontSize:13, fontWeight:600, color:C.textPrimary }}>Quick Actions</h4>
              <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                {pages.map(pg => (
                  <button key={pg.id} onClick={() => openEditor(pg.id)} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 12px', background:isDark?'#1c2a3d':C.bg, border:`1px solid ${C.border}`, borderRadius:8, cursor:'pointer', textAlign:'left', fontFamily:'DM Sans', width:'100%' }}>
                    <div style={{ width:28, height:16, borderRadius:3, background:pg.bg?.value||'#0e1623', border:`1px solid ${C.border}`, flexShrink:0 }}/>
                    <span style={{ flex:1, fontSize:12, fontWeight:600, color:C.textPrimary }}>{pg.name}</span>
                    <span style={{ fontSize:11, color:C.textDim }}>{pg.elements.length} el</span>
                    <Edit size={12} color={C.textDim}/>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* BACKGROUND TAB */}
      {tab === 'background' && (
        <div style={{ display:'grid', gridTemplateColumns:'320px 1fr', gap:20 }}>
          <div>
            <h3 style={{ margin:'0 0 14px', fontSize:15, fontWeight:700, color:C.textPrimary }}>Background Settings</h3>
            <p style={{ margin:'0 0 16px', fontSize:13, color:C.textSecondary }}>Set the background for each portal page. Choose from solid colour, image, video or slideshow.</p>
            <div style={{ marginBottom:16 }}>
              <label style={{ fontSize:11, color:C.textSecondary, textTransform:'uppercase', letterSpacing:0.6, display:'block', marginBottom:8, fontWeight:600 }}>Page</label>
              <select value={editingPageId || ''} onChange={e => setEditingPageId(e.target.value || null)}
                style={{ width:'100%', padding:'9px 11px', background:C.inputBg, border:`1px solid ${C.border}`, borderRadius:7, color:C.textPrimary, fontFamily:'DM Sans', fontSize:13 }}>
                <option value=''>Select a page...</option>
                {pages.map(pg => <option key={pg.id} value={pg.id}>{pg.name}</option>)}
              </select>
            </div>
            {editingPageId && (() => {
              const pg = pages.find(p => p.id === editingPageId);
              if (!pg) return null;
              const bg = pg.bg || { type: 'color', value: '#0e1623' };
              return (
                <div>
                  <label style={{ fontSize:11, color:C.textSecondary, textTransform:'uppercase', letterSpacing:0.6, display:'block', marginBottom:8, fontWeight:600 }}>Background Type</label>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6, marginBottom:14 }}>
                    {[['color','Solid Color'], ['image','Image'], ['video','Video'], ['slideshow','Slideshow']].map(([t,l]) => (
                      <button key={t} onClick={() => updatePageBg(editingPageId, { ...bg, type: t })}
                        style={{ padding:'9px', borderRadius:7, border:`1px solid ${bg.type===t?C.teal:C.border}`, background:bg.type===t?C.tealDim:'transparent', color:bg.type===t?C.teal:C.textSecondary, cursor:'pointer', fontSize:12, fontFamily:'DM Sans', fontWeight:bg.type===t?700:400 }}>
                        {t==='color'?'🎨':t==='image'?'🖼':t==='video'?'🎥':'🎞'} {l}
                      </button>
                    ))}
                  </div>

                  {bg.type === 'color' && (
                    <div>
                      <label style={{ fontSize:11, color:C.textSecondary, display:'block', marginBottom:6 }}>Background Color</label>
                      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                        <input type='color' value={bg.value || '#0e1623'} onChange={e => updatePageBg(editingPageId, { ...bg, value: e.target.value })}
                          style={{ width:44, height:44, padding:2, background:C.card, border:`1px solid ${C.border}`, borderRadius:6, cursor:'pointer' }}/>
                        <div style={{ display:'flex', gap:4 }}>
                          {['#0a0f1e','#0e1623','#1a0a00','#0a001a','#000000','#001a0a'].map(c => (
                            <button key={c} onClick={() => updatePageBg(editingPageId, { ...bg, value: c })}
                              style={{ width:28, height:28, background:c, border:`2px solid ${bg.value===c?C.teal:'transparent'}`, borderRadius:4, cursor:'pointer' }}/>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {(bg.type === 'image' || bg.type === 'video') && (
                    <div>
                      <div style={{ background:C.card, border:`2px dashed ${C.border}`, borderRadius:8, padding:'20px', textAlign:'center', cursor:'pointer', marginBottom:10 }}>
                        <div style={{ fontSize:28, marginBottom:8 }}>{bg.type === 'video' ? '🎥' : '🖼'}</div>
                        <div style={{ fontSize:13, color:C.textSecondary }}>Click to upload {bg.type}</div>
                        <div style={{ fontSize:11, color:C.textDim, marginTop:4 }}>
                          {bg.type === 'video' ? 'MP4, MOV — recommended 1920×1080' : 'JPG, PNG — recommended 1920×1080'}
                        </div>
                      </div>
                      {bg.type === 'image' && (
                        <div>
                          <label style={{ fontSize:11, color:C.textSecondary, display:'block', marginBottom:5 }}>Background Overlay</label>
                          <input type='range' min={0} max={90} defaultValue={40}
                            style={{ width:'100%' }}/>
                          <span style={{ fontSize:11, color:C.textDim }}>Overlay opacity</span>
                        </div>
                      )}
                    </div>
                  )}

                  {bg.type === 'slideshow' && (
                    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:8, padding:14 }}>
                      <div style={{ fontSize:13, color:C.textSecondary, marginBottom:10 }}>Slideshow backgrounds cycle behind your portal content.</div>
                      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:10 }}>
                        <div>
                          <div style={{ fontSize:11, color:C.textDim, marginBottom:4 }}>Interval (sec)</div>
                          <input type='number' defaultValue={8} min={2} max={60}
                            style={{ width:'100%', padding:'7px', background:C.inputBg, border:`1px solid ${C.border}`, borderRadius:5, color:C.textPrimary, fontSize:13, fontFamily:'DM Sans', boxSizing:'border-box' }}/>
                        </div>
                        <div>
                          <div style={{ fontSize:11, color:C.textDim, marginBottom:4 }}>Transition</div>
                          <select style={{ width:'100%', padding:'7px', background:C.inputBg, border:`1px solid ${C.border}`, borderRadius:5, color:C.textPrimary, fontSize:13, fontFamily:'DM Sans' }}>
                            {['Fade','Slide','Zoom','Dissolve'].map(t => <option key={t}>{t}</option>)}
                          </select>
                        </div>
                      </div>
                      <button style={{ width:'100%', padding:'9px', background:'transparent', border:`2px dashed ${C.border}`, borderRadius:7, color:C.textSecondary, cursor:'pointer', fontSize:13, fontFamily:'DM Sans' }}>
                        + Add Images from Asset Library
                      </button>
                    </div>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Preview */}
          <div>
            <h4 style={{ margin:'0 0 12px', fontSize:13, fontWeight:600, color:C.textSecondary, textTransform:'uppercase', letterSpacing:0.7 }}>Page Preview</h4>
            <div style={{ aspectRatio:'16/9', borderRadius:10, overflow:'hidden', border:`1px solid ${C.border}`, background: editingPageId ? (pages.find(p=>p.id===editingPageId)?.bg?.value||'#0e1623') : '#0e1623', display:'flex', alignItems:'center', justifyContent:'center' }}>
              {editingPageId
                ? <div style={{ color:'#ffffff44', fontSize:14, fontFamily:'DM Sans' }}>{pages.find(p=>p.id===editingPageId)?.name} — Preview</div>
                : <div style={{ color:'#ffffff22', fontSize:13, fontFamily:'DM Sans' }}>Select a page to preview</div>
              }
            </div>
          </div>
        </div>
      )}

      {/* AM/PM SCHEDULE TAB */}
      {tab === 'schedule' && (
        <div style={{ maxWidth:700 }}>
          <div style={{ background:C.card, border:`1px solid ${C.cardBorder}`, borderRadius:12, padding:22, marginBottom:16 }}>
            <h3 style={{ margin:'0 0 6px', fontSize:16, fontWeight:700, color:C.textPrimary }}>AM / PM Portal Scheduling</h3>
            <p style={{ margin:'0 0 18px', fontSize:13, color:C.textSecondary }}>Show different portal themes and content based on time of day. E.g. a breakfast menu in the morning, evening dining at night.</p>
            <div style={{ display:'flex', gap:8, marginBottom:18 }}>
              {['am', 'pm', 'auto'].map(m => (
                <button key={m} onClick={() => setAmPm(m)}
                  style={{ flex:1, padding:'10px', borderRadius:8, border:`1px solid ${amPm===m?C.teal:C.border}`, background:amPm===m?C.tealDim:'transparent', color:amPm===m?C.teal:C.textSecondary, cursor:'pointer', fontSize:13, fontFamily:'DM Sans', fontWeight:700 }}>
                  {m==='am'?'☀️ AM Mode':m==='pm'?'🌙 PM Mode':'🔄 Auto Switch'}
                </button>
              ))}
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              {[['AM Hours', '06:00', '12:00', Sun], ['PM Hours', '12:00', '06:00', Moon]].map(([label, start, end, Icon]) => (
                <div key={label} style={{ background:isDark?'#1c2a3d':C.bg, borderRadius:9, padding:14, border:`1px solid ${C.border}` }}>
                  <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:10, fontSize:13, fontWeight:700, color:C.textPrimary }}>
                    <Icon size={15} color={label.startsWith('AM')?C.amber:C.purple}/> {label}
                  </div>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                    {[['Start', start], ['End', end]].map(([l, v]) => (
                      <div key={l}>
                        <div style={{ fontSize:10, color:C.textDim, marginBottom:4 }}>{l}</div>
                        <input type='time' defaultValue={v} style={{ width:'100%', padding:'7px 8px', background:C.inputBg, border:`1px solid ${C.border}`, borderRadius:6, color:C.textPrimary, fontFamily:'DM Sans', fontSize:13, boxSizing:'border-box' }}/>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ background:C.card, border:`1px solid ${C.cardBorder}`, borderRadius:12, padding:22 }}>
            <h4 style={{ margin:'0 0 14px', fontSize:14, fontWeight:600, color:C.textPrimary }}>Advertising Panel Schedules</h4>
            <p style={{ margin:'0 0 14px', fontSize:13, color:C.textSecondary }}>Set what shows in advertising panels at different times and days.</p>
            {[
              { time:'06:00–10:00', days:'Mon–Sun', content:'Breakfast Menu', status:'active' },
              { time:'10:00–14:00', days:'Mon–Sun', content:'Spa & Wellness Offer', status:'active' },
              { time:'14:00–18:00', days:'Mon–Fri', content:'Happy Hour Promo', status:'active' },
              { time:'18:00–22:00', days:'Mon–Sun', content:'Restaurant Evening Menu', status:'active' },
            ].map((s, i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 12px', background:isDark?'#1c2a3d':C.bg, borderRadius:8, marginBottom:6, border:`1px solid ${C.border}` }}>
                <Clock size={13} color={C.teal}/>
                <span style={{ fontWeight:600, color:C.teal, fontSize:13, minWidth:120 }}>{s.time}</span>
                <span style={{ fontSize:12, color:C.textSecondary, flex:1 }}>{s.content}</span>
                <span style={{ fontSize:11, color:C.textDim }}>{s.days}</span>
                <span style={{ background:C.green+'22', color:C.green, border:`1px solid ${C.green}33`, borderRadius:4, padding:'1px 7px', fontSize:10, fontWeight:600 }}>Active</span>
                <button style={{ background:'none', border:'none', cursor:'pointer', color:C.textDim }}><Edit size={13}/></button>
              </div>
            ))}
            <button style={{ width:'100%', padding:'9px', background:'transparent', border:`2px dashed ${C.border}`, borderRadius:8, color:C.textSecondary, cursor:'pointer', marginTop:8, fontSize:13, fontFamily:'DM Sans', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
              <Plus size={14}/> Add Schedule Slot
            </button>
          </div>
        </div>
      )}

      {/* SETTINGS TAB */}
      {tab === 'settings' && (
        <div style={{ maxWidth:600, display:'flex', flexDirection:'column', gap:14 }}>
          {[
            ['Portal Name', 'text', 'Hilton Garden Inn Darwin'],
            ['Welcome Message', 'text', 'Welcome to Your Stay'],
            ['Footer Text', 'text', 'For assistance, press 0 or visit Reception'],
          ].map(([label, type, placeholder]) => (
            <div key={label}>
              <label style={{ fontSize:12, color:C.textSecondary, display:'block', marginBottom:6, fontWeight:600 }}>{label}</label>
              <input type={type} defaultValue={placeholder}
                style={{ width:'100%', padding:'10px 12px', background:C.inputBg, border:`1px solid ${C.border}`, borderRadius:8, color:C.textPrimary, fontFamily:'DM Sans', fontSize:14, boxSizing:'border-box', outline:'none' }}/>
            </div>
          ))}
          <div>
            <label style={{ fontSize:12, color:C.textSecondary, display:'block', marginBottom:8, fontWeight:600 }}>Portal Features</label>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {[['Show guest name on welcome','true'],['Show room number','true'],['Show weather widget','true'],['Show news ticker','false'],['Enable guest messaging notifications','true'],['Show check-out reminder (from 10am)','true']].map(([l, def]) => (
                <label key={l} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 14px', background:C.card, border:`1px solid ${C.border}`, borderRadius:8, cursor:'pointer', fontSize:13, color:C.textPrimary }}>
                  <input type='checkbox' defaultChecked={def==='true'} style={{ width:16, height:16 }}/>
                  {l}
                </label>
              ))}
            </div>
          </div>
          <Btn icon={Check}>Save Portal Settings</Btn>
        </div>
      )}

      {/* PREVIEW TAB */}
      {tab === 'preview' && (
        <div>
          <div style={{ display:'flex', gap:10, alignItems:'center', marginBottom:14 }}>
            <span style={{ fontSize:13, color:C.textSecondary }}>Preview mode:</span>
            {[['am','☀️ AM'],['pm','🌙 PM']].map(([m,l]) => (
              <button key={m} onClick={() => setAmPm(m)}
                style={{ padding:'5px 12px', borderRadius:6, border:`1px solid ${amPm===m?C.teal:C.border}`, background:amPm===m?C.tealDim:'transparent', color:amPm===m?C.teal:C.textSecondary, cursor:'pointer', fontSize:12, fontFamily:'DM Sans' }}>
                {l}
              </button>
            ))}
          </div>
          <div style={{ aspectRatio:'16/9', maxWidth:900, borderRadius:12, overflow:'hidden', border:`1px solid ${C.border}`, background:'#0a0f1e', position:'relative', display:'flex', flexDirection:'column' }}>
            <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:12 }}>
              <div style={{ fontSize:11, color:'#ffffff66', marginBottom:4 }}>{amPm.toUpperCase()} PORTAL PREVIEW</div>
              <div style={{ fontSize:26, fontWeight:700, color:'#fff' }}>Welcome, James T.</div>
              <div style={{ fontSize:16, color:'#ffffff88' }}>Room 203 · Deluxe · Floor 2</div>
              <div style={{ display:'flex', gap:12, marginTop:16 }}>
                {pages.map(pg => (
                  <div key={pg.id} style={{ padding:'14px 22px', borderRadius:12, background: pg.isHome ? '#00d4aa' : '#ffffff18', color: pg.isHome ? '#07080f' : '#fff', fontSize:14, fontWeight:700, cursor:'pointer' }}>
                    {pg.name}
                  </div>
                ))}
              </div>
            </div>
            <div style={{ padding:'8px 16px', background:'#00000055', fontSize:11, color:'#ffffff66', display:'flex', justifyContent:'space-between' }}>
              <span>Hilton Garden Inn Darwin</span>
              <span>{new Date().toLocaleTimeString()}</span>
            </div>
          </div>
          <p style={{ fontSize:12, color:C.textDim, marginTop:10 }}>This is a simplified preview. For full interactive preview, use the Preview Portal button above.</p>
        </div>
      )}
    </div>
  );
}
