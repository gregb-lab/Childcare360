import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { useTheme } from '../context/ThemeContext.jsx';
import { api } from '../api/client.js';
import ThemeToggle from '../components/ThemeToggle.jsx';
import SignageModule from './SignageModule.jsx';
import PortalDesigner from './PortalDesigner.jsx';
import {
  LayoutDashboard, BedDouble, Tv, MonitorPlay, Film, MessageSquare,
  ShoppingCart, BarChart2, Radio, Layers, LogOut, Settings, Zap,
  ChevronRight, Users, Wifi, WifiOff, AlertTriangle, Check,
  Send, Plus, Edit, Trash2, RefreshCw, X, Bell, Activity,
  TrendingUp, Package, Clock, Star, Globe
} from 'lucide-react';

// ─────────────────────────────────────────────────────────────────────────────
// NAV ITEMS
// ─────────────────────────────────────────────────────────────────────────────
const NAV = [
  { id: 'dashboard',  label: 'Dashboard',       icon: LayoutDashboard, section: 'main' },
  { id: 'rooms',      label: 'Rooms',            icon: BedDouble,       section: 'main' },
  { id: 'devices',    label: 'Devices',          icon: Tv,              section: 'main' },
  { id: 'channels',   label: 'Channels',         icon: Radio,           section: 'content' },
  { id: 'movies',     label: 'Movies & VOD',     icon: Film,            section: 'content' },
  { id: 'messages',   label: 'Guest Messages',   icon: MessageSquare,   section: 'content' },
  { id: 'minibar',    label: 'Minibar Menu',     icon: ShoppingCart,    section: 'content' },
  { id: 'signage',    label: 'Digital Signage',  icon: MonitorPlay,     section: 'studio' },
  { id: 'portal',     label: 'Portal Designer',  icon: Layers,          section: 'studio' },
  { id: 'studio',     label: 'streamSTUDIO',     icon: Zap,             section: 'studio' },
  { id: 'reports',    label: 'Reports',          icon: BarChart2,       section: 'reports' },
  { id: 'settings',   label: 'Settings',         icon: Settings,        section: 'settings' },
];

const SECTIONS = [
  { id: 'main',     label: 'PROPERTY' },
  { id: 'content',  label: 'CONTENT' },
  { id: 'studio',   label: 'STUDIO' },
  { id: 'reports',  label: 'ANALYTICS' },
  { id: 'settings', label: 'SYSTEM' },
];

// ─────────────────────────────────────────────────────────────────────────────
// SHARED MINI COMPONENTS (scoped — use C from parent)
// ─────────────────────────────────────────────────────────────────────────────
function Btn({ children, variant = 'primary', size = 'md', onClick, icon: Icon, disabled, style: s = {} }) {
  const { C, isDark } = useTheme();
  const variants = {
    primary:   { background: C.teal,          color: isDark ? '#07080f' : '#fff',  border: 'none' },
    secondary: { background: C.card,          color: C.textPrimary,                border: `1px solid ${C.border}` },
    danger:    { background: C.red + '18',    color: C.red,                         border: `1px solid ${C.red}33` },
    ghost:     { background: 'transparent',   color: C.textSecondary,               border: `1px solid transparent` },
    teal:      { background: C.tealDim,       color: C.teal,                        border: `1px solid ${C.tealMid}` },
    amber:     { background: C.amber + '18',  color: C.amber,                       border: `1px solid ${C.amber}33` },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, cursor: disabled ? 'not-allowed' : 'pointer',
      borderRadius: 8, fontWeight: 600, fontFamily: "'DM Sans', sans-serif",
      fontSize: size === 'sm' ? 12 : size === 'xs' ? 11 : 14,
      padding: size === 'sm' ? '5px 11px' : size === 'xs' ? '3px 8px' : '9px 16px',
      opacity: disabled ? 0.6 : 1, transition: 'opacity 0.15s', ...variants[variant], ...s
    }}>
      {Icon && <Icon size={size === 'sm' ? 13 : 15} />}
      {children}
    </button>
  );
}

function Badge({ label, color }) {
  return <span style={{ background: color + '22', color, border: `1px solid ${color}44`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600, whiteSpace: 'nowrap' }}>{label}</span>;
}

function Modal({ title, onClose, children, width = 520 }) {
  const { C } = useTheme();
  return (
    <div style={{ position: 'fixed', inset: 0, background: '#00000066', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
      onClick={e => e.target === e.currentTarget && onClose?.()}>
      <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: 28, width: '100%', maxWidth: width, maxHeight: '90vh', overflowY: 'auto', boxShadow: C.shadowLg }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 }}>
          <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: C.textPrimary }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.textSecondary, fontSize: 20 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Field({ label, children, hint }) {
  const { C } = useTheme();
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 12, color: C.textSecondary, display: 'block', marginBottom: 5, fontWeight: 500 }}>{label}</label>
      {children}
      {hint && <p style={{ fontSize: 11, color: C.textDim, margin: '4px 0 0' }}>{hint}</p>}
    </div>
  );
}

function CInput({ style: s = {}, ...props }) {
  const { C } = useTheme();
  return <input {...props} style={{ width: '100%', padding: '9px 11px', background: C.input, border: `1px solid ${C.inputBorder}`, borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans',sans-serif", boxSizing: 'border-box', outline: 'none', ...s }} />;
}

function CSelect({ children, style: s = {}, ...props }) {
  const { C } = useTheme();
  return <select {...props} style={{ width: '100%', padding: '9px 11px', background: C.input, border: `1px solid ${C.inputBorder}`, borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans',sans-serif", boxSizing: 'border-box', ...s }}>{children}</select>;
}

function StatCard({ icon: Icon, label, value, sub, color, onClick }) {
  const { C } = useTheme();
  const c = color || C.teal;
  return (
    <div onClick={onClick} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: '18px 22px', display: 'flex', gap: 14, alignItems: 'center', position: 'relative', overflow: 'hidden', cursor: onClick ? 'pointer' : 'default' }}>
      <div style={{ position: 'absolute', top: 0, right: 0, width: 100, height: 100, background: `radial-gradient(circle at top right, ${c}12, transparent 70%)`, pointerEvents: 'none' }} />
      <div style={{ width: 44, height: 44, borderRadius: 10, background: c + '18', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon size={20} color={c} />
      </div>
      <div>
        <div style={{ fontSize: 11, color: C.textSecondary, fontWeight: 500, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 3 }}>{label}</div>
        <div style={{ fontSize: 26, fontWeight: 700, color: C.textPrimary, lineHeight: 1 }}>{value}</div>
        {sub && <div style={{ fontSize: 11, color: C.textSecondary, marginTop: 3 }}>{sub}</div>}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────
function Dashboard({ hotel, onNavigate }) {
  const { C } = useTheme();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.hotels.stats(hotel.id).then(s => { setStats(s); setLoading(false); }).catch(() => setLoading(false));
  }, [hotel.id]);

  if (loading) return <div style={{ color: C.textDim, padding: 40, textAlign: 'center' }}>Loading...</div>;

  const s = stats || {};
  const occupancy = s.totalRooms > 0 ? Math.round((s.occupiedRooms / s.totalRooms) * 100) : 0;

  return (
    <div>
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>{hotel.name}</h2>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{hotel.city}, {hotel.country} · {hotel.total_rooms} rooms</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16, marginBottom: 28 }}>
        <StatCard icon={BedDouble}      label="Occupied"       value={`${occupancy}%`}      sub={`${s.occupiedRooms || 0} / ${s.totalRooms || 0} rooms`}  color={C.teal}   onClick={() => onNavigate('rooms')} />
        <StatCard icon={Tv}             label="Devices"        value={s.onlineDevices || 0} sub={`${s.faultDevices || 0} fault, ${s.offlineDevices || 0} offline`} color={C.blue}   onClick={() => onNavigate('devices')} />
        <StatCard icon={MessageSquare}  label="Messages"       value={s.sentMessages || 0}  sub="Sent this week"                                                  color={C.purple} onClick={() => onNavigate('messages')} />
        <StatCard icon={Film}           label="VOD Revenue"    value={`$${(s.vodRevenue || 0).toFixed(0)}`} sub="This month"                                     color={C.amber}  onClick={() => onNavigate('movies')} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Recent Faults */}
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: C.textPrimary }}>Device Status</h3>
            <button onClick={() => onNavigate('devices')} style={{ fontSize: 12, color: C.teal, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600 }}>View all →</button>
          </div>
          <div style={{ display: 'flex', gap: 16 }}>
            {[
              { icon: Wifi,         label: 'Online',   value: s.onlineDevices || 0,  color: C.green },
              { icon: AlertTriangle,label: 'Fault',    value: s.faultDevices || 0,   color: C.amber },
              { icon: WifiOff,      label: 'Offline',  value: s.offlineDevices || 0, color: C.red   },
            ].map(item => (
              <div key={item.label} style={{ flex: 1, textAlign: 'center', padding: '12px 8px', background: item.color + '12', borderRadius: 8 }}>
                <item.icon size={20} color={item.color} style={{ marginBottom: 6 }} />
                <div style={{ fontSize: 22, fontWeight: 700, color: item.color }}>{item.value}</div>
                <div style={{ fontSize: 11, color: C.textSecondary, marginTop: 2 }}>{item.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 20 }}>
          <h3 style={{ margin: '0 0 16px', fontSize: 14, fontWeight: 700, color: C.textPrimary }}>Quick Actions</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { label: 'Send Guest Message',  icon: Send,        nav: 'messages',  color: C.teal   },
              { label: 'Manage Channels',     icon: Radio,       nav: 'channels',  color: C.blue   },
              { label: 'Update Portal',       icon: Layers,      nav: 'portal',    color: C.purple },
              { label: 'Signage Schedules',   icon: MonitorPlay, nav: 'signage',   color: C.amber  },
            ].map(a => (
              <button key={a.nav} onClick={() => onNavigate(a.nav)} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '9px 14px',
                background: a.color + '0f', border: `1px solid ${a.color}22`,
                borderRadius: 8, cursor: 'pointer', textAlign: 'left', fontFamily: "'DM Sans',sans-serif"
              }}>
                <a.icon size={15} color={a.color} />
                <span style={{ fontSize: 13, fontWeight: 500, color: C.textPrimary }}>{a.label}</span>
                <ChevronRight size={13} color={C.textDim} style={{ marginLeft: 'auto' }} />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: ROOMS
// ─────────────────────────────────────────────────────────────────────────────
function RoomsModule({ hotel }) {
  const { C } = useTheme();
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editRoom, setEditRoom] = useState(null);

  const load = () => {
    setLoading(true);
    api.hotels.rooms(hotel.id).then(r => { setRooms(r); setLoading(false); }).catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, [hotel.id]);

  const statusColor = { occupied: C.teal, vacant: C.green, maintenance: C.amber };
  const statusLabel = { occupied: 'Occupied', vacant: 'Vacant', maintenance: 'Maintenance', active: 'Active' };

  const filtered = rooms.filter(r =>
    r.number.toLowerCase().includes(search.toLowerCase()) ||
    (r.guest_name || '').toLowerCase().includes(search.toLowerCase()) ||
    (r.type || '').toLowerCase().includes(search.toLowerCase())
  );

  const save = async () => {
    try {
      await api.hotels.updateRoom(hotel.id, editRoom.id, editRoom);
      setEditRoom(null);
      load();
    } catch (e) { alert(e.message); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Rooms</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{rooms.length} rooms configured</p>
        </div>
        <Btn icon={RefreshCw} variant="secondary" size="sm" onClick={load}>Refresh</Btn>
      </div>

      <div style={{ marginBottom: 16 }}>
        <CInput placeholder="Search rooms, guests, type..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {loading ? <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div> : (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: C.tableHeader }}>
                {['Room', 'Type', 'Floor', 'Status', 'Guest', 'Restrictions', ''].map(h => (
                  <th key={h} style={{ padding: '11px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, borderBottom: `1px solid ${C.border}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((room, i) => (
                <tr key={room.id} style={{ background: i % 2 === 0 ? C.tableRow : C.tableRowAlt }}>
                  <td style={{ padding: '11px 16px', fontWeight: 700, color: C.textPrimary, fontSize: 13, borderBottom: `1px solid ${C.border}` }}>{room.number}</td>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>{room.type}</td>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>{room.floor > 0 ? `Level ${room.floor}` : '—'}</td>
                  <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}>
                    <Badge label={statusLabel[room.status] || room.status} color={statusColor[room.status] || C.textDim} />
                  </td>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: C.textPrimary, borderBottom: `1px solid ${C.border}` }}>{room.guest_name || <span style={{ color: C.textDim }}>—</span>}</td>
                  <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}>
                    <div style={{ display: 'flex', gap: 4 }}>
                      {room.restriction_vod ? <Badge label="VOD" color={C.red} /> : null}
                      {room.restriction_adult ? <Badge label="Adult" color={C.red} /> : null}
                      {room.restriction_all ? <Badge label="All" color={C.red} /> : null}
                      {!room.restriction_vod && !room.restriction_adult && !room.restriction_all && <span style={{ color: C.textDim, fontSize: 12 }}>None</span>}
                    </div>
                  </td>
                  <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}>
                    <Btn icon={Edit} variant="ghost" size="xs" onClick={() => setEditRoom({ ...room })}>Edit</Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editRoom && (
        <Modal title={`Edit Room ${editRoom.number}`} onClose={() => setEditRoom(null)}>
          <Field label="Status">
            <CSelect value={editRoom.status} onChange={e => setEditRoom(r => ({ ...r, status: e.target.value }))}>
              <option value="vacant">Vacant</option>
              <option value="occupied">Occupied</option>
              <option value="maintenance">Maintenance</option>
            </CSelect>
          </Field>
          <Field label="Guest Name">
            <CInput value={editRoom.guest_name || ''} onChange={e => setEditRoom(r => ({ ...r, guest_name: e.target.value }))} placeholder="Guest name" />
          </Field>
          <Field label="Room Type">
            <CInput value={editRoom.type || ''} onChange={e => setEditRoom(r => ({ ...r, type: e.target.value }))} />
          </Field>
          <Field label="Restrictions">
            {[
              { key: 'restriction_vod',    label: 'Block VOD' },
              { key: 'restriction_adult',  label: 'Block Adult' },
              { key: 'restriction_billing',label: 'Block Billing' },
              { key: 'restriction_all',    label: 'Block All TV' },
            ].map(r => (
              <label key={r.key} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer', fontSize: 13, color: C.textPrimary }}>
                <input type="checkbox" checked={!!editRoom[r.key]} onChange={e => setEditRoom(rm => ({ ...rm, [r.key]: e.target.checked ? 1 : 0 }))} />
                {r.label}
              </label>
            ))}
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setEditRoom(null)}>Cancel</Btn>
            <Btn size="sm" onClick={save}>Save Changes</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: DEVICES
// ─────────────────────────────────────────────────────────────────────────────
function DevicesModule({ hotel }) {
  const { C } = useTheme();
  const [devices, setDevices] = useState([]);
  const [faults, setFaults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('all');

  const load = () => {
    setLoading(true);
    Promise.all([api.hotels.devices(hotel.id), api.hotels.faults(hotel.id)])
      .then(([d, f]) => { setDevices(d); setFaults(f); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, [hotel.id]);

  const statusColor = { online: C.green, offline: C.red, fault: C.amber };
  const shown = tab === 'faults' ? devices.filter(d => d.status !== 'online') : devices;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Devices</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{devices.length} registered devices</p>
        </div>
        <Btn icon={RefreshCw} variant="secondary" size="sm" onClick={load}>Refresh</Btn>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {[{ id: 'all', label: `All (${devices.length})` }, { id: 'faults', label: `Issues (${devices.filter(d => d.status !== 'online').length})` }].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: '6px 14px', borderRadius: 7, border: `1px solid ${tab === t.id ? C.teal : C.border}`,
            background: tab === t.id ? C.tealDim : 'transparent', color: tab === t.id ? C.teal : C.textSecondary,
            cursor: 'pointer', fontWeight: 600, fontSize: 13, fontFamily: "'DM Sans',sans-serif"
          }}>{t.label}</button>
        ))}
      </div>

      {loading ? <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div> : (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: C.tableHeader }}>
                {['Room', 'MAC Address', 'IP', 'Model', 'Firmware', 'Status', 'Last Seen', 'Notes'].map(h => (
                  <th key={h} style={{ padding: '11px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, borderBottom: `1px solid ${C.border}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {shown.map((d, i) => (
                <tr key={d.id} style={{ background: i % 2 === 0 ? C.tableRow : C.tableRowAlt }}>
                  <td style={{ padding: '11px 16px', fontWeight: 700, color: C.textPrimary, fontSize: 13, borderBottom: `1px solid ${C.border}` }}>{d.room_number || '—'}</td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: C.textSecondary, fontFamily: 'monospace', borderBottom: `1px solid ${C.border}` }}>{d.mac}</td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: C.textSecondary, fontFamily: 'monospace', borderBottom: `1px solid ${C.border}` }}>{d.ip}</td>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>{d.model}</td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: C.textDim, borderBottom: `1px solid ${C.border}` }}>v{d.firmware_version}</td>
                  <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}>
                    <Badge label={d.status} color={statusColor[d.status] || C.textDim} />
                  </td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>{d.last_seen ? new Date(d.last_seen).toLocaleString() : '—'}</td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: d.fault_note ? C.amber : C.textDim, borderBottom: `1px solid ${C.border}` }}>{d.fault_note || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {shown.length === 0 && <div style={{ textAlign: 'center', color: C.textDim, padding: 40, fontSize: 14 }}>No devices to show</div>}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: CHANNELS
// ─────────────────────────────────────────────────────────────────────────────
function ChannelsModule({ hotel }) {
  const { C } = useTheme();
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  const load = () => {
    setLoading(true);
    api.hotels.channels(hotel.id).then(c => { setChannels(c); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(() => { load(); }, [hotel.id]);

  const save = async () => {
    try {
      await api.hotels.updateChannel(hotel.id, editing.id, editing);
      setEditing(null);
      load();
    } catch (e) { alert(e.message); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Channels</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{channels.filter(c => c.active).length} active channels</p>
        </div>
        <Btn icon={RefreshCw} variant="secondary" size="sm" onClick={load}>Refresh</Btn>
      </div>

      {loading ? <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div> : (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: C.tableHeader }}>
                {['#', 'Channel Name', 'Stream URL', 'Bitrate', 'Status', 'Active', ''].map(h => (
                  <th key={h} style={{ padding: '11px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, borderBottom: `1px solid ${C.border}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {channels.map((ch, i) => (
                <tr key={ch.id} style={{ background: i % 2 === 0 ? C.tableRow : C.tableRowAlt }}>
                  <td style={{ padding: '11px 16px', fontWeight: 700, color: C.teal, fontSize: 13, borderBottom: `1px solid ${C.border}` }}>{ch.channel_number}</td>
                  <td style={{ padding: '11px 16px', fontWeight: 600, color: C.textPrimary, fontSize: 13, borderBottom: `1px solid ${C.border}` }}>{ch.name}</td>
                  <td style={{ padding: '11px 16px', fontSize: 11, color: C.textDim, fontFamily: 'monospace', borderBottom: `1px solid ${C.border}`, maxWidth: 200 }}><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block' }}>{ch.url}</span></td>
                  <td style={{ padding: '11px 16px', fontSize: 12, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>{ch.bitrate}</td>
                  <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}><Badge label={ch.status} color={ch.status === 'up' ? C.green : C.red} /></td>
                  <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}><Badge label={ch.active ? 'Active' : 'Hidden'} color={ch.active ? C.teal : C.textDim} /></td>
                  <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}><Btn icon={Edit} variant="ghost" size="xs" onClick={() => setEditing({ ...ch })}>Edit</Btn></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <Modal title={`Edit Channel ${editing.channel_number}`} onClose={() => setEditing(null)}>
          <Field label="Channel Name"><CInput value={editing.name} onChange={e => setEditing(c => ({ ...c, name: e.target.value }))} /></Field>
          <Field label="Stream URL"><CInput value={editing.url} onChange={e => setEditing(c => ({ ...c, url: e.target.value }))} /></Field>
          <Field label="Channel Number"><CInput type="number" value={editing.channel_number} onChange={e => setEditing(c => ({ ...c, channel_number: +e.target.value }))} /></Field>
          <Field label="Active">
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13, color: C.textPrimary }}>
              <input type="checkbox" checked={!!editing.active} onChange={e => setEditing(c => ({ ...c, active: e.target.checked ? 1 : 0 }))} />
              Show in guest channel list
            </label>
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setEditing(null)}>Cancel</Btn>
            <Btn size="sm" onClick={save}>Save</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: MOVIES
// ─────────────────────────────────────────────────────────────────────────────
function MoviesModule({ hotel }) {
  const { C } = useTheme();
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  const load = () => {
    setLoading(true);
    api.hotels.movies(hotel.id).then(m => { setMovies(m); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(() => { load(); }, [hotel.id]);

  const save = async () => {
    try {
      await api.hotels.updateMovie(hotel.id, editing.id, editing);
      setEditing(null);
      load();
    } catch (e) { alert(e.message); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Movies & VOD</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{movies.filter(m => m.active).length} active titles</p>
        </div>
      </div>

      {loading ? <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div> : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {movies.map(movie => (
            <div key={movie.id} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 18, display: 'flex', gap: 14, alignItems: 'flex-start' }}>
              <div style={{ fontSize: 36, flexShrink: 0, lineHeight: 1, width: 50, height: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', background: C.panel, borderRadius: 8 }}>{movie.poster}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: C.textPrimary, marginBottom: 2 }}>{movie.title}</div>
                <div style={{ fontSize: 12, color: C.textSecondary, marginBottom: 6 }}>{movie.year} · {movie.genre} · ⭐ {movie.rating}</div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 14, fontWeight: 700, color: C.teal }}>${movie.price}</span>
                  <Badge label={movie.active ? 'Active' : 'Hidden'} color={movie.active ? C.green : C.textDim} />
                  <Btn icon={Edit} variant="ghost" size="xs" onClick={() => setEditing({ ...movie })} style={{ marginLeft: 'auto' }}>Edit</Btn>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <Modal title="Edit Movie" onClose={() => setEditing(null)}>
          <div style={{ marginBottom: 16, display: 'flex', gap: 14, alignItems: 'center' }}>
            <div style={{ fontSize: 40 }}>{editing.poster}</div>
            <div>
              <div style={{ fontWeight: 700, color: C.textPrimary }}>{editing.title}</div>
              <div style={{ fontSize: 12, color: C.textSecondary }}>{editing.year} · {editing.genre}</div>
            </div>
          </div>
          <Field label="Price (AUD)"><CInput type="number" step="0.01" value={editing.price} onChange={e => setEditing(m => ({ ...m, price: +e.target.value }))} /></Field>
          <Field label="Active">
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13, color: C.textPrimary }}>
              <input type="checkbox" checked={!!editing.active} onChange={e => setEditing(m => ({ ...m, active: e.target.checked ? 1 : 0 }))} />
              Available for purchase
            </label>
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setEditing(null)}>Cancel</Btn>
            <Btn size="sm" onClick={save}>Save</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: MESSAGES
// ─────────────────────────────────────────────────────────────────────────────
function MessagesModule({ hotel }) {
  const { C } = useTheme();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [composing, setComposing] = useState(false);
  const [form, setForm] = useState({ subject: '', body: '', target: 'all', is_emergency: false });

  const load = () => {
    setLoading(true);
    api.hotels.messages(hotel.id).then(m => { setMessages(m); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(() => { load(); }, [hotel.id]);

  const send = async () => {
    try {
      await api.hotels.sendMessage(hotel.id, form);
      setComposing(false);
      setForm({ subject: '', body: '', target: 'all', is_emergency: false });
      load();
    } catch (e) { alert(e.message); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Guest Messages</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{messages.length} messages sent</p>
        </div>
        <Btn icon={Send} size="sm" onClick={() => setComposing(true)}>New Message</Btn>
      </div>

      {loading ? <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {messages.map(msg => (
            <div key={msg.id} style={{ background: C.card, border: `1px solid ${msg.is_emergency ? C.red : C.cardBorder}`, borderRadius: 12, padding: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <div>
                  <span style={{ fontWeight: 700, fontSize: 14, color: C.textPrimary }}>{msg.subject}</span>
                  {msg.is_emergency ? <Badge label="⚠ Emergency" color={C.red} /> : null}
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <Badge label={msg.target === 'all' ? 'All Rooms' : msg.target} color={C.teal} />
                  <span style={{ fontSize: 11, color: C.textDim }}>{msg.created_at ? new Date(msg.created_at).toLocaleDateString() : ''}</span>
                </div>
              </div>
              <p style={{ margin: 0, fontSize: 13, color: C.textSecondary, lineHeight: 1.5 }}>{msg.body}</p>
            </div>
          ))}
          {messages.length === 0 && <div style={{ textAlign: 'center', color: C.textDim, padding: 40, fontSize: 14 }}>No messages sent yet</div>}
        </div>
      )}

      {composing && (
        <Modal title="Send Guest Message" onClose={() => setComposing(false)}>
          <Field label="Subject"><CInput value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} placeholder="Message subject" /></Field>
          <Field label="Message">
            <textarea value={form.body} onChange={e => setForm(f => ({ ...f, body: e.target.value }))} placeholder="Message body..." rows={4}
              style={{ width: '100%', padding: '9px 11px', background: C.input, border: `1px solid ${C.inputBorder}`, borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans',sans-serif", boxSizing: 'border-box', outline: 'none', resize: 'vertical' }} />
          </Field>
          <Field label="Target">
            <CSelect value={form.target} onChange={e => setForm(f => ({ ...f, target: e.target.value }))}>
              <option value="all">All Rooms</option>
              <option value="occupied">Occupied Rooms Only</option>
            </CSelect>
          </Field>
          <Field label="">
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13, color: C.textPrimary }}>
              <input type="checkbox" checked={form.is_emergency} onChange={e => setForm(f => ({ ...f, is_emergency: e.target.checked }))} />
              <span style={{ color: C.red, fontWeight: 600 }}>Emergency Broadcast</span>
            </label>
          </Field>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => setComposing(false)}>Cancel</Btn>
            <Btn size="sm" icon={Send} onClick={send} disabled={!form.subject || !form.body}>Send Message</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: MINIBAR
// ─────────────────────────────────────────────────────────────────────────────
function MinibarModule({ hotel }) {
  const { C } = useTheme();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: '', category: 'Beverage', cost_price: '', sell_price: '', icon: '🍶', location: 'Mini Fridge' });

  const load = () => {
    setLoading(true);
    api.hotels.minibar(hotel.id).then(i => { setItems(i); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(() => { load(); }, [hotel.id]);

  const save = async () => {
    try {
      if (editing) await api.hotels.updateMinibarItem(hotel.id, editing.id, editing);
      else await api.hotels.createMinibarItem(hotel.id, form);
      setEditing(null); setAdding(false);
      setForm({ name: '', category: 'Beverage', cost_price: '', sell_price: '', icon: '🍶', location: 'Mini Fridge' });
      load();
    } catch (e) { alert(e.message); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Minibar Menu</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{items.length} items configured</p>
        </div>
        <Btn icon={Plus} size="sm" onClick={() => setAdding(true)}>Add Item</Btn>
      </div>

      {loading ? <div style={{ color: C.textDim, textAlign: 'center', padding: 40 }}>Loading...</div> : (
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: C.tableHeader }}>
                {['', 'Item', 'Category', 'Location', 'Cost', 'Sell Price', 'Margin', ''].map(h => (
                  <th key={h} style={{ padding: '11px 16px', textAlign: 'left', fontSize: 11, fontWeight: 600, color: C.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, borderBottom: `1px solid ${C.border}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {items.map((item, i) => {
                const margin = item.cost_price > 0 ? Math.round(((item.sell_price - item.cost_price) / item.sell_price) * 100) : null;
                return (
                  <tr key={item.id} style={{ background: i % 2 === 0 ? C.tableRow : C.tableRowAlt }}>
                    <td style={{ padding: '11px 16px', fontSize: 22, borderBottom: `1px solid ${C.border}` }}>{item.icon}</td>
                    <td style={{ padding: '11px 16px', fontWeight: 600, color: C.textPrimary, fontSize: 13, borderBottom: `1px solid ${C.border}` }}>{item.name}</td>
                    <td style={{ padding: '11px 16px', fontSize: 13, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>{item.category}</td>
                    <td style={{ padding: '11px 16px', fontSize: 13, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>{item.location}</td>
                    <td style={{ padding: '11px 16px', fontSize: 13, color: C.textSecondary, borderBottom: `1px solid ${C.border}` }}>${item.cost_price?.toFixed(2)}</td>
                    <td style={{ padding: '11px 16px', fontSize: 13, fontWeight: 700, color: C.teal, borderBottom: `1px solid ${C.border}` }}>${item.sell_price?.toFixed(2)}</td>
                    <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}>
                      {margin !== null && <Badge label={`${margin}%`} color={margin > 60 ? C.green : margin > 40 ? C.amber : C.red} />}
                    </td>
                    <td style={{ padding: '11px 16px', borderBottom: `1px solid ${C.border}` }}><Btn icon={Edit} variant="ghost" size="xs" onClick={() => setEditing({ ...item })}>Edit</Btn></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {(editing || adding) && (
        <Modal title={editing ? 'Edit Item' : 'Add Minibar Item'} onClose={() => { setEditing(null); setAdding(false); }}>
          {[
            ['Name', 'name', 'text', 'Item name'],
            ['Icon (emoji)', 'icon', 'text', '🍺'],
            ['Category', 'category', 'text', 'Beverage / Snack'],
            ['Location', 'location', 'text', 'Mini Fridge / Cabinet'],
            ['Cost Price', 'cost_price', 'number', '0.00'],
            ['Sell Price', 'sell_price', 'number', '0.00'],
          ].map(([label, key, type, ph]) => {
            const src = editing || form;
            const upd = editing ? e => setEditing(x => ({ ...x, [key]: type === 'number' ? +e.target.value : e.target.value }))
                                : e => setForm(x => ({ ...x, [key]: type === 'number' ? +e.target.value : e.target.value }));
            return <Field key={key} label={label}><CInput type={type} value={src[key]} onChange={upd} placeholder={ph} step={type === 'number' ? '0.01' : undefined} /></Field>;
          })}
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
            <Btn variant="secondary" size="sm" onClick={() => { setEditing(null); setAdding(false); }}>Cancel</Btn>
            <Btn size="sm" onClick={save}>Save</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: REPORTS (placeholder)
// ─────────────────────────────────────────────────────────────────────────────
function ReportsModule({ hotel }) {
  const { C } = useTheme();
  return (
    <div>
      <h2 style={{ margin: '0 0 8px', fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Reports</h2>
      <p style={{ margin: '0 0 28px', fontSize: 13, color: C.textSecondary }}>Analytics and usage reporting</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 16, marginBottom: 28 }}>
        {[
          { label: 'VOD Revenue',     icon: TrendingUp, value: '$482',  sub: 'This month',       color: C.teal   },
          { label: 'Channel Views',   icon: Tv,         value: '1,247', sub: 'This week',         color: C.blue   },
          { label: 'Device Uptime',   icon: Activity,   value: '99.1%', sub: 'Last 30 days',      color: C.green  },
          { label: 'Msg Open Rate',   icon: Bell,       value: '87%',   sub: 'Last 10 messages',  color: C.purple },
        ].map(s => <StatCard key={s.label} {...s} />)}
      </div>
      <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 40, textAlign: 'center' }}>
        <BarChart2 size={48} color={C.textDim} style={{ marginBottom: 12 }} />
        <div style={{ fontSize: 16, fontWeight: 600, color: C.textSecondary, marginBottom: 6 }}>Detailed Reports Coming Soon</div>
        <div style={{ fontSize: 13, color: C.textDim }}>Revenue charts, channel viewership, device uptime, and message analytics will be available here.</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: streamSTUDIO (placeholder)
// ─────────────────────────────────────────────────────────────────────────────
function StudioModule({ hotel }) {
  const { C } = useTheme();
  const options = [
    { icon: '📁', label: 'My Content',      desc: 'Upload and stream pre-recorded content from your library' },
    { icon: '🌐', label: 'Internet Stream', desc: 'Push any RTMP/HLS stream from an external source' },
    { icon: '▶️', label: 'YouTube Live',    desc: 'Connect your YouTube Live channel and stream directly' },
  ];
  return (
    <div>
      <h2 style={{ margin: '0 0 8px', fontSize: 22, fontWeight: 700, color: C.textPrimary }}>streamSTUDIO</h2>
      <p style={{ margin: '0 0 28px', fontSize: 13, color: C.textSecondary }}>Broadcast live or on-demand content directly to in-room TVs</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16, marginBottom: 28 }}>
        {options.map(opt => (
          <div key={opt.label} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 24, cursor: 'not-allowed', opacity: 0.7 }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>{opt.icon}</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: C.textPrimary, marginBottom: 6 }}>{opt.label}</div>
            <div style={{ fontSize: 13, color: C.textSecondary }}>{opt.desc}</div>
          </div>
        ))}
      </div>
      <div style={{ background: C.tealDim, border: `1px solid ${C.tealMid}`, borderRadius: 12, padding: 20, display: 'flex', alignItems: 'center', gap: 14 }}>
        <Zap size={24} color={C.teal} />
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: C.teal }}>Coming in v2.1</div>
          <div style={{ fontSize: 13, color: C.textSecondary }}>streamSTUDIO will enable live broadcasting, scheduled streams, and interactive content delivery to all in-room devices.</div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE: SETTINGS
// ─────────────────────────────────────────────────────────────────────────────
function SettingsModule({ hotel }) {
  const { C, mode, setMode } = useTheme();
  return (
    <div>
      <h2 style={{ margin: '0 0 8px', fontSize: 22, fontWeight: 700, color: C.textPrimary }}>Settings</h2>
      <p style={{ margin: '0 0 28px', fontSize: 13, color: C.textSecondary }}>System and property configuration</p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 24 }}>
          <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700, color: C.textPrimary }}>Property Info</h3>
          {[
            ['Hotel Name', hotel.name],
            ['Property Code', hotel.code],
            ['City', hotel.city],
            ['Country', hotel.country],
            ['Timezone', hotel.timezone],
            ['Total Rooms', hotel.total_rooms],
          ].map(([label, val]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: `1px solid ${C.border}`, fontSize: 13 }}>
              <span style={{ color: C.textSecondary }}>{label}</span>
              <span style={{ color: C.textPrimary, fontWeight: 500 }}>{val || '—'}</span>
            </div>
          ))}
        </div>

        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 24 }}>
          <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700, color: C.textPrimary }}>Interface</h3>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 13, color: C.textSecondary, marginBottom: 10 }}>Theme Mode</div>
            <div style={{ display: 'flex', gap: 8 }}>
              {['light', 'auto', 'dark'].map(m => (
                <button key={m} onClick={() => setMode(m)} style={{
                  padding: '7px 16px', borderRadius: 8, border: `1px solid ${mode === m ? C.teal : C.border}`,
                  background: mode === m ? C.tealDim : 'transparent', color: mode === m ? C.teal : C.textSecondary,
                  cursor: 'pointer', fontWeight: 600, fontSize: 13, fontFamily: "'DM Sans',sans-serif", textTransform: 'capitalize'
                }}>{m}</button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SIDEBAR
// ─────────────────────────────────────────────────────────────────────────────
function Sidebar({ active, onNavigate, hotel, onLogout, version, onSwitchHotel }) {
  const { C } = useTheme();
  const SB = { bg: '#0d1117', text: '#8899b4', active: C.teal, hover: '#161d2e', border: '#1e2d45' };

  return (
    <div style={{ width: 228, background: SB.bg, display: 'flex', flexDirection: 'column', height: '100vh', position: 'fixed', left: 0, top: 0, borderRight: `1px solid ${SB.border}`, overflow: 'hidden', flexShrink: 0 }}>
      {/* Logo */}
      <div style={{ padding: '20px 18px 16px', borderBottom: `1px solid ${SB.border}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: C.teal, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Tv size={17} color="#07080f" />
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 800, color: '#f1f5f9', letterSpacing: -0.3 }}>streamvision</div>
            <div style={{ fontSize: 10, color: SB.text, letterSpacing: 0.8, textTransform: 'uppercase' }}>Property CMS</div>
          </div>
        </div>
      </div>

      {/* Hotel */}
      <div style={{ padding: '10px 14px', borderBottom: `1px solid ${SB.border}` }}>
        <div style={{ background: SB.hover, borderRadius: 8, padding: '8px 12px' }}>
          <div style={{ fontSize: 11, color: SB.text, textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 2 }}>Current Property</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#f1f5f9', lineHeight: 1.2 }}>{hotel?.name || 'Unknown'}</div>
          {hotel?.city && <div style={{ fontSize: 11, color: SB.text, marginTop: 1 }}>{hotel.city}</div>}
        </div>
        {onSwitchHotel && (
          <button onClick={onSwitchHotel} style={{ width: '100%', marginTop: 6, padding: '5px 12px', background: 'transparent', border: `1px solid ${SB.border}`, borderRadius: 6, color: SB.text, fontSize: 11, cursor: 'pointer', fontFamily: "'DM Sans',sans-serif", fontWeight: 500 }}>
            Switch Property
          </button>
        )}
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, overflowY: 'auto', padding: '8px 10px' }}>
        {SECTIONS.map(sec => {
          const items = NAV.filter(n => n.section === sec.id);
          return (
            <div key={sec.id} style={{ marginBottom: 4 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: SB.border, letterSpacing: 1.2, padding: '10px 8px 4px', textTransform: 'uppercase' }}>{sec.label}</div>
              {items.map(item => {
                const isActive = active === item.id;
                return (
                  <button key={item.id} onClick={() => onNavigate(item.id)} style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: 9, padding: '7px 10px',
                    borderRadius: 7, border: 'none', cursor: 'pointer', fontFamily: "'DM Sans',sans-serif",
                    fontSize: 13, fontWeight: isActive ? 600 : 400,
                    background: isActive ? C.teal + '1a' : 'transparent',
                    color: isActive ? SB.active : SB.text, marginBottom: 1,
                    transition: 'all 0.15s',
                  }}>
                    {isActive && <div style={{ position: 'absolute', left: 10, width: 3, height: 20, borderRadius: 2, background: C.teal }} />}
                    <item.icon size={15} />
                    {item.label}
                  </button>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div style={{ padding: '12px 14px', borderTop: `1px solid ${SB.border}` }}>
        <button onClick={onLogout} style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px',
          background: 'transparent', border: 'none', cursor: 'pointer', color: SB.text,
          fontSize: 13, fontFamily: "'DM Sans',sans-serif", borderRadius: 7
        }}>
          <LogOut size={14} />
          Sign Out
        </button>
        <div style={{ fontSize: 10, color: SB.border, marginTop: 6, paddingLeft: 10 }}>v{version} · streamvision CMS</div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// TOP BAR
// ─────────────────────────────────────────────────────────────────────────────
function TopBar({ module, hotel }) {
  const { C } = useTheme();
  const navItem = NAV.find(n => n.id === module);

  return (
    <div style={{
      height: 56, background: C.panel, borderBottom: `1px solid ${C.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 28px', flexShrink: 0
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {navItem && <navItem.icon size={16} color={C.teal} />}
        <h1 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: C.textPrimary }}>{navItem?.label || 'CMS'}</h1>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <ThemeToggle />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN CMS COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export default function CMS({ hotel }) {
  const { C } = useTheme();
  const { user, logout, setActiveHotel, version } = useAuth();
  const [activeModule, setActiveModule] = useState('dashboard');

  const handleSwitchHotel = () => {
    setActiveHotel(null);
  };

  const showSwitch = user.role === 'group_admin' || (user.accessibleHotels && user.accessibleHotels.length > 1);

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard': return <Dashboard hotel={hotel} onNavigate={setActiveModule} />;
      case 'rooms':     return <RoomsModule hotel={hotel} />;
      case 'devices':   return <DevicesModule hotel={hotel} />;
      case 'channels':  return <ChannelsModule hotel={hotel} />;
      case 'movies':    return <MoviesModule hotel={hotel} />;
      case 'messages':  return <MessagesModule hotel={hotel} />;
      case 'minibar':   return <MinibarModule hotel={hotel} />;
      case 'signage':   return <SignageModule hotelId={hotel.id} />;
      case 'portal':    return <PortalDesigner hotelId={hotel.id} />;
      case 'studio':    return <StudioModule hotel={hotel} />;
      case 'reports':   return <ReportsModule hotel={hotel} />;
      case 'settings':  return <SettingsModule hotel={hotel} />;
      default:          return <Dashboard hotel={hotel} onNavigate={setActiveModule} />;
    }
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: C.bg, fontFamily: "'DM Sans', sans-serif" }}>
      <Sidebar
        active={activeModule}
        onNavigate={setActiveModule}
        hotel={hotel}
        onLogout={logout}
        version={version || '1.0.2'}
        onSwitchHotel={showSwitch ? handleSwitchHotel : null}
      />

      {/* Main content area — offset by sidebar width */}
      <div style={{ marginLeft: 228, flex: 1, display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <TopBar module={activeModule} hotel={hotel} />
        <main style={{ flex: 1, padding: 28, overflowY: 'auto' }}>
          {renderModule()}
        </main>
      </div>
    </div>
  );
}
