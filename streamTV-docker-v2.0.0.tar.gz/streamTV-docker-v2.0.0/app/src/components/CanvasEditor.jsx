import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Type, Image, Video, Tv, Clock, Cloud, Rss, PlayCircle, Film, Square,
  Trash2, Copy, ChevronUp, ChevronDown, Lock, EyeOff, Eye, ZoomIn,
  ZoomOut, Grid, Magnet, RotateCcw, AlignLeft, AlignCenter, AlignRight,
  Bold, Italic, Underline, Plus, X, Layers, Plane, Share2, MousePointer,
  Megaphone, Users, Newspaper, QrCode, StretchHorizontal
} from 'lucide-react';

const GRID = 10;
let _idCounter = 1000;
const genId = () => `el_${++_idCounter}_${Date.now()}`;

// ─── WIDGET CATALOGUE ─────────────────────────────────────────────────────────
export const SIGNAGE_WIDGETS = [
  { group: 'Text & Content', items: [
    { type: 'text', label: 'Text Block', icon: '📝', w: 400, h: 80, defaults: { text: 'Your text here', fontSize: 32, fontFamily: 'DM Sans', fontWeight: '400', fontStyle: 'normal', textDecoration: 'none', color: '#ffffff', bgColor: 'transparent', textAlign: 'left', letterSpacing: 0, lineHeight: 1.3, padding: 8 } },
    { type: 'headline', label: 'Headline', icon: 'H₁', w: 700, h: 110, defaults: { text: 'Big Headline', fontSize: 72, fontFamily: 'DM Sans', fontWeight: '800', fontStyle: 'normal', textDecoration: 'none', color: '#ffffff', bgColor: 'transparent', textAlign: 'center', letterSpacing: -2, lineHeight: 1.0, padding: 0 } },
    { type: 'rss', label: 'RSS Ticker', icon: '📰', w: 800, h: 70, defaults: { url: '', title: 'Breaking News', speed: 40, color: '#ffffff', bgColor: '#00000088', fontSize: 22, label: 'NEWS' } },
    { type: 'social', label: 'Social Feed', icon: '📱', w: 380, h: 480, defaults: { platform: 'instagram', handle: '@yourhotel', bgColor: '#00000055', color: '#ffffff', postsCount: 4 } },
  ]},
  { group: 'Media', items: [
    { type: 'image', label: 'Image', icon: '🖼', w: 600, h: 400, defaults: { src: null, objectFit: 'cover', opacity: 100, radius: 0, label: 'Image Placeholder' } },
    { type: 'video', label: 'Video', icon: '🎥', w: 640, h: 360, defaults: { src: null, autoplay: true, loop: true, muted: true, opacity: 100, label: 'Video Placeholder' } },
    { type: 'slideshow', label: 'Slideshow', icon: '🎞', w: 640, h: 480, defaults: { assets: [], interval: 5000, transition: 'fade', showDots: true } },
  ]},
  { group: 'Hotel & Venue', items: [
    { type: 'livetv', label: 'Live TV Channel', icon: '📺', w: 640, h: 360, defaults: { channelName: 'Select Channel', channelId: null, showOverlay: true, showChannelName: true } },
    { type: 'movie', label: 'Movie Feature', icon: '🎬', w: 280, h: 420, defaults: { title: 'Dune: Part Two', year: 2024, rating: 8.5, price: 6.99, poster: '🏜️', genre: 'Sci-Fi', showDetails: true, bgColor: '#000000' } },
    { type: 'flight', label: 'Flight Board', icon: '✈️', w: 900, h: 400, defaults: { airport: 'Darwin (DRW)', type: 'departures', maxRows: 6, bgColor: '#000e1a', color: '#ffffff', headerBg: '#001f3d' } },
    { type: 'menuboard', label: 'Menu Board', icon: '🍽', w: 500, h: 600, defaults: { title: "Today's Menu", bgColor: '#1a0a00', color: '#f5deb3', accentColor: '#d4a030' } },
  ]},
  { group: 'Widgets', items: [
    { type: 'clock', label: 'Clock', icon: '🕐', w: 380, h: 130, defaults: { format: '12h', showDate: true, showSeconds: true, fontSize: 76, fontFamily: 'DM Sans', fontWeight: '300', color: '#ffffff', bgColor: 'transparent', dateFormat: 'full' } },
    { type: 'weather', label: 'Weather', icon: '⛅', w: 320, h: 200, defaults: { location: 'Darwin, AU', units: 'celsius', style: 'minimal', color: '#ffffff', bgColor: 'transparent', temp: 31, condition: 'Partly Cloudy', icon: '⛅' } },
    { type: 'shape', label: 'Shape', icon: '⬛', w: 200, h: 10, defaults: { shape: 'rectangle', fillColor: '#ffffff', opacity: 30, radius: 0 } },
    { type: 'qr', label: 'QR Code', icon: '◼◻', w: 200, h: 220, defaults: { content: 'https://streamvision.com.au', label: 'Scan to connect', bgColor: '#ffffff', fgColor: '#000000', showLabel: true } },
  ]},
];

export const PORTAL_WIDGETS = [
  { group: 'Navigation', items: [
    { type: 'button', label: 'Button', icon: '🔘', w: 260, h: 72, defaults: { text: 'Guest Services', linkTo: null, style: 'filled', bgColor: '#00d4aa', textColor: '#000000', fontSize: 20, fontWeight: '600', radius: 12, animation: 'none', iconEmoji: '🛎', showIcon: true } },
    { type: 'navtile', label: 'Nav Tile', icon: '⬛', w: 200, h: 200, defaults: { text: 'Movies', iconEmoji: '🎬', linkTo: null, bgColor: '#1c2a3d', textColor: '#ffffff', radius: 16, fontSize: 22, fontWeight: '700' } },
    { type: 'backbtn', label: 'Back Button', icon: '⬅', w: 130, h: 50, defaults: { text: '← Back', bgColor: '#ffffff22', textColor: '#ffffff', fontSize: 16, radius: 8, linkTo: '__back__' } },
  ]},
  { group: 'Guest Info', items: [
    { type: 'guestname', label: 'Guest Name', icon: '👤', w: 500, h: 80, defaults: { prefix: 'Welcome,', suffix: '', fontSize: 42, fontWeight: '700', color: '#ffffff', bgColor: 'transparent', mockName: 'James T.' } },
    { type: 'roominfo', label: 'Room Info', icon: '🛏', w: 300, h: 110, defaults: { showNumber: true, showType: true, showFloor: true, fontSize: 28, color: '#ffffff', bgColor: 'transparent', mockRoom: '203', mockType: 'Deluxe', mockFloor: '2' } },
    { type: 'weather', label: 'Weather', icon: '⛅', w: 280, h: 170, defaults: { location: 'Darwin, AU', units: 'celsius', color: '#ffffff', bgColor: 'transparent', temp: 31, condition: 'Partly Cloudy', icon: '⛅' } },
    { type: 'datetime', label: 'Date & Time', icon: '📅', w: 380, h: 90, defaults: { format: '12h', showDate: true, fontSize: 38, color: '#ffffff', bgColor: 'transparent', fontWeight: '300' } },
  ]},
  { group: 'Content', items: [
    { type: 'text', label: 'Text Block', icon: '📝', w: 400, h: 80, defaults: { text: 'Welcome to your room', fontSize: 28, fontFamily: 'DM Sans', fontWeight: '400', color: '#ffffff', bgColor: 'transparent', textAlign: 'left', letterSpacing: 0, lineHeight: 1.3, padding: 8 } },
    { type: 'image', label: 'Image', icon: '🖼', w: 500, h: 350, defaults: { src: null, objectFit: 'cover', opacity: 100, radius: 12, label: 'Hotel Image' } },
    { type: 'ads', label: 'Ad Panel', icon: '📢', w: 400, h: 200, defaults: { schedule: [], bgColor: '#000', label: 'Advertising Space', accentColor: '#f59e0b' } },
    { type: 'news', label: 'News Ticker', icon: '📰', w: 600, h: 64, defaults: { speed: 40, bgColor: '#00000088', color: '#ffffff', fontSize: 20, label: 'NEWS' } },
  ]},
];

// ─── LIVE ELEMENT RENDERERS ───────────────────────────────────────────────────
function ClockWidget({ p }) {
  const [t, setT] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setT(new Date()), 1000); return () => clearInterval(i); }, []);
  const h = p.format === '12h' ? (t.getHours() % 12 || 12) : t.getHours().toString().padStart(2, '0');
  const m = t.getMinutes().toString().padStart(2, '0');
  const s = t.getSeconds().toString().padStart(2, '0');
  const ap = t.getHours() >= 12 ? 'PM' : 'AM';
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: p.bgColor || 'transparent', color: p.color, fontFamily: p.fontFamily }}>
      <div style={{ fontSize: p.fontSize, fontWeight: p.fontWeight, lineHeight: 1, display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span>{h}:{m}</span>
        {p.showSeconds && <span style={{ fontSize: p.fontSize * 0.45, opacity: 0.7 }}>:{s}</span>}
        {p.format === '12h' && <span style={{ fontSize: p.fontSize * 0.3, marginLeft: 6, opacity: 0.8 }}>{ap}</span>}
      </div>
      {p.showDate && <div style={{ fontSize: p.fontSize * 0.28, marginTop: 6, opacity: 0.75 }}>{t.toLocaleDateString('en-AU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>}
    </div>
  );
}

function FlightWidget({ p }) {
  const flights = [
    { time: '14:35', dest: 'Sydney (SYD)', flight: 'QF 701', gate: 'A4', status: 'On Time', terminal: 'T1' },
    { time: '15:10', dest: 'Melbourne (MEL)', flight: 'VA 831', gate: 'B2', status: 'On Time', terminal: 'T1' },
    { time: '15:45', dest: 'Brisbane (BNE)', flight: 'QF 405', gate: 'A7', status: 'Delayed', terminal: 'T1' },
    { time: '16:20', dest: 'Alice Springs (ASP)', flight: 'NT 123', gate: 'A1', status: 'On Time', terminal: 'T1' },
    { time: '17:00', dest: 'Perth (PER)', flight: 'QF 573', gate: 'C3', status: 'Boarding', terminal: 'T2' },
    { time: '17:30', dest: 'Singapore (SIN)', flight: 'SQ 232', gate: 'B5', status: 'On Time', terminal: 'T2' },
  ].slice(0, p.maxRows || 5);
  return (
    <div style={{ width: '100%', height: '100%', background: p.bgColor || '#000e1a', color: p.color || '#fff', fontFamily: 'DM Sans', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: p.headerBg || '#001f3d', padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 10, fontSize: 16, fontWeight: 700 }}>
        <span>✈️</span><span>{p.airport || 'Darwin (DRW)'}</span><span style={{ marginLeft: 'auto', fontSize: 13, opacity: 0.7 }}>{p.type === 'arrivals' ? 'ARRIVALS' : 'DEPARTURES'}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '70px 1fr 100px 60px 90px', padding: '4px 12px', fontSize: 11, opacity: 0.55, borderBottom: '1px solid #ffffff22', gap: 8 }}>
        {['TIME', 'DESTINATION', 'FLIGHT', 'GATE', 'STATUS'].map(h => <span key={h}>{h}</span>)}
      </div>
      {flights.map((f, i) => (
        <div key={i} style={{ display: 'grid', gridTemplateColumns: '70px 1fr 100px 60px 90px', padding: '7px 12px', fontSize: 14, borderBottom: '1px solid #ffffff11', gap: 8, background: i % 2 ? '#ffffff05' : 'transparent' }}>
          <span style={{ fontWeight: 700, color: '#4fc3f7' }}>{f.time}</span>
          <span>{f.dest}</span>
          <span style={{ opacity: 0.8 }}>{f.flight}</span>
          <span style={{ fontWeight: 700, color: '#81c784' }}>{f.gate}</span>
          <span style={{ color: f.status === 'Delayed' ? '#ff7043' : f.status === 'Boarding' ? '#ffd54f' : '#81c784', fontWeight: 600, fontSize: 12 }}>{f.status}</span>
        </div>
      ))}
    </div>
  );
}

function MovieWidget({ p }) {
  return (
    <div style={{ width: '100%', height: '100%', background: p.bgColor || '#000', display: 'flex', flexDirection: 'column', overflow: 'hidden', fontFamily: 'DM Sans', position: 'relative' }}>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 80 }}>{p.poster || '🎬'}</div>
      {p.showDetails && (
        <div style={{ padding: '10px 12px', background: 'linear-gradient(transparent, #000000cc)' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#fff', marginBottom: 3 }}>{p.title}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 11, color: '#f59e0b' }}>★ {p.rating}</span>
            <span style={{ fontSize: 11, color: '#999' }}>{p.year} · {p.genre}</span>
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#00d4aa' }}>${p.price}</div>
        </div>
      )}
    </div>
  );
}

function WeatherWidget({ p }) {
  return (
    <div style={{ width: '100%', height: '100%', background: p.bgColor || 'transparent', color: p.color || '#fff', fontFamily: 'DM Sans', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
      <div style={{ fontSize: 44 }}>{p.icon || '⛅'}</div>
      <div style={{ fontSize: 42, fontWeight: '700', lineHeight: 1 }}>{p.temp || 31}°{p.units === 'fahrenheit' ? 'F' : 'C'}</div>
      <div style={{ fontSize: 16, opacity: 0.85 }}>{p.condition || 'Partly Cloudy'}</div>
      <div style={{ fontSize: 13, opacity: 0.6 }}>{p.location || 'Darwin, AU'}</div>
    </div>
  );
}

function RssWidget({ p }) {
  const [offset, setOffset] = useState(0);
  const text = `${p.label || 'NEWS'}: Breaking news — Top headlines from around the world. Market update: ASX closes higher. Weather alert issued for northern regions. Sports: Local team advances to finals.`;
  useEffect(() => {
    const i = setInterval(() => setOffset(o => (o - 1) % (text.length * 14)), 30); return () => clearInterval(i);
  }, []);
  return (
    <div style={{ width: '100%', height: '100%', background: p.bgColor || '#00000088', color: p.color || '#fff', display: 'flex', alignItems: 'center', overflow: 'hidden', fontFamily: 'DM Sans' }}>
      <div style={{ background: '#ef444488', padding: '0 12px', height: '100%', display: 'flex', alignItems: 'center', fontSize: p.fontSize * 0.6 || 14, fontWeight: 700, flexShrink: 0, minWidth: 70 }}>{p.label || 'NEWS'}</div>
      <div style={{ overflow: 'hidden', flex: 1, padding: '0 14px' }}>
        <div style={{ fontSize: p.fontSize || 22, whiteSpace: 'nowrap', animation: `ticker ${80 / (p.speed || 40)}s linear infinite` }}>
          {text} &nbsp;&nbsp;&nbsp; {text}
        </div>
      </div>
      <style>{`@keyframes ticker { from { transform: translateX(100%) } to { transform: translateX(-200%) } }`}</style>
    </div>
  );
}

function DateTimeWidget({ p }) {
  const [t, setT] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setT(new Date()), 1000); return () => clearInterval(i); }, []);
  const h = p.format === '12h' ? (t.getHours() % 12 || 12) : t.getHours().toString().padStart(2, '0');
  const m = t.getMinutes().toString().padStart(2, '0');
  const ap = t.getHours() >= 12 ? 'PM' : 'AM';
  return (
    <div style={{ width: '100%', height: '100%', background: p.bgColor || 'transparent', color: p.color || '#fff', fontFamily: 'DM Sans', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 8px' }}>
      <div style={{ fontSize: p.fontSize || 38, fontWeight: p.fontWeight || '300', lineHeight: 1 }}>{h}:{m} {p.format === '12h' ? ap : ''}</div>
      {p.showDate && <div style={{ fontSize: (p.fontSize || 38) * 0.38, opacity: 0.7, marginTop: 4 }}>{t.toLocaleDateString('en-AU', { weekday: 'short', day: 'numeric', month: 'long' })}</div>}
    </div>
  );
}

function renderElementContent(el) {
  const p = el.props;
  switch (el.type) {
    case 'text': case 'headline': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || 'transparent', padding: p.padding || 0, boxSizing: 'border-box', display: 'flex', alignItems: 'center', overflow: 'hidden' }}>
        <div style={{ fontSize: p.fontSize, fontFamily: p.fontFamily || 'DM Sans', fontWeight: p.fontWeight || '400', fontStyle: p.fontStyle || 'normal', textDecoration: p.textDecoration || 'none', color: p.color || '#fff', textAlign: p.textAlign || 'left', letterSpacing: p.letterSpacing || 0, lineHeight: p.lineHeight || 1.3, width: '100%' }}>{p.text || 'Text'}</div>
      </div>
    );
    case 'clock': return <ClockWidget p={p} />;
    case 'weather': return <WeatherWidget p={p} />;
    case 'flight': return <FlightWidget p={p} />;
    case 'movie': return <MovieWidget p={p} />;
    case 'rss': case 'news': return <RssWidget p={p} />;
    case 'datetime': return <DateTimeWidget p={p} />;
    case 'livetv': return (
      <div style={{ width: '100%', height: '100%', background: '#000', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, color: '#fff', fontFamily: 'DM Sans' }}>
        <div style={{ fontSize: 40 }}>📺</div>
        <div style={{ fontSize: 14, fontWeight: 600 }}>{p.channelName || 'Live TV Channel'}</div>
        {p.showChannelName && <div style={{ fontSize: 11, opacity: 0.5 }}>LIVE STREAM</div>}
      </div>
    );
    case 'image': return (
      <div style={{ width: '100%', height: '100%', background: '#1a2040', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, color: '#ffffff55', fontFamily: 'DM Sans', opacity: (p.opacity || 100) / 100, borderRadius: p.radius || 0 }}>
        <div style={{ fontSize: 32 }}>🖼</div>
        <div style={{ fontSize: 12 }}>{p.label || 'Image'}</div>
      </div>
    );
    case 'video': return (
      <div style={{ width: '100%', height: '100%', background: '#0a0a0a', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, color: '#ffffff44', fontFamily: 'DM Sans', opacity: (p.opacity || 100) / 100 }}>
        <div style={{ fontSize: 32 }}>🎥</div>
        <div style={{ fontSize: 12 }}>{p.label || 'Video'}</div>
        {p.loop && <div style={{ fontSize: 10, color: '#00d4aa' }}>LOOP · AUTOPLAY</div>}
      </div>
    );
    case 'slideshow': return (
      <div style={{ width: '100%', height: '100%', background: '#0f1a2a', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, color: '#ffffff44', fontFamily: 'DM Sans' }}>
        <div style={{ fontSize: 32 }}>🎞</div>
        <div style={{ fontSize: 12 }}>Slideshow ({p.assets?.length || 0} slides)</div>
        <div style={{ fontSize: 10, color: '#7d93b5' }}>Interval: {(p.interval || 5000) / 1000}s · {p.transition || 'fade'}</div>
      </div>
    );
    case 'shape': return (
      <div style={{ width: '100%', height: '100%', background: p.fillColor || '#3b82f6', opacity: (p.opacity || 80) / 100, borderRadius: p.radius || 0 }} />
    );
    case 'qr': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 12, boxSizing: 'border-box', fontFamily: 'DM Sans' }}>
        <div style={{ width: '70%', aspectRatio: '1', background: p.fgColor || '#000', display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 2, padding: 8, boxSizing: 'border-box' }}>
          {[1,0,1,0,1, 0,1,0,1,0, 1,0,1,0,1, 0,1,0,1,0, 1,0,1,0,1].map((v,i) => <div key={i} style={{ background: v ? (p.fgColor||'#000') : (p.bgColor||'#fff') }} />)}
        </div>
        {p.showLabel && <div style={{ fontSize: 10, marginTop: 4, color: p.fgColor || '#000' }}>{p.label || 'Scan to connect'}</div>}
      </div>
    );
    case 'guestname': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || 'transparent', color: p.color || '#fff', fontFamily: 'DM Sans', display: 'flex', alignItems: 'center', padding: '0 4px' }}>
        <span style={{ fontSize: p.fontSize || 42, fontWeight: p.fontWeight || '700' }}>{p.prefix || 'Welcome,'} {p.mockName || 'James T.'}</span>
      </div>
    );
    case 'roominfo': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || 'transparent', color: p.color || '#fff', fontFamily: 'DM Sans', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 4px', gap: 2 }}>
        {p.showNumber && <div style={{ fontSize: p.fontSize || 28, fontWeight: 700 }}>Room {p.mockRoom || '203'}</div>}
        {p.showType && <div style={{ fontSize: (p.fontSize || 28) * 0.55, opacity: 0.7 }}>{p.mockType || 'Deluxe'} · Floor {p.mockFloor || '2'}</div>}
      </div>
    );
    case 'button': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || '#00d4aa', borderRadius: p.radius || 12, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, cursor: 'pointer', fontFamily: 'DM Sans' }}>
        {p.showIcon && p.iconEmoji && <span style={{ fontSize: p.fontSize * 0.9 || 20 }}>{p.iconEmoji}</span>}
        <span style={{ fontSize: p.fontSize || 20, fontWeight: p.fontWeight || '600', color: p.textColor || '#000' }}>{p.text || 'Button'}</span>
      </div>
    );
    case 'navtile': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || '#1c2a3d', borderRadius: p.radius || 16, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, fontFamily: 'DM Sans' }}>
        <div style={{ fontSize: 44 }}>{p.iconEmoji || '🎬'}</div>
        <div style={{ fontSize: p.fontSize || 22, fontWeight: p.fontWeight || '700', color: p.textColor || '#fff' }}>{p.text || 'Menu Item'}</div>
      </div>
    );
    case 'backbtn': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || '#ffffff22', borderRadius: p.radius || 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'DM Sans' }}>
        <span style={{ fontSize: p.fontSize || 16, fontWeight: 600, color: p.textColor || '#fff' }}>{p.text || '← Back'}</span>
      </div>
    );
    case 'ads': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || '#000', border: `2px dashed ${p.accentColor || '#f59e0b'}55`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'DM Sans' }}>
        <div style={{ fontSize: 24 }}>📢</div>
        <div style={{ fontSize: 13, color: p.accentColor || '#f59e0b', fontWeight: 600 }}>{p.label || 'Advertising Panel'}</div>
        <div style={{ fontSize: 10, color: '#ffffff44' }}>Scheduled content area</div>
      </div>
    );
    case 'social': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || '#0f172a', color: p.color || '#fff', fontFamily: 'DM Sans', display: 'flex', flexDirection: 'column', padding: 12, gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14, fontWeight: 700, borderBottom: '1px solid #ffffff22', paddingBottom: 8 }}>
          <span>{p.platform === 'instagram' ? '📸' : p.platform === 'twitter' ? '𝕏' : '👍'}</span>
          <span>{p.handle || '@yourhotel'}</span>
        </div>
        {[1,2,3].slice(0, Math.min(3, p.postsCount || 3)).map(i => (
          <div key={i} style={{ background: '#ffffff0a', borderRadius: 6, padding: 8, fontSize: 11, color: '#fff', opacity: 0.8 }}>📷 Latest post content #{i}</div>
        ))}
      </div>
    );
    case 'menuboard': return (
      <div style={{ width: '100%', height: '100%', background: p.bgColor || '#1a0a00', color: p.color || '#f5deb3', fontFamily: 'DM Sans', display: 'flex', flexDirection: 'column', padding: 16, gap: 8 }}>
        <div style={{ fontSize: 22, fontWeight: 700, color: p.accentColor || '#d4a030', borderBottom: `1px solid ${p.accentColor || '#d4a030'}55`, paddingBottom: 8 }}>{p.title || "Today's Menu"}</div>
        {[['Grilled Barramundi', '$28'], ['Signature Burger', '$22'], ['Garden Salad', '$16'], ['Chef\'s Special', '$34']].map(([n,pr]) => (
          <div key={n} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
            <span>{n}</span><span style={{ color: p.accentColor || '#d4a030', fontWeight: 600 }}>{pr}</span>
          </div>
        ))}
      </div>
    );
    default: return (
      <div style={{ width: '100%', height: '100%', background: '#1c2a3d', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7d93b5', fontSize: 12, fontFamily: 'DM Sans' }}>{el.type}</div>
    );
  }
}

// ─── PROPERTIES PANEL ─────────────────────────────────────────────────────────
function PropField({ label, children }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 10, fontWeight: 600, color: '#7d93b5', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 4 }}>{label}</div>
      {children}
    </div>
  );
}

const propInput = (val, onChange, type = 'text', extra = {}) => (
  <input type={type} value={val ?? ''} onChange={e => onChange(type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value)} {...extra}
    style={{ width: '100%', background: '#111b28', border: '1px solid #243553', borderRadius: 5, padding: '5px 8px', color: '#e8f0fc', fontSize: 12, fontFamily: 'DM Sans', boxSizing: 'border-box' }} />
);

const propSelect = (val, onChange, options) => (
  <select value={val} onChange={e => onChange(e.target.value)}
    style={{ width: '100%', background: '#111b28', border: '1px solid #243553', borderRadius: 5, padding: '5px 8px', color: '#e8f0fc', fontSize: 12, fontFamily: 'DM Sans' }}>
    {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
  </select>
);

function PropertiesPanel({ el, onChange, onDelete, onDuplicate, onBringForward, onSendBack, onToggleLock, onToggleVisible, pages = [] }) {
  if (!el) return (
    <div style={{ flex: '0 0 280px', borderLeft: '1px solid #243553', background: '#111b28', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#4a6080', fontSize: 13, fontFamily: 'DM Sans', padding: 20, textAlign: 'center' }}>
      Select an element to edit its properties
    </div>
  );
  const p = el.props;
  const up = (key, val) => onChange({ ...el, props: { ...p, [key]: val } });
  const upEl = (key, val) => onChange({ ...el, [key]: val });

  return (
    <div style={{ flex: '0 0 280px', borderLeft: '1px solid #243553', background: '#111b28', overflowY: 'auto', fontFamily: 'DM Sans' }}>
      <div style={{ padding: '12px 14px', borderBottom: '1px solid #243553', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: '#e8f0fc', textTransform: 'uppercase', letterSpacing: 0.6 }}>{el.type}</span>
        <div style={{ display: 'flex', gap: 3 }}>
          {[
            [el.locked ? Lock : Lock, onToggleLock, el.locked ? '#ef4444' : '#4a6080'],
            [el.visible === false ? EyeOff : Eye, onToggleVisible, el.visible === false ? '#f59e0b' : '#4a6080'],
            [Copy, onDuplicate, '#7d93b5'],
            [Trash2, onDelete, '#ef4444'],
          ].map(([Icon, action, color], i) => (
            <button key={i} onClick={action} style={{ background: 'none', border: 'none', cursor: 'pointer', color, padding: 4 }}><Icon size={13} /></button>
          ))}
        </div>
      </div>

      <div style={{ padding: 14 }}>
        {/* Position & Size */}
        <PropField label="Position & Size">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
            {[['X', el.x, v => upEl('x', v)], ['Y', el.y, v => upEl('y', v)], ['W', el.w, v => upEl('w', v)], ['H', el.h, v => upEl('h', v)]].map(([lbl, val, fn]) => (
              <div key={lbl}>
                <div style={{ fontSize: 9, color: '#4a6080', marginBottom: 2 }}>{lbl}</div>
                {propInput(Math.round(val), fn, 'number', { min: 0 })}
              </div>
            ))}
          </div>
        </PropField>

        {/* Layer */}
        <PropField label="Layer">
          <div style={{ display: 'flex', gap: 4 }}>
            {[[ChevronUp, onBringForward, 'Fwd'], [ChevronDown, onSendBack, 'Back']].map(([Icon, fn, lbl]) => (
              <button key={lbl} onClick={fn} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, background: '#1c2a3d', border: '1px solid #243553', borderRadius: 5, padding: '5px 8px', color: '#7d93b5', cursor: 'pointer', fontSize: 11, fontFamily: 'DM Sans' }}>
                <Icon size={11} />{lbl}
              </button>
            ))}
            <div style={{ display: 'flex', alignItems: 'center', fontSize: 10, color: '#4a6080', paddingLeft: 4 }}>z:{el.zIndex}</div>
          </div>
        </PropField>

        {/* Text properties */}
        {['text', 'headline', 'button', 'navtile', 'backbtn', 'guestname', 'roominfo'].includes(el.type) && (
          <>
            <PropField label="Text">
              <textarea value={p.text || ''} onChange={e => up('text', e.target.value)} rows={2}
                style={{ width: '100%', background: '#111b28', border: '1px solid #243553', borderRadius: 5, padding: '5px 8px', color: '#e8f0fc', fontSize: 12, fontFamily: 'DM Sans', resize: 'vertical', boxSizing: 'border-box' }} />
            </PropField>
            <PropField label="Font">
              {propSelect(p.fontFamily || 'DM Sans', v => up('fontFamily', v), [
                ['DM Sans', 'DM Sans'], ['Arial', 'Arial'], ['Georgia', 'Georgia'], ['Courier New', 'Courier New'],
                ['Verdana', 'Verdana'], ['Trebuchet MS', 'Trebuchet MS'], ['Impact', 'Impact'], ['Times New Roman', 'Times New Roman']
              ])}
            </PropField>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5, marginBottom: 10 }}>
              <div><div style={{ fontSize: 9, color: '#4a6080', marginBottom: 2 }}>Size</div>{propInput(p.fontSize || 24, v => up('fontSize', v), 'number', { min: 6, max: 300 })}</div>
              <div><div style={{ fontSize: 9, color: '#4a6080', marginBottom: 2 }}>Weight</div>{propSelect(p.fontWeight || '400', v => up('fontWeight', v), [['300','Light'],['400','Regular'],['500','Medium'],['600','Semibold'],['700','Bold'],['800','Extrabold']])}</div>
            </div>
            <PropField label="Style">
              <div style={{ display: 'flex', gap: 4 }}>
                {[['B', 'fontWeight', v => up('fontWeight', p.fontWeight === '700' ? '400' : '700'), p.fontWeight === '700'],
                  ['I', 'fontStyle', v => up('fontStyle', p.fontStyle === 'italic' ? 'normal' : 'italic'), p.fontStyle === 'italic'],
                  ['U', 'textDecoration', v => up('textDecoration', p.textDecoration === 'underline' ? 'none' : 'underline'), p.textDecoration === 'underline'],
                ].map(([lbl, , fn, active]) => (
                  <button key={lbl} onClick={fn} style={{ flex: 1, padding: '5px', background: active ? '#243553' : 'transparent', border: `1px solid ${active ? '#3b82f6' : '#243553'}`, borderRadius: 4, color: active ? '#3b82f6' : '#7d93b5', cursor: 'pointer', fontFamily: 'DM Sans', fontWeight: lbl === 'B' ? '700' : lbl === 'I' ? '400' : '400', fontStyle: lbl === 'I' ? 'italic' : 'normal', fontSize: 12 }}>{lbl}</button>
                ))}
              </div>
            </PropField>
            <PropField label="Alignment">
              <div style={{ display: 'flex', gap: 4 }}>
                {[['left', AlignLeft], ['center', AlignCenter], ['right', AlignRight]].map(([v, Icon]) => (
                  <button key={v} onClick={() => up('textAlign', v)} style={{ flex: 1, padding: '5px', background: p.textAlign === v ? '#243553' : 'transparent', border: `1px solid ${p.textAlign === v ? '#3b82f6' : '#243553'}`, borderRadius: 4, color: p.textAlign === v ? '#3b82f6' : '#7d93b5', cursor: 'pointer' }}>
                    <Icon size={13} />
                  </button>
                ))}
              </div>
            </PropField>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5, marginBottom: 10 }}>
              <div><div style={{ fontSize: 9, color: '#4a6080', marginBottom: 2 }}>Letter Spacing</div>{propInput(p.letterSpacing || 0, v => up('letterSpacing', v), 'number', { step: 0.5 })}</div>
              <div><div style={{ fontSize: 9, color: '#4a6080', marginBottom: 2 }}>Line Height</div>{propInput(p.lineHeight || 1.3, v => up('lineHeight', v), 'number', { step: 0.1 })}</div>
            </div>
          </>
        )}

        {/* Color */}
        {['text', 'headline', 'button', 'navtile', 'backbtn', 'guestname', 'roominfo', 'clock', 'weather', 'flight', 'shape', 'datetime', 'rss', 'news'].includes(el.type) && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5, marginBottom: 10 }}>
            <PropField label="Text Color">
              <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                <input type="color" value={p.color || p.textColor || '#ffffff'} onChange={e => up(p.textColor !== undefined ? 'textColor' : 'color', e.target.value)} style={{ width: 28, height: 28, padding: 1, background: '#111b28', border: '1px solid #243553', borderRadius: 4, cursor: 'pointer' }} />
                <span style={{ fontSize: 10, color: '#4a6080' }}>{p.color || p.textColor || '#fff'}</span>
              </div>
            </PropField>
            <PropField label="Background">
              <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                <input type="color" value={p.bgColor && p.bgColor !== 'transparent' ? p.bgColor : '#000000'} onChange={e => up('bgColor', e.target.value)} style={{ width: 28, height: 28, padding: 1, background: '#111b28', border: '1px solid #243553', borderRadius: 4, cursor: 'pointer' }} />
                <button onClick={() => up('bgColor', 'transparent')} style={{ fontSize: 9, background: p.bgColor === 'transparent' ? '#243553' : 'transparent', border: '1px solid #243553', borderRadius: 3, padding: '2px 4px', color: '#7d93b5', cursor: 'pointer', fontFamily: 'DM Sans' }}>None</button>
              </div>
            </PropField>
          </div>
        )}

        {/* Shape fill */}
        {el.type === 'shape' && (
          <PropField label="Fill Color">
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <input type="color" value={p.fillColor || '#3b82f6'} onChange={e => up('fillColor', e.target.value)} style={{ width: 32, height: 32, padding: 1, background: '#111b28', border: '1px solid #243553', borderRadius: 4, cursor: 'pointer' }} />
              {propInput(p.opacity ?? 80, v => up('opacity', v), 'number', { min: 0, max: 100, style: { width: 60 } })}
              <span style={{ fontSize: 10, color: '#4a6080' }}>opacity %</span>
            </div>
          </PropField>
        )}

        {/* Button link to page */}
        {(el.type === 'button' || el.type === 'navtile' || el.type === 'backbtn') && pages.length > 0 && (
          <PropField label="Link to Page">
            {propSelect(p.linkTo || '', v => up('linkTo', v || null), [['', '— None —'], ['__back__', '← Back'], ...pages.map(pg => [pg.id, pg.name])])}
          </PropField>
        )}

        {/* Button style */}
        {el.type === 'button' && (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5, marginBottom: 10 }}>
              <PropField label="Corner Radius">{propInput(p.radius || 12, v => up('radius', v), 'number', { min: 0, max: 100 })}</PropField>
              <PropField label="Animation">{propSelect(p.animation || 'none', v => up('animation', v), [['none','None'],['pulse','Pulse'],['bounce','Bounce'],['glow','Glow'],['shake','Shake']])}</PropField>
            </div>
            <PropField label="Icon Emoji">
              <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
                {propInput(p.iconEmoji || '', v => up('iconEmoji', v))}
                <button onClick={() => up('showIcon', !p.showIcon)} style={{ flexShrink: 0, background: p.showIcon ? '#243553' : 'transparent', border: '1px solid #243553', borderRadius: 4, padding: '5px 8px', color: '#7d93b5', cursor: 'pointer', fontSize: 10, fontFamily: 'DM Sans' }}>Show</button>
              </div>
            </PropField>
          </>
        )}

        {/* Clock specific */}
        {el.type === 'clock' && (
          <>
            <PropField label="Format">{propSelect(p.format || '12h', v => up('format', v), [['12h','12 Hour'],['24h','24 Hour']])}</PropField>
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              {[['showDate','Show Date'],['showSeconds','Show Seconds']].map(([k,l]) => (
                <label key={k} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#7d93b5', cursor: 'pointer' }}>
                  <input type="checkbox" checked={!!p[k]} onChange={e => up(k, e.target.checked)} />
                  {l}
                </label>
              ))}
            </div>
          </>
        )}

        {/* Flight specific */}
        {el.type === 'flight' && (
          <>
            <PropField label="Airport">{propInput(p.airport || 'Darwin (DRW)', v => up('airport', v))}</PropField>
            <PropField label="Type">{propSelect(p.type || 'departures', v => up('type', v), [['departures','Departures'],['arrivals','Arrivals']])}</PropField>
            <PropField label="Max Rows">{propInput(p.maxRows || 6, v => up('maxRows', v), 'number', { min: 1, max: 20 })}</PropField>
          </>
        )}

        {/* Weather specific */}
        {el.type === 'weather' && (
          <>
            <PropField label="Location">{propInput(p.location || 'Darwin, AU', v => up('location', v))}</PropField>
            <PropField label="Units">{propSelect(p.units || 'celsius', v => up('units', v), [['celsius','Celsius (°C)'],['fahrenheit','Fahrenheit (°F)']])}</PropField>
          </>
        )}

        {/* Image/Video opacity */}
        {(el.type === 'image' || el.type === 'video') && (
          <>
            <PropField label="Opacity %">{propInput(p.opacity ?? 100, v => up('opacity', v), 'number', { min: 0, max: 100 })}</PropField>
            {el.type === 'image' && <PropField label="Border Radius">{propInput(p.radius || 0, v => up('radius', v), 'number', { min: 0 })}</PropField>}
            {el.type === 'video' && (
              <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                {[['autoplay','Autoplay'],['loop','Loop'],['muted','Muted']].map(([k,l]) => (
                  <label key={k} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#7d93b5', cursor: 'pointer' }}>
                    <input type="checkbox" checked={!!p[k]} onChange={e => up(k, e.target.checked)} />
                    {l}
                  </label>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

// ─── MAIN CANVAS EDITOR ───────────────────────────────────────────────────────
const RESOLUTIONS = [
  { label: '1920 × 1080 — Full HD', w: 1920, h: 1080 },
  { label: '3840 × 2160 — 4K UHD', w: 3840, h: 2160 },
  { label: '1280 × 720 — HD', w: 1280, h: 720 },
  { label: '1080 × 1920 — Portrait/Kiosk', w: 1080, h: 1920 },
  { label: '1366 × 768 — Laptop', w: 1366, h: 768 },
];

export default function CanvasEditor({
  initialElements = [], onChange, mode = 'signage',
  pages = [], onSave, onSaveTemplate, canvasBackground = '#0a0a14'
}) {
  const [elements, setElements] = useState(initialElements);
  const [selectedId, setSelectedId] = useState(null);
  const [snapEnabled, setSnapEnabled] = useState(true);
  const [showGrid, setShowGrid] = useState(false);
  const [userZoom, setUserZoom] = useState(1.0);
  const [resolution, setResolution] = useState(RESOLUTIONS[0]);
  const [canvasBg, setCanvasBg] = useState(canvasBackground);
  const [displayScale, setDisplayScale] = useState(0.5);

  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const dragRef = useRef(null);
  const elementsRef = useRef(elements);
  const snapRef = useRef(true);
  const scaleRef = useRef(0.5);
  const resolRef = useRef(RESOLUTIONS[0]);

  elementsRef.current = elements;
  snapRef.current = snapEnabled;
  scaleRef.current = displayScale * userZoom;
  resolRef.current = resolution;

  // Auto-calc scale to fit container
  useEffect(() => {
    const calc = () => {
      if (!containerRef.current) return;
      const cw = containerRef.current.clientWidth - 56;
      const ch = containerRef.current.clientHeight - 56;
      const sw = cw / resolRef.current.w;
      const sh = ch / resolRef.current.h;
      setDisplayScale(Math.min(sw, sh, 1));
    };
    calc();
    const ro = new ResizeObserver(calc);
    if (containerRef.current) ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, [resolution]);

  const snap = (v) => snapRef.current ? Math.round(v / GRID) * GRID : v;

  const getCoords = useCallback((e) => {
    if (!canvasRef.current) return { x: 0, y: 0 };
    const rect = canvasRef.current.getBoundingClientRect();
    const scale = scaleRef.current;
    return { x: (e.clientX - rect.left) / scale, y: (e.clientY - rect.top) / scale };
  }, []);

  // Global mouse handlers (use refs to avoid stale closures)
  useEffect(() => {
    const onMove = (e) => {
      const dr = dragRef.current;
      if (!dr) return;
      const { x, y } = getCoords(e);
      const dx = x - dr.startX;
      const dy = y - dr.startY;

      if (dr.type === 'move') {
        const newX = snap(Math.max(0, Math.min(resolRef.current.w - dr.elem.w, dr.elem.x + dx)));
        const newY = snap(Math.max(0, Math.min(resolRef.current.h - dr.elem.h, dr.elem.y + dy)));
        setElements(prev => prev.map(el => el.id === dr.id ? { ...el, x: newX, y: newY } : el));
      } else if (dr.type === 'resize') {
        let { x: ex, y: ey, w: ew, h: eh } = dr.elem;
        const h = dr.handle;
        if (h.includes('e')) ew = Math.max(40, snap(dr.elem.w + dx));
        if (h.includes('s')) eh = Math.max(20, snap(dr.elem.h + dy));
        if (h.includes('w')) { ex = snap(dr.elem.x + dx); ew = Math.max(40, snap(dr.elem.w - dx)); }
        if (h.includes('n')) { ey = snap(dr.elem.y + dy); eh = Math.max(20, snap(dr.elem.h - dy)); }
        setElements(prev => prev.map(el => el.id === dr.id ? { ...el, x: ex, y: ey, w: ew, h: eh } : el));
      }
    };
    const onUp = () => { dragRef.current = null; };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, [getCoords]);

  const addElement = useCallback((widgetDef, canvasX, canvasY) => {
    const id = genId();
    const el = {
      id, type: widgetDef.type,
      x: snap(Math.max(0, canvasX - widgetDef.w / 2)),
      y: snap(Math.max(0, canvasY - widgetDef.h / 2)),
      w: widgetDef.w, h: widgetDef.h,
      zIndex: (elementsRef.current.length + 1),
      locked: false, visible: true,
      props: { ...widgetDef.defaults }
    };
    setElements(prev => { const n = [...prev, el]; if (onChange) onChange(n); return n; });
    setSelectedId(id);
  }, [onChange]);

  const handleCanvasDrop = useCallback((e) => {
    e.preventDefault();
    const wdJson = e.dataTransfer.getData('widgetDef');
    if (!wdJson) return;
    const wd = JSON.parse(wdJson);
    const { x, y } = getCoords(e);
    addElement(wd, x, y);
  }, [getCoords, addElement]);

  const handleElemMouseDown = useCallback((e, el) => {
    if (el.locked) return;
    e.preventDefault();
    e.stopPropagation();
    setSelectedId(el.id);
    const { x, y } = getCoords(e);
    dragRef.current = { type: 'move', id: el.id, elem: { ...el }, startX: x, startY: y };
  }, [getCoords]);

  const handleResizeMouseDown = useCallback((e, el, handle) => {
    e.preventDefault();
    e.stopPropagation();
    const { x, y } = getCoords(e);
    dragRef.current = { type: 'resize', id: el.id, elem: { ...el }, handle, startX: x, startY: y };
  }, [getCoords]);

  const updateElement = useCallback((updated) => {
    setElements(prev => { const n = prev.map(el => el.id === updated.id ? updated : el); if (onChange) onChange(n); return n; });
  }, [onChange]);

  const deleteElement = useCallback(() => {
    setElements(prev => { const n = prev.filter(el => el.id !== selectedId); if (onChange) onChange(n); return n; });
    setSelectedId(null);
  }, [selectedId, onChange]);

  const duplicateElement = useCallback(() => {
    const el = elementsRef.current.find(e => e.id === selectedId);
    if (!el) return;
    const newEl = { ...el, id: genId(), x: el.x + 30, y: el.y + 30, zIndex: el.zIndex + 1 };
    setElements(prev => { const n = [...prev, newEl]; if (onChange) onChange(n); return n; });
    setSelectedId(newEl.id);
  }, [selectedId, onChange]);

  const bringForward = useCallback(() => {
    setElements(prev => prev.map(el => el.id === selectedId ? { ...el, zIndex: el.zIndex + 1 } : el));
  }, [selectedId]);

  const sendBack = useCallback(() => {
    setElements(prev => prev.map(el => el.id === selectedId ? { ...el, zIndex: Math.max(1, el.zIndex - 1) } : el));
  }, [selectedId]);

  const toggleLock = useCallback(() => {
    setElements(prev => prev.map(el => el.id === selectedId ? { ...el, locked: !el.locked } : el));
  }, [selectedId]);

  const toggleVisible = useCallback(() => {
    setElements(prev => prev.map(el => el.id === selectedId ? { ...el, visible: el.visible === false ? true : false } : el));
  }, [selectedId]);

  const selectedEl = elements.find(el => el.id === selectedId);
  const widgets = mode === 'portal' ? PORTAL_WIDGETS : SIGNAGE_WIDGETS;
  const effectiveScale = displayScale * userZoom;

  const HANDLES = [
    { id: 'nw', style: { top: -5, left: -5, cursor: 'nw-resize' } },
    { id: 'n', style: { top: -5, left: '50%', transform: 'translateX(-50%)', cursor: 'n-resize' } },
    { id: 'ne', style: { top: -5, right: -5, cursor: 'ne-resize' } },
    { id: 'e', style: { top: '50%', right: -5, transform: 'translateY(-50%)', cursor: 'e-resize' } },
    { id: 'se', style: { bottom: -5, right: -5, cursor: 'se-resize' } },
    { id: 's', style: { bottom: -5, left: '50%', transform: 'translateX(-50%)', cursor: 's-resize' } },
    { id: 'sw', style: { bottom: -5, left: -5, cursor: 'sw-resize' } },
    { id: 'w', style: { top: '50%', left: -5, transform: 'translateY(-50%)', cursor: 'w-resize' } },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#0e1623', fontFamily: 'DM Sans', color: '#e8f0fc' }}>
      {/* TOOLBAR */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: '#111b28', borderBottom: '1px solid #243553', flexShrink: 0, flexWrap: 'wrap' }}>
        <select value={`${resolution.w}x${resolution.h}`} onChange={e => { const r = RESOLUTIONS.find(r => `${r.w}x${r.h}` === e.target.value); if (r) setResolution(r); }}
          style={{ background: '#1c2a3d', border: '1px solid #243553', borderRadius: 6, padding: '5px 8px', color: '#e8f0fc', fontSize: 12, fontFamily: 'DM Sans' }}>
          {RESOLUTIONS.map(r => <option key={r.label} value={`${r.w}x${r.h}`}>{r.label}</option>)}
        </select>

        <div style={{ width: 1, height: 20, background: '#243553' }} />

        {[
          [() => setUserZoom(z => Math.min(3, +(z + 0.1).toFixed(1))), ZoomIn, 'Zoom in'],
          [() => setUserZoom(z => Math.max(0.1, +(z - 0.1).toFixed(1))), ZoomOut, 'Zoom out'],
        ].map(([fn, Icon, tip]) => (
          <button key={tip} title={tip} onClick={fn} style={{ background: '#1c2a3d', border: '1px solid #243553', borderRadius: 5, padding: '5px 8px', color: '#7d93b5', cursor: 'pointer' }}>
            <Icon size={14} />
          </button>
        ))}
        <span style={{ fontSize: 11, color: '#4a6080', minWidth: 36, textAlign: 'center' }}>{Math.round(userZoom * 100)}%</span>
        <button onClick={() => setUserZoom(1)} style={{ background: 'none', border: '1px solid #243553', borderRadius: 4, padding: '3px 7px', color: '#4a6080', cursor: 'pointer', fontSize: 10, fontFamily: 'DM Sans' }}>Reset</button>

        <div style={{ width: 1, height: 20, background: '#243553' }} />

        {[
          [snapEnabled, () => setSnapEnabled(v => !v), Magnet, 'Snap to Grid'],
          [showGrid, () => setShowGrid(v => !v), Grid, 'Show Grid'],
        ].map(([active, fn, Icon, tip]) => (
          <button key={tip} title={tip} onClick={fn} style={{ display: 'flex', alignItems: 'center', gap: 5, background: active ? '#0b9e9822' : '#1c2a3d', border: `1px solid ${active ? '#0b9e98' : '#243553'}`, borderRadius: 5, padding: '5px 9px', color: active ? '#0b9e98' : '#7d93b5', cursor: 'pointer', fontSize: 11, fontFamily: 'DM Sans' }}>
            <Icon size={13} />{tip}
          </button>
        ))}

        <div style={{ flex: 1 }} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ fontSize: 10, color: '#4a6080' }}>Canvas BG:</span>
          <input type="color" value={canvasBg} onChange={e => setCanvasBg(e.target.value)}
            style={{ width: 28, height: 28, padding: 1, background: '#1c2a3d', border: '1px solid #243553', borderRadius: 4, cursor: 'pointer' }} />
          {['#0a0a14', '#000000', '#ffffff', '#1a2035'].map(c => (
            <button key={c} onClick={() => setCanvasBg(c)} style={{ width: 20, height: 20, background: c, border: `2px solid ${canvasBg === c ? '#00d4aa' : '#243553'}`, borderRadius: 3, cursor: 'pointer' }} />
          ))}
        </div>

        <div style={{ width: 1, height: 20, background: '#243553' }} />

        {onSaveTemplate && (
          <button onClick={onSaveTemplate} style={{ display: 'flex', alignItems: 'center', gap: 5, background: '#243553', border: '1px solid #3b5280', borderRadius: 5, padding: '6px 11px', color: '#7d93b5', cursor: 'pointer', fontSize: 12, fontFamily: 'DM Sans' }}>
            <Layers size={13} /> Template
          </button>
        )}
        <button onClick={() => { if (onSave) onSave(elements); }} style={{ display: 'flex', alignItems: 'center', gap: 5, background: '#00d4aa', border: 'none', borderRadius: 5, padding: '6px 14px', color: '#07080f', cursor: 'pointer', fontSize: 12, fontWeight: 700, fontFamily: 'DM Sans' }}>
          Save
        </button>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* WIDGET PANEL */}
        <div style={{ width: 190, background: '#111b28', borderRight: '1px solid #243553', overflowY: 'auto', flexShrink: 0 }}>
          <div style={{ padding: '10px 12px 6px', fontSize: 10, fontWeight: 700, color: '#4a6080', textTransform: 'uppercase', letterSpacing: 0.8 }}>
            Drag to Canvas
          </div>
          {widgets.map(group => (
            <div key={group.group}>
              <div style={{ padding: '6px 12px 4px', fontSize: 10, fontWeight: 700, color: '#4a6080', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 4 }}>{group.group}</div>
              {group.items.map(w => (
                <div key={w.type} draggable
                  onDragStart={e => e.dataTransfer.setData('widgetDef', JSON.stringify(w))}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px', cursor: 'grab', userSelect: 'none', borderBottom: '1px solid #1c2a3d' }}
                  onMouseEnter={e => e.currentTarget.style.background = '#1c2a3d'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <span style={{ fontSize: 16, flexShrink: 0 }}>{typeof w.icon === 'string' ? w.icon : '□'}</span>
                  <span style={{ fontSize: 12, color: '#7d93b5' }}>{w.label}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* CANVAS AREA */}
        <div ref={containerRef}
          style={{ flex: 1, background: '#1a1f2e', overflow: 'auto', display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-start', padding: 28 }}
          onClick={() => setSelectedId(null)}
        >
          {/* Outer container sets display size */}
          <div style={{
            width: resolution.w * effectiveScale,
            height: resolution.h * effectiveScale,
            position: 'relative',
            boxShadow: '0 0 0 1px #243553, 0 8px 40px rgba(0,0,0,0.6)',
            flexShrink: 0,
          }}>
            {/* Actual canvas at resolution size, scaled */}
            <div ref={canvasRef}
              style={{
                width: resolution.w,
                height: resolution.h,
                position: 'absolute',
                top: 0, left: 0,
                transform: `scale(${effectiveScale})`,
                transformOrigin: 'top left',
                background: canvasBg,
                overflow: 'hidden',
              }}
              onDragOver={e => e.preventDefault()}
              onDrop={handleCanvasDrop}
            >
              {/* Grid overlay */}
              {showGrid && (
                <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', opacity: 0.12 }}>
                  <defs>
                    <pattern id="grid" width={GRID} height={GRID} patternUnits="userSpaceOnUse">
                      <path d={`M ${GRID} 0 L 0 0 0 ${GRID}`} fill="none" stroke="#ffffff" strokeWidth="0.5" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#grid)" />
                </svg>
              )}

              {/* Elements */}
              {[...elements].sort((a, b) => a.zIndex - b.zIndex).map(el => {
                const isSelected = el.id === selectedId;
                return (
                  <div key={el.id}
                    style={{
                      position: 'absolute',
                      left: el.x, top: el.y, width: el.w, height: el.h,
                      zIndex: el.zIndex,
                      opacity: el.visible === false ? 0.3 : 1,
                      cursor: el.locked ? 'not-allowed' : 'move',
                      outline: isSelected ? '2px solid #00d4aa' : el.locked ? '1px dashed #ef444455' : 'none',
                      outlineOffset: isSelected ? 1 : 0,
                      boxSizing: 'border-box',
                      userSelect: 'none',
                    }}
                    onMouseDown={e => handleElemMouseDown(e, el)}
                  >
                    {renderElementContent(el)}

                    {/* Resize handles */}
                    {isSelected && !el.locked && HANDLES.map(handle => (
                      <div key={handle.id}
                        style={{ position: 'absolute', width: 10, height: 10, background: '#00d4aa', border: '2px solid #0e1623', borderRadius: 2, zIndex: 9999, ...handle.style }}
                        onMouseDown={e => handleResizeMouseDown(e, el, handle.id)}
                      />
                    ))}

                    {el.locked && (
                      <div style={{ position: 'absolute', top: 4, right: 4, background: '#ef444444', borderRadius: 3, padding: '1px 4px', fontSize: 10, color: '#ef4444' }}>🔒</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* PROPERTIES PANEL */}
        <PropertiesPanel
          el={selectedEl}
          pages={pages}
          onChange={updateElement}
          onDelete={deleteElement}
          onDuplicate={duplicateElement}
          onBringForward={bringForward}
          onSendBack={sendBack}
          onToggleLock={toggleLock}
          onToggleVisible={toggleVisible}
        />
      </div>
    </div>
  );
}
