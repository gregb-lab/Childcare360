import { useTheme } from '../context/ThemeContext.jsx';

export function Btn({ children, variant = 'primary', size = 'md', onClick, icon: Icon, disabled, style: s = {}, title }) {
  const { C, isDark } = useTheme();
  const variants = {
    primary: { background: C.teal, color: isDark ? '#07080f' : '#fff', border: 'none' },
    secondary: { background: C.card, color: C.textPrimary, border: `1px solid ${C.border}` },
    danger: { background: C.red + '18', color: C.red, border: `1px solid ${C.red}33` },
    ghost: { background: 'transparent', color: C.textSecondary, border: '1px solid transparent' },
    amber: { background: C.amber + '18', color: C.amber, border: `1px solid ${C.amber}33` },
    purple: { background: C.purple + '18', color: C.purple, border: `1px solid ${C.purple}33` },
    teal: { background: C.tealDim, color: C.teal, border: `1px solid ${C.tealMid}` },
  };
  return (
    <button title={title} disabled={disabled} onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, cursor: disabled ? 'not-allowed' : 'pointer',
      borderRadius: 8, fontWeight: 600, fontFamily: "'DM Sans', sans-serif",
      fontSize: size === 'sm' ? 12 : size === 'xs' ? 11 : 14,
      padding: size === 'sm' ? '5px 11px' : size === 'xs' ? '3px 8px' : '9px 16px',
      opacity: disabled ? 0.6 : 1, transition: 'opacity 0.15s',
      ...variants[variant], ...s
    }}>
      {Icon && <Icon size={size === 'sm' ? 13 : size === 'xs' ? 11 : 15} />}
      {children}
    </button>
  );
}

export function Badge({ label, color }) {
  return (
    <span style={{ background: color + '22', color, border: `1px solid ${color}44`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600, letterSpacing: 0.3, whiteSpace: 'nowrap' }}>
      {label}
    </span>
  );
}

export function Toggle({ value, onChange }) {
  const { C } = useTheme();
  return (
    <div onClick={() => onChange && onChange(!value)} style={{
      width: 38, height: 21, borderRadius: 11, cursor: 'pointer',
      background: value ? C.teal : C.border, position: 'relative', transition: 'all 0.2s', flexShrink: 0
    }}>
      <div style={{
        position: 'absolute', top: 3, left: value ? 19 : 3, width: 13, height: 13,
        borderRadius: '50%', background: value ? (C.name === 'dark' ? '#07080f' : '#fff') : C.textDim, transition: 'left 0.2s'
      }} />
    </div>
  );
}

export function Input({ style: s = {}, ...props }) {
  const { C } = useTheme();
  return (
    <input {...props} style={{
      width: '100%', padding: '9px 11px', background: C.inputBg, border: `1px solid ${C.border}`,
      borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans', sans-serif",
      boxSizing: 'border-box', outline: 'none', ...s
    }} />
  );
}

export function Select({ style: s = {}, children, ...props }) {
  const { C } = useTheme();
  return (
    <select {...props} style={{
      width: '100%', padding: '9px 11px', background: C.inputBg, border: `1px solid ${C.border}`,
      borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans', sans-serif",
      boxSizing: 'border-box', ...s
    }}>
      {children}
    </select>
  );
}

export function Textarea({ style: s = {}, ...props }) {
  const { C } = useTheme();
  return (
    <textarea {...props} style={{
      width: '100%', padding: '9px 11px', background: C.inputBg, border: `1px solid ${C.border}`,
      borderRadius: 7, color: C.textPrimary, fontSize: 13, fontFamily: "'DM Sans', sans-serif",
      boxSizing: 'border-box', outline: 'none', resize: 'vertical', ...s
    }} />
  );
}

export function Card({ children, style: s = {}, onClick }) {
  const { C } = useTheme();
  return (
    <div onClick={onClick} style={{
      background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12,
      ...(onClick ? { cursor: 'pointer' } : {}), ...s
    }}>
      {children}
    </div>
  );
}

export function SectionHeader({ title, sub, action }) {
  const { C } = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
      <div>
        <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.textPrimary }}>{title}</h2>
        {sub && <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textSecondary }}>{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function StatCard({ icon: Icon, label, value, sub, color }) {
  const { C } = useTheme();
  const c = color || C.teal;
  return (
    <div style={{
      background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: '18px 22px',
      display: 'flex', gap: 14, alignItems: 'center', position: 'relative', overflow: 'hidden'
    }}>
      <div style={{ position: 'absolute', top: 0, right: 0, width: 100, height: 100, background: `radial-gradient(circle at top right, ${c}12, transparent 70%)` }} />
      <div style={{ width: 44, height: 44, borderRadius: 10, background: c + '18', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon size={20} color={c} />
      </div>
      <div>
        <div style={{ fontSize: 11, color: C.textSecondary, fontWeight: 500, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 3 }}>{label}</div>
        <div style={{ fontSize: 26, fontWeight: 700, color: C.textPrimary, lineHeight: 1 }}>{value}</div>
        {sub && <div style={{ fontSize: 11, color: C.textSecondary, marginTop: 3 }}>{sub}</div>}
      </div>
    </div>
  );
}

export function Modal({ title, onClose, children, width = 520 }) {
  const { C } = useTheme();
  return (
    <div style={{ position: 'fixed', inset: 0, background: '#00000066', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
      onClick={e => e.target === e.currentTarget && onClose?.()}>
      <div style={{ background: C.panel, border: `1px solid ${C.border}`, borderRadius: 14, padding: 28, width: '100%', maxWidth: width, maxHeight: '90vh', overflowY: 'auto', boxShadow: C.shadow }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 }}>
          <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: C.textPrimary }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.textSecondary, fontSize: 20 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({ label, children, hint }) {
  const { C } = useTheme();
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 12, color: C.textSecondary, display: 'block', marginBottom: 5, fontWeight: 500 }}>{label}</label>
      {children}
      {hint && <p style={{ fontSize: 11, color: C.textDim, margin: '4px 0 0' }}>{hint}</p>}
    </div>
  );
}
