import { Sun, Moon, Monitor } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.jsx';

export default function ThemeToggle() {
  const { mode, setMode, C } = useTheme();

  const options = [
    { key: 'light', icon: Sun, label: 'Light' },
    { key: 'auto', icon: Monitor, label: 'Auto' },
    { key: 'dark', icon: Moon, label: 'Dark' },
  ];

  return (
    <div style={{ display: 'flex', background: C.card, border: `1px solid ${C.border}`, borderRadius: 8, overflow: 'hidden' }}>
      {options.map(({ key, icon: Icon, label }) => (
        <button key={key} onClick={() => setMode(key)} title={label} style={{
          padding: '5px 9px', background: mode === key ? C.tealDim : 'transparent',
          border: 'none', cursor: 'pointer', color: mode === key ? C.teal : C.textDim,
          display: 'flex', alignItems: 'center', borderRight: `1px solid ${C.border}`,
        }}>
          <Icon size={14} />
        </button>
      ))}
    </div>
  );
}
