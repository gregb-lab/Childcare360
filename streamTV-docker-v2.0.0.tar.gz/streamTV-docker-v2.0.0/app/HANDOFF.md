# Streamvision CMS — Handoff Document
**Date:** 20 February 2026  
**Current Version:** v1.0.2 (pending v2.0.0 with theme + full signage)  
**Project:** streamTV CMS — cloud-based hotel IPTV / digital signage management platform

---

## What Has Been Built

### Architecture
- **Stack:** React 18 (Vite) frontend + Express.js backend + better-sqlite3 database
- **Port:** Express serves on **3006** (built frontend + API)
- **Deploy path on VM:** `~/streamtv-cms/`
- **Shared folder:** `/media/sf_VM_Shared_Folder/`
- **VM:** Ubuntu 22.04, VirtualBox on Windows

### Multi-Tenancy Model
| Role | Login | What They See |
|------|-------|---------------|
| `superadmin` | admin@streamvision.com.au / StreamTV2026! | Streamvision Admin Portal (create hotels, groups, users) |
| `group_admin` | portfolio@hilton.com / Hilton2026! | Hotel selector → full CMS for chosen property |
| `hotel_admin` | manager@hgidarwin.com.au / HotelDemo2026! | Direct CMS for their hotel (HGI Darwin) |
| `hotel_staff` | reception@hgidarwin.com.au / Staff2026! | Direct CMS for their hotel |

### File Structure
```
streamtv-cms/
├── index.html
├── package.json
├── vite.config.js          (proxy /api → localhost:3006 in dev)
├── postcss.config.js       (empty — prevents Tailwind clash from ~/postcss.config.js)
├── server/
│   ├── index.js            Express API server (PORT 3006)
│   └── db.js               SQLite schema + seed data
├── src/
│   ├── main.jsx
│   ├── App.jsx             Routes: Login → AdminPortal | HotelSelector | CMS
│   ├── api/
│   │   └── client.js       All API calls (fetch wrapper with JWT)
│   ├── context/
│   │   ├── AuthContext.jsx  Login state, activeHotel, user role
│   │   └── ThemeContext.jsx Light/Dark/Auto theme (LIGHT and DARK colour objects)
│   ├── components/
│   │   ├── UI.jsx           Shared: Btn, Badge, Card, Modal, Field, Input, Select, Toggle, StatCard
│   │   ├── ThemeToggle.jsx  Light/Auto/Dark toggle widget
│   │   └── CanvasEditor.jsx WYSIWYG canvas — used by both Signage and Portal Designer
│   └── pages/
│       ├── Login.jsx        Login with email/pw, Google/Apple UI stubs, demo account buttons
│       ├── AdminPortal.jsx  Streamvision superadmin — hotels, groups, users CRUD
│       ├── HotelSelector.jsx Property picker for group/multi-hotel users
│       ├── Signage.jsx      Digital Signage module (assets + schedule + canvas editor)
│       ├── SignageModule.jsx Signage integrated into main CMS nav
│       └── PortalDesigner.jsx TV Portal editor with multi-page support
```

**NOTE:** `CMS.jsx` (the main hotel CMS shell with sidebar nav + all hotel modules) was being built at time of context limit. The last committed version may be missing from the tar. See "What Still Needs Doing" below.

---

## Theme System
`ThemeContext.jsx` exports `LIGHT` and `DARK` colour objects and a `useTheme()` hook.

```js
const { C, mode, setMode, isDark } = useTheme();
// C.bg, C.panel, C.card, C.teal, C.textPrimary, etc.
// mode: 'light' | 'dark' | 'auto'
```

**Light theme:** White panels, navy blue sidebar (`#1a2644`), teal accent `#00b894`  
**Dark theme:** Near-black bg `#0b0f1a`, dark navy card `#161d2e`, teal accent `#00d4aa`

---

## CanvasEditor.jsx — WYSIWYG Editor
The shared canvas editor is used in both Signage and Portal Designer.

**Mode prop:**
- `mode="signage"` — digital signage editing (resolution selector, snap guides, etc.)
- `mode="portal"` — TV portal page editing (buttons with page links, guest widgets)

**Widget catalogues exported from CanvasEditor.jsx:**
- `SIGNAGE_WIDGETS` — Text, Image, Video, Slideshow, Live TV, Movie Feature, Flight Board, Menu Board, Clock, Weather, Shape, QR Code, RSS Ticker, Social Feed
- `PORTAL_WIDGETS` — Button (linkable to pages), Nav Tile, Back Button, Guest Name, Room Info, Weather, Advertising Panel, News Ticker, Clock, Room Number

**Canvas features built:**
- Drag to move elements
- Resize handles
- Snap to grid (togglable)
- Snap guidelines (togglable)
- Element properties panel (right side)
- Full text formatting: font family, size, weight, italic, underline, alignment, letter spacing, line height, colour
- Z-index layering (bring forward/send back)
- Lock elements
- Hide/show elements
- Delete, duplicate elements
- Undo stack
- Zoom in/out
- Resolution selector (1080p, 4K, 720p, Portrait modes)
- Save as template / Load template

---

## Digital Signage Module (Signage.jsx / SignageModule.jsx)
- **Asset Library:** Upload/manage videos, images, PDFs, PowerPoint (by type icon), text snippets, slideshows
- **Playlists:** Create playlists, drag assets in, set duration per asset
- **Schedules:** Assign playlists to screens with time/date scheduling
- **Screens:** Register display screens (lobby, conference, poolside etc.)
- **Canvas Editor:** Full WYSIWYG slide builder

**Status:** Mostly complete. Needs polish and integration with backend API endpoints.

---

## Portal Designer (PortalDesigner.jsx)
- Multi-page portal (create Home + sub-pages)
- Edit each page in canvas editor
- Buttons dragged onto canvas can be linked to other pages
- AM/PM schedule (different portal morning vs evening)
- Background settings: solid colour, image, video, slideshow
- Advertising panel widget with time scheduling

**Status:** Page manager built, canvas editor wired in. Needs: advertising scheduler UI, AM/PM switcher logic, live preview panel.

---

## What Still Needs Doing (Priority Order)

### 1. CRITICAL — CMS.jsx rebuild with theme support
The main CMS shell (`CMS.jsx`) wraps all hotel modules in a sidebar layout.
It was the file being edited when context ran out. It needs to:
- Use `useTheme()` for all colours (currently uses hardcoded DARK colours)
- Wire in `SignageModule` and `PortalDesigner` into the nav
- Theme toggle in the top bar

### 2. All CMS module pages need theme support
These files exist but use hardcoded dark colours:
- `src/pages/AdminPortal.jsx`
- `src/pages/HotelSelector.jsx`
- `src/pages/Login.jsx`

Replace all hardcoded `#07080f`, `#0d1117`, `#111827`, `#161d2e`, `#1e2d45` etc. with `C.bg`, `C.sidebar`, `C.panel`, `C.card`, `C.border` from `useTheme()`.

### 3. Complete CanvasEditor features
- Drag from widget panel onto canvas (currently click-to-add)
- Smart snap guides (show alignment lines when dragging near other elements)
- Button → page link picker (dropdown of portal pages)
- Template save/load with named templates list
- PDF/PowerPoint import (show as image placeholder with file icon)

### 4. Digital Signage — backend API
Add these endpoints to `server/index.js`:
- `GET/POST /api/hotels/:id/signage/assets`
- `GET/POST /api/hotels/:id/signage/playlists`
- `GET/POST /api/hotels/:id/signage/schedules`
- `GET/POST /api/hotels/:id/signage/screens`

Add tables to `server/db.js`:
```sql
CREATE TABLE signage_assets (id, hotel_id, name, type, url, size, created_at)
CREATE TABLE signage_playlists (id, hotel_id, name, created_at)
CREATE TABLE signage_playlist_items (id, playlist_id, asset_id, duration, sort_order)
CREATE TABLE signage_screens (id, hotel_id, name, location, resolution, status)
CREATE TABLE signage_schedules (id, screen_id, playlist_id, start_time, end_time, days_of_week)
```

### 5. Reports module
Placeholder currently shown. Build out with:
- Revenue chart (VOD + minibar)
- Channel viewership
- Device uptime/fault stats
- Message open rates

### 6. streamSTUDIO module
Placeholder. Build wizard: My Content / Internet Stream / YouTube Live → configure → go live.

---

## Deploy Instructions (for VM)
```bash
cd ~/streamtv-cms
pkill -f "node server/index.js" 2>/dev/null
rm -rf data node_modules
cp /media/sf_VM_Shared_Folder/streamTV-v{VERSION}-{DATE}.tar.gz .
tar xf streamTV-v{VERSION}-{DATE}.tar.gz
npm install
npm rebuild better-sqlite3 --build-from-source
npx vite build
nohup node server/index.js > streamtv.log 2>&1 &
sleep 2 && cat streamtv.log
```

Access at: `http://localhost:3006`

---

## Known Issues
1. `better-sqlite3` requires `--build-from-source` on Ubuntu 22.04 with some Node versions
2. A `postcss.config.js` exists in the user's home `~` directory from another project (LittleSteps/littlesteps-app) that references Tailwind — the app includes an empty `postcss.config.js` at project root to override it
3. Google/Apple OAuth login buttons are UI stubs only — need real OAuth configuration
4. ThemeToggle component references `setThemeMode` and `theme` — should be `setMode` and `C` — fix when rebuilding CMS.jsx

---

## Branding & Design Direction
- Font: **DM Sans** (Google Fonts, loaded in index.html)
- Product name: **streamvision** (lowercase in logo)
- Teal accent is the primary brand colour
- Logo: TV icon in teal square, white text
- Sidebar is always dark navy regardless of light/dark mode
- Version displayed in sidebar footer and login page

## File Naming Convention
All deployable tars: `streamTV-v{major}.{minor}.{patch}-{YYYYMMDD}-{HHMM}.tar.gz`
