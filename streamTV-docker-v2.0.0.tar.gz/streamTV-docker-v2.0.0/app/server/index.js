const express = require('express');
const cors = require('cors');
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = 3006;
const JWT_SECRET = process.env.JWT_SECRET || 'streamvision-jwt-secret-2026';
const APP_VERSION = '2.0.0';

app.use(cors());
app.use(express.json());

// ─── LOAD DB (with crash protection) ─────────────────────────────────────────
let db;
try {
  db = require('./db');
  console.log('✅ Database loaded');
} catch (e) {
  console.error('❌ Database failed to load:', e.message);
  process.exit(1);
}

// ─── API JSON error guard — any /api route that throws returns JSON ───────────
app.use('/api', (req, res, next) => {
  res.setHeader('Content-Type', 'application/json');
  next();
});

// ─── AUTH MIDDLEWARE ──────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Forbidden' });
    next();
  };
}

// ─── HEALTH CHECK ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ ok: true, version: APP_VERSION });
});

// ─── AUTH ─────────────────────────────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const user = db.prepare('SELECT * FROM users WHERE email = ? AND active = 1').get(email.toLowerCase().trim());
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const valid = bcrypt.compareSync(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    db.prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?").run(user.id);

    let hotelInfo = null;
    let groupInfo = null;
    let accessibleHotels = [];

    if (user.hotel_id) {
      hotelInfo = db.prepare('SELECT id, name, code, city, country, timezone, total_rooms FROM hotels WHERE id = ?').get(user.hotel_id);
    }
    if (user.group_id) {
      groupInfo = db.prepare('SELECT id, name, code FROM hotel_groups WHERE id = ?').get(user.group_id);
      accessibleHotels = db.prepare(`
        SELECT h.id, h.name, h.code, h.city, h.country, h.total_rooms, h.active
        FROM hotels h JOIN user_hotel_access uha ON uha.hotel_id = h.id WHERE uha.user_id = ?
      `).all(user.id);
    }
    if (user.role === 'superadmin') {
      accessibleHotels = db.prepare('SELECT id, name, code, city, country, total_rooms, active, group_id FROM hotels').all();
    }

    const payload = { id: user.id, email: user.email, name: user.name, role: user.role, hotel_id: user.hotel_id, group_id: user.group_id };
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '12h' });

    res.json({ token, user: { ...payload, hotel: hotelInfo, group: groupInfo, accessibleHotels }, version: APP_VERSION });
  } catch (e) {
    console.error('Login error:', e);
    res.status(500).json({ error: 'Server error: ' + e.message });
  }
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  try {
    const user = db.prepare('SELECT id, email, name, role, hotel_id, group_id, last_login FROM users WHERE id = ?').get(req.user.id);
    res.json({ user, version: APP_VERSION });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── HOTELS ───────────────────────────────────────────────────────────────────
app.get('/api/hotels', requireAuth, (req, res) => {
  try {
    let hotels;
    if (req.user.role === 'superadmin') {
      hotels = db.prepare('SELECT h.*, hg.name as group_name FROM hotels h LEFT JOIN hotel_groups hg ON hg.id = h.group_id ORDER BY h.name').all();
    } else if (req.user.role === 'group_admin') {
      hotels = db.prepare(`SELECT h.*, hg.name as group_name FROM hotels h JOIN user_hotel_access uha ON uha.hotel_id = h.id LEFT JOIN hotel_groups hg ON hg.id = h.group_id WHERE uha.user_id = ? ORDER BY h.name`).all(req.user.id);
    } else {
      hotels = db.prepare('SELECT * FROM hotels WHERE id = ?').all(req.user.hotel_id);
    }
    res.json(hotels);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels', requireAuth, requireRole('superadmin'), (req, res) => {
  try {
    const { name, code, group_id, city, country, timezone, total_rooms, contact_email } = req.body;
    const r = db.prepare(`INSERT INTO hotels (name, code, group_id, city, country, timezone, total_rooms, contact_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(name, code.toUpperCase(), group_id || null, city, country, timezone || 'Australia/Sydney', total_rooms || 0, contact_email);
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/hotels/:id', requireAuth, requireRole('superadmin', 'group_admin'), (req, res) => {
  try {
    const { name, city, country, timezone, total_rooms, contact_email, active } = req.body;
    db.prepare('UPDATE hotels SET name=?, city=?, country=?, timezone=?, total_rooms=?, contact_email=?, active=? WHERE id=?').run(name, city, country, timezone, total_rooms, contact_email, active ? 1 : 0, req.params.id);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── GROUPS ───────────────────────────────────────────────────────────────────
app.get('/api/groups', requireAuth, requireRole('superadmin'), (req, res) => {
  try {
    const groups = db.prepare('SELECT *, (SELECT COUNT(*) FROM hotels WHERE group_id = hotel_groups.id) as hotel_count FROM hotel_groups').all();
    res.json(groups);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/groups', requireAuth, requireRole('superadmin'), (req, res) => {
  try {
    const { name, code, country, contact_email } = req.body;
    const r = db.prepare('INSERT INTO hotel_groups (name, code, country, contact_email) VALUES (?, ?, ?, ?)').run(name, code.toUpperCase(), country, contact_email);
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// ─── USERS ────────────────────────────────────────────────────────────────────
app.get('/api/users', requireAuth, requireRole('superadmin', 'group_admin', 'hotel_admin'), (req, res) => {
  try {
    let users;
    if (req.user.role === 'superadmin') {
      users = db.prepare('SELECT id, email, name, role, group_id, hotel_id, active, last_login, created_at FROM users ORDER BY name').all();
    } else if (req.user.role === 'group_admin') {
      users = db.prepare('SELECT id, email, name, role, group_id, hotel_id, active, last_login FROM users WHERE group_id = ? ORDER BY name').all(req.user.group_id);
    } else {
      users = db.prepare('SELECT id, email, name, role, hotel_id, active, last_login FROM users WHERE hotel_id = ? ORDER BY name').all(req.user.hotel_id);
    }
    res.json(users);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/users', requireAuth, requireRole('superadmin', 'group_admin', 'hotel_admin'), (req, res) => {
  try {
    const { email, password, name, role, group_id, hotel_id } = req.body;
    const hash = bcrypt.hashSync(password, 10);
    const r = db.prepare('INSERT INTO users (email, password_hash, name, role, group_id, hotel_id) VALUES (?, ?, ?, ?, ?, ?)').run(email.toLowerCase(), hash, name, role, group_id || null, hotel_id || null);
    if (hotel_id) {
      try { db.prepare('INSERT INTO user_hotel_access (user_id, hotel_id) VALUES (?, ?)').run(r.lastInsertRowid, hotel_id); } catch {}
    }
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/users/:id', requireAuth, requireRole('superadmin', 'group_admin', 'hotel_admin'), (req, res) => {
  try {
    const { name, role, active, hotel_id, group_id } = req.body;
    db.prepare('UPDATE users SET name=?, role=?, active=?, hotel_id=?, group_id=? WHERE id=?').run(name, role, active ? 1 : 0, hotel_id || null, group_id || null, req.params.id);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── STATS ────────────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/stats', requireAuth, (req, res) => {
  try {
    const hid = req.params.hotelId;
    const totalRooms = db.prepare('SELECT COUNT(*) as c FROM rooms WHERE hotel_id = ?').get(hid).c;
    const occupied = db.prepare("SELECT COUNT(*) as c FROM rooms WHERE hotel_id = ? AND status = 'occupied'").get(hid).c;
    const devOnline = db.prepare("SELECT COUNT(*) as c FROM devices WHERE hotel_id = ? AND status = 'online'").get(hid).c;
    const devOffline = db.prepare("SELECT COUNT(*) as c FROM devices WHERE hotel_id = ? AND status = 'offline'").get(hid).c;
    const devFault = db.prepare("SELECT COUNT(*) as c FROM devices WHERE hotel_id = ? AND status = 'fault'").get(hid).c;
    const msgCount = db.prepare('SELECT COUNT(*) as c FROM messages WHERE hotel_id = ?').get(hid).c;
    const channelCount = db.prepare('SELECT COUNT(*) as c FROM channels WHERE hotel_id = ? AND active = 1').get(hid).c;
    res.json({ totalRooms, occupied, vacant: totalRooms - occupied, devOnline, devOffline, devFault, msgCount, channelCount });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── ROOMS ────────────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/rooms', requireAuth, (req, res) => {
  try {
    const rooms = db.prepare(`SELECT r.*, d.status as device_status, d.model as device_model, d.ip as device_ip, d.fault_note FROM rooms r LEFT JOIN devices d ON d.room_id = r.id WHERE r.hotel_id = ? ORDER BY r.floor, r.number`).all(req.params.hotelId);
    res.json(rooms);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/rooms', requireAuth, (req, res) => {
  try {
    const { number, type, floor } = req.body;
    const r = db.prepare('INSERT INTO rooms (hotel_id, number, type, floor) VALUES (?, ?, ?, ?)').run(req.params.hotelId, number, type || 'Standard', floor || 1);
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/rooms/:id', requireAuth, (req, res) => {
  try {
    const { status, guest_name, guest_email, restriction_vod, restriction_adult, restriction_billing, restriction_menu, restriction_all, discount } = req.body;
    db.prepare('UPDATE rooms SET status=?, guest_name=?, guest_email=?, restriction_vod=?, restriction_adult=?, restriction_billing=?, restriction_menu=?, restriction_all=?, discount=? WHERE id=? AND hotel_id=?').run(status, guest_name || null, guest_email || null, restriction_vod ? 1 : 0, restriction_adult ? 1 : 0, restriction_billing ? 1 : 0, restriction_menu ? 1 : 0, restriction_all ? 1 : 0, discount || 0, req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── DEVICES ──────────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/devices', requireAuth, (req, res) => {
  try {
    const devices = db.prepare(`SELECT d.*, r.number as room_number, r.floor FROM devices d LEFT JOIN rooms r ON r.id = d.room_id WHERE d.hotel_id = ? ORDER BY r.floor, r.number`).all(req.params.hotelId);
    res.json(devices);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/devices/:id/resolve', requireAuth, (req, res) => {
  try {
    const { note } = req.body;
    db.prepare("UPDATE devices SET status='online', fault_note=NULL WHERE id=? AND hotel_id=?").run(req.params.id, req.params.hotelId);
    db.prepare("UPDATE device_fault_log SET resolved=1, resolved_at=datetime('now') WHERE device_id=? AND resolved=0").run(req.params.id);
    if (note) db.prepare("INSERT INTO device_fault_log (device_id, fault_type, note, resolved) VALUES (?, ?, ?, 1)").run(req.params.id, 'Manual Resolve', note);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/hotels/:hotelId/devices/faults', requireAuth, (req, res) => {
  try {
    const faults = db.prepare(`SELECT dfl.*, d.model, d.mac, r.number as room_number FROM device_fault_log dfl JOIN devices d ON d.id = dfl.device_id LEFT JOIN rooms r ON r.id = d.room_id WHERE d.hotel_id = ? ORDER BY dfl.created_at DESC LIMIT 50`).all(req.params.hotelId);
    res.json(faults);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── MESSAGES ─────────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/messages', requireAuth, (req, res) => {
  try {
    const msgs = db.prepare(`SELECT m.*, u.name as sent_by_name FROM messages m LEFT JOIN users u ON u.id = m.sent_by WHERE m.hotel_id = ? ORDER BY m.created_at DESC LIMIT 100`).all(req.params.hotelId);
    res.json(msgs);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/messages', requireAuth, (req, res) => {
  try {
    const { subject, body, msg_type, target, is_emergency, valid_hours, scheduled_at } = req.body;
    const r = db.prepare('INSERT INTO messages (hotel_id, subject, body, msg_type, target, is_emergency, valid_hours, scheduled_at, sent_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').run(req.params.hotelId, subject, body, msg_type || 'text', target || 'all', is_emergency ? 1 : 0, valid_hours || 24, scheduled_at || null, req.user.id);
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── CHANNELS ─────────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/channels', requireAuth, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM channels WHERE hotel_id = ? ORDER BY channel_number').all(req.params.hotelId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/channels', requireAuth, (req, res) => {
  try {
    const { channel_number, name, url, status, bitrate } = req.body;
    const r = db.prepare('INSERT INTO channels (hotel_id, channel_number, name, url, status, bitrate) VALUES (?, ?, ?, ?, ?, ?)').run(req.params.hotelId, channel_number, name, url, status || 'up', bitrate || '0 Mbps');
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/channels/:id', requireAuth, (req, res) => {
  try {
    const { name, url, active, channel_number } = req.body;
    db.prepare('UPDATE channels SET name=?, url=?, active=?, channel_number=? WHERE id=? AND hotel_id=?').run(name, url, active ? 1 : 0, channel_number, req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── MOVIES ───────────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/movies', requireAuth, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM movies WHERE hotel_id = ? ORDER BY created_at DESC').all(req.params.hotelId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/movies/:id', requireAuth, (req, res) => {
  try {
    const { price, active } = req.body;
    db.prepare('UPDATE movies SET price=?, active=? WHERE id=? AND hotel_id=?').run(price, active ? 1 : 0, req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── MINIBAR ─────────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/minibar', requireAuth, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM minibar_items WHERE hotel_id = ? AND active = 1').all(req.params.hotelId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/minibar', requireAuth, (req, res) => {
  try {
    const { name, category, cost_price, sell_price, icon, location } = req.body;
    const r = db.prepare('INSERT INTO minibar_items (hotel_id, name, category, cost_price, sell_price, icon, location) VALUES (?, ?, ?, ?, ?, ?, ?)').run(req.params.hotelId, name, category, cost_price, sell_price, icon || '🍶', location || 'Mini Fridge');
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/minibar/:id', requireAuth, (req, res) => {
  try {
    const { name, category, cost_price, sell_price, icon, location, active } = req.body;
    db.prepare('UPDATE minibar_items SET name=?, category=?, cost_price=?, sell_price=?, icon=?, location=?, active=? WHERE id=? AND hotel_id=?').run(name, category, cost_price, sell_price, icon, location, active ? 1 : 0, req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── PORTAL PAGES ─────────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/pages', requireAuth, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM portal_pages WHERE hotel_id = ? ORDER BY sort_order').all(req.params.hotelId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/pages', requireAuth, (req, res) => {
  try {
    const { title } = req.body;
    const max = db.prepare('SELECT MAX(sort_order) as m FROM portal_pages WHERE hotel_id = ?').get(req.params.hotelId);
    const r = db.prepare('INSERT INTO portal_pages (hotel_id, title, sort_order) VALUES (?, ?, ?)').run(req.params.hotelId, title, (max.m || 0) + 1);
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/pages/:id', requireAuth, (req, res) => {
  try {
    const { title, active, sort_order } = req.body;
    db.prepare('UPDATE portal_pages SET title=?, active=?, sort_order=? WHERE id=? AND hotel_id=?').run(title, active ? 1 : 0, sort_order, req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── SIGNAGE ASSETS ───────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/signage/assets', requireAuth, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM signage_assets WHERE hotel_id = ? ORDER BY created_at DESC').all(req.params.hotelId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/signage/assets', requireAuth, (req, res) => {
  try {
    const { name, type, url, size } = req.body;
    const r = db.prepare("INSERT INTO signage_assets (hotel_id, name, type, url, size) VALUES (?, ?, ?, ?, ?)").run(req.params.hotelId, name, type, url || '', size || '');
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/hotels/:hotelId/signage/assets/:id', requireAuth, (req, res) => {
  try {
    db.prepare('DELETE FROM signage_assets WHERE id = ? AND hotel_id = ?').run(req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── SIGNAGE PLAYLISTS ────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/signage/playlists', requireAuth, (req, res) => {
  try {
    const playlists = db.prepare('SELECT * FROM signage_playlists WHERE hotel_id = ? ORDER BY created_at DESC').all(req.params.hotelId);
    const items = db.prepare('SELECT spi.*, sa.name as asset_name, sa.type as asset_type FROM signage_playlist_items spi JOIN signage_assets sa ON sa.id = spi.asset_id WHERE spi.playlist_id IN (SELECT id FROM signage_playlists WHERE hotel_id = ?) ORDER BY spi.sort_order').all(req.params.hotelId);
    res.json(playlists.map(p => ({ ...p, items: items.filter(i => i.playlist_id === p.id) })));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/signage/playlists', requireAuth, (req, res) => {
  try {
    const { name, items = [] } = req.body;
    const r = db.prepare('INSERT INTO signage_playlists (hotel_id, name) VALUES (?, ?)').run(req.params.hotelId, name);
    const pid = r.lastInsertRowid;
    const ins = db.prepare('INSERT INTO signage_playlist_items (playlist_id, asset_id, duration, sort_order) VALUES (?, ?, ?, ?)');
    items.forEach((item, i) => ins.run(pid, item.asset_id, item.duration || 10, i));
    res.json({ id: pid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/signage/playlists/:id', requireAuth, (req, res) => {
  try {
    const { name, items } = req.body;
    db.prepare('UPDATE signage_playlists SET name = ? WHERE id = ? AND hotel_id = ?').run(name, req.params.id, req.params.hotelId);
    if (items) {
      db.prepare('DELETE FROM signage_playlist_items WHERE playlist_id = ?').run(req.params.id);
      const ins = db.prepare('INSERT INTO signage_playlist_items (playlist_id, asset_id, duration, sort_order) VALUES (?, ?, ?, ?)');
      items.forEach((item, i) => ins.run(req.params.id, item.asset_id, item.duration || 10, i));
    }
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/hotels/:hotelId/signage/playlists/:id', requireAuth, (req, res) => {
  try {
    db.prepare('DELETE FROM signage_playlists WHERE id = ? AND hotel_id = ?').run(req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── SIGNAGE SCREENS ──────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/signage/screens', requireAuth, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM signage_screens WHERE hotel_id = ? ORDER BY name').all(req.params.hotelId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/signage/screens', requireAuth, (req, res) => {
  try {
    const { name, location, resolution, ip } = req.body;
    const r = db.prepare('INSERT INTO signage_screens (hotel_id, name, location, resolution, ip) VALUES (?, ?, ?, ?, ?)').run(req.params.hotelId, name, location || '', resolution || '1920x1080', ip || '');
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/signage/screens/:id', requireAuth, (req, res) => {
  try {
    const { name, location, resolution, status, ip } = req.body;
    db.prepare('UPDATE signage_screens SET name=?, location=?, resolution=?, status=?, ip=? WHERE id=? AND hotel_id=?').run(name, location, resolution, status, ip, req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/hotels/:hotelId/signage/screens/:id', requireAuth, (req, res) => {
  try {
    db.prepare('DELETE FROM signage_screens WHERE id = ? AND hotel_id = ?').run(req.params.id, req.params.hotelId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── SIGNAGE SCHEDULES ────────────────────────────────────────────────────────
app.get('/api/hotels/:hotelId/signage/schedules', requireAuth, (req, res) => {
  try {
    res.json(db.prepare(`
      SELECT ss.*, sc.name as screen_name, sp.name as playlist_name
      FROM signage_schedules ss
      JOIN signage_screens sc ON sc.id = ss.screen_id
      JOIN signage_playlists sp ON sp.id = ss.playlist_id
      WHERE sc.hotel_id = ?
      ORDER BY sc.name, ss.start_time
    `).all(req.params.hotelId));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/hotels/:hotelId/signage/schedules', requireAuth, (req, res) => {
  try {
    const { screen_id, playlist_id, start_time, end_time, days_of_week } = req.body;
    const r = db.prepare('INSERT INTO signage_schedules (screen_id, playlist_id, start_time, end_time, days_of_week) VALUES (?, ?, ?, ?, ?)').run(screen_id, playlist_id, start_time, end_time, days_of_week || 'Mon-Sun');
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/hotels/:hotelId/signage/schedules/:id', requireAuth, (req, res) => {
  try {
    const { start_time, end_time, days_of_week, active, playlist_id } = req.body;
    db.prepare('UPDATE signage_schedules SET start_time=?, end_time=?, days_of_week=?, active=?, playlist_id=? WHERE id=?').run(start_time, end_time, days_of_week, active ? 1 : 0, playlist_id, req.params.id);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/hotels/:hotelId/signage/schedules/:id', requireAuth, (req, res) => {
  try {
    db.prepare('DELETE FROM signage_schedules WHERE id = ?').run(req.params.id);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── SERVE FRONTEND (must be LAST, after all /api routes) ─────────────────────
const fs = require('fs');
const distPath = path.join(__dirname, '../dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  // Only catch non-API routes for SPA routing
  app.get(/^(?!\/api).*$/, (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
} else {
  console.warn('⚠️  No dist/ folder found — run: npx vite build');
}

// ─── GLOBAL ERROR HANDLER ─────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`🚀 Streamvision CMS v${APP_VERSION} running on http://localhost:${PORT}`);
});
