let Database;
try {
  Database = require('better-sqlite3');
} catch(e) {
  console.error('❌ better-sqlite3 failed to load:', e.message);
  console.error('   Try: npm rebuild better-sqlite3 --build-from-source');
  process.exit(1);
}

const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const DATA_DIR = path.join(__dirname, '../data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'streamtv.db');
console.log('📂 Database path:', DB_PATH);

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS hotel_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, code TEXT UNIQUE NOT NULL,
    country TEXT, contact_email TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS hotels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER REFERENCES hotel_groups(id),
    name TEXT NOT NULL, code TEXT UNIQUE NOT NULL,
    address TEXT, city TEXT, country TEXT,
    timezone TEXT DEFAULT 'Australia/Darwin',
    total_rooms INTEGER DEFAULT 0, contact_email TEXT,
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('superadmin','group_admin','hotel_admin','hotel_staff')),
    group_id INTEGER REFERENCES hotel_groups(id),
    hotel_id INTEGER REFERENCES hotels(id),
    active INTEGER DEFAULT 1, last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS user_hotel_access (
    user_id INTEGER REFERENCES users(id),
    hotel_id INTEGER REFERENCES hotels(id),
    PRIMARY KEY (user_id, hotel_id)
  );
  CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    number TEXT NOT NULL, type TEXT DEFAULT 'Standard',
    floor INTEGER DEFAULT 1, status TEXT DEFAULT 'vacant',
    guest_name TEXT, guest_email TEXT,
    restriction_vod INTEGER DEFAULT 0, restriction_adult INTEGER DEFAULT 0,
    restriction_billing INTEGER DEFAULT 0, restriction_menu INTEGER DEFAULT 0,
    restriction_all INTEGER DEFAULT 0, discount INTEGER DEFAULT 0,
    UNIQUE(hotel_id, number)
  );
  CREATE TABLE IF NOT EXISTS devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    room_id INTEGER REFERENCES rooms(id),
    mac TEXT UNIQUE, ip TEXT, model TEXT,
    status TEXT DEFAULT 'online', firmware_version TEXT,
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP, fault_note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS device_fault_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id INTEGER REFERENCES devices(id),
    fault_type TEXT, note TEXT, resolved INTEGER DEFAULT 0,
    resolved_at DATETIME, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    subject TEXT, body TEXT, msg_type TEXT DEFAULT 'text',
    target TEXT DEFAULT 'all', is_emergency INTEGER DEFAULT 0,
    status TEXT DEFAULT 'sent', scheduled_at DATETIME,
    valid_hours INTEGER DEFAULT 24,
    sent_by INTEGER REFERENCES users(id),
    read_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    channel_number INTEGER, name TEXT, url TEXT,
    pmt_pid INTEGER, service_id INTEGER, logo TEXT,
    status TEXT DEFAULT 'up', bitrate TEXT, active INTEGER DEFAULT 1,
    UNIQUE(hotel_id, channel_number)
  );
  CREATE TABLE IF NOT EXISTS movies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    title TEXT, year INTEGER, genre TEXT, rating REAL,
    price REAL DEFAULT 4.99, imdb_id TEXT, poster TEXT,
    description TEXT, active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS minibar_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    name TEXT, category TEXT DEFAULT 'Beverage',
    cost_price REAL, sell_price REAL,
    icon TEXT DEFAULT '🍶', location TEXT DEFAULT 'Mini Fridge',
    active INTEGER DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS portal_pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    title TEXT, sort_order INTEGER DEFAULT 0, active INTEGER DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS signage_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    name TEXT NOT NULL, type TEXT NOT NULL,
    url TEXT, size TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS signage_playlists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    name TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS signage_playlist_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    playlist_id INTEGER REFERENCES signage_playlists(id) ON DELETE CASCADE,
    asset_id INTEGER REFERENCES signage_assets(id) ON DELETE CASCADE,
    duration INTEGER DEFAULT 10, sort_order INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS signage_screens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hotel_id INTEGER REFERENCES hotels(id),
    name TEXT NOT NULL, location TEXT,
    resolution TEXT DEFAULT '1920x1080',
    status TEXT DEFAULT 'offline',
    ip TEXT, last_seen DATETIME
  );
  CREATE TABLE IF NOT EXISTS signage_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    screen_id INTEGER REFERENCES signage_screens(id) ON DELETE CASCADE,
    playlist_id INTEGER REFERENCES signage_playlists(id) ON DELETE CASCADE,
    start_time TEXT, end_time TEXT,
    days_of_week TEXT DEFAULT 'Mon-Sun',
    active INTEGER DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id),
    hotel_id INTEGER, action TEXT, detail TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

function seed() {
  const existing = db.prepare('SELECT COUNT(*) as c FROM users').get();
  if (existing.c > 0) { console.log('✅ Database ready (' + existing.c + ' users)'); return; }
  console.log('🌱 Seeding database...');

  const hash = (pw) => bcrypt.hashSync(pw, 10);

  const ig = db.prepare('INSERT INTO hotel_groups (name, code, country, contact_email) VALUES (?, ?, ?, ?)');
  const g1 = ig.run('Hilton Portfolio', 'HILTON', 'Australia', 'portfolio@hilton.com');
  const g2 = ig.run('Accor Hotels', 'ACCOR', 'Australia', 'portfolio@accor.com');

  const ih = db.prepare('INSERT INTO hotels (group_id, name, code, city, country, timezone, total_rooms, contact_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
  const h1 = ih.run(g1.lastInsertRowid, 'Hilton Garden Inn Darwin', 'HGI-DRW', 'Darwin', 'Australia', 'Australia/Darwin', 193, 'gm@hgidarwin.com.au');
  const h2 = ih.run(g1.lastInsertRowid, 'Hilton Garden Inn Sydney', 'HGI-SYD', 'Sydney', 'Australia', 'Australia/Sydney', 240, 'gm@hgisydney.com.au');
  const h3 = ih.run(g2.lastInsertRowid, 'Novotel Brisbane', 'NOV-BNE', 'Brisbane', 'Australia', 'Australia/Brisbane', 180, 'gm@novotelbrisbane.com.au');

  const iu = db.prepare('INSERT INTO users (email, password_hash, name, role, group_id, hotel_id) VALUES (?, ?, ?, ?, ?, ?)');
  iu.run('admin@streamvision.com.au', hash('StreamTV2026!'), 'Greg (Streamvision)', 'superadmin', null, null);
  const ga1 = iu.run('portfolio@hilton.com', hash('Hilton2026!'), 'Hilton Portfolio Manager', 'group_admin', g1.lastInsertRowid, null);
  iu.run('portfolio@accor.com', hash('Accor2026!'), 'Accor Portfolio Manager', 'group_admin', g2.lastInsertRowid, null);
  iu.run('manager@hgidarwin.com.au', hash('HotelDemo2026!'), 'Darwin GM', 'hotel_admin', g1.lastInsertRowid, h1.lastInsertRowid);
  iu.run('manager@hgisydney.com.au', hash('SydneyDemo2026!'), 'Sydney GM', 'hotel_admin', g1.lastInsertRowid, h2.lastInsertRowid);
  const staff = iu.run('reception@hgidarwin.com.au', hash('Staff2026!'), 'Reception Team', 'hotel_staff', null, h1.lastInsertRowid);

  const ia = db.prepare('INSERT INTO user_hotel_access (user_id, hotel_id) VALUES (?, ?)');
  ia.run(ga1.lastInsertRowid, h1.lastInsertRowid);
  ia.run(ga1.lastInsertRowid, h2.lastInsertRowid);

  const ir = db.prepare('INSERT INTO rooms (hotel_id, number, type, floor, status, guest_name) VALUES (?, ?, ?, ?, ?, ?)');
  [
    ['201','Standard',2,'occupied','James T.'], ['202','Standard',2,'occupied','Sarah K.'],
    ['203','Deluxe',2,'occupied','M. Chen'], ['204','Standard',2,'vacant',null],
    ['205','Suite',2,'occupied','R. Patel'], ['301','Standard',3,'occupied','C. Wilson'],
    ['302','Deluxe',3,'vacant',null], ['401','Penthouse',4,'occupied','A. Smith'],
    ['Bar','Venue',0,'active',null], ['Conf-A','Conference',1,'active',null],
  ].forEach(r => ir.run(h1.lastInsertRowid, ...r));

  const rooms = db.prepare('SELECT id, number FROM rooms WHERE hotel_id = ?').all(h1.lastInsertRowid);
  const rm = {}; rooms.forEach(r => rm[r.number] = r.id);

  const id = db.prepare("INSERT INTO devices (hotel_id, room_id, mac, ip, model, status, firmware_version, last_seen, fault_note) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), ?)");
  [
    [rm['201'],'f0:70:4f:10:e1:c6','192.168.242.171','HAU8000','online','3.2.0',null],
    [rm['202'],'f0:70:4f:9a:e5:5b','192.168.242.174','HAU8000','online','3.2.0',null],
    [rm['203'],'20:15:de:86:9c:d1','192.168.243.38','HAQ60','fault','3.1.2','Socket timeout'],
    [rm['301'],'f0:70:4f:9a:ec:1b','192.168.242.216','HAU8000','offline','3.2.0','No ping response'],
    [rm['205'],'f0:70:4f:9a:e9:ad','192.168.242.120','HAU8000','online','3.2.0',null],
  ].forEach(d => id.run(h1.lastInsertRowid, ...d));

  const ic = db.prepare('INSERT INTO channels (hotel_id, channel_number, name, url, status, bitrate) VALUES (?, ?, ?, ?, ?, ?)');
  [
    [1,'10 BOLD NT','udp://239.1.0.1:1234','up','4.3 Mbps'],
    [10,'10HD DDT','udp://239.1.0.10:1234','up','8.9 Mbps'],
    [11,'10 Peach Darwin','udp://239.1.0.11:1234','up','4.8 Mbps'],
    [20,'ABC TV HD NT','udp://239.1.0.2:1234','up','4.8 Mbps'],
    [30,'SBS HD NT','udp://239.1.0.3:1234','up','2.7 Mbps'],
    [35,'SBS World Watch','udp://239.1.0.35:1234','down','0 Mbps'],
  ].forEach(c => ic.run(h1.lastInsertRowid, ...c));

  const im = db.prepare('INSERT INTO movies (hotel_id, title, year, genre, rating, price, poster) VALUES (?, ?, ?, ?, ?, ?, ?)');
  [
    ['Dune: Part Two',2024,'Sci-Fi',8.5,6.99,'🏜️'],
    ['Oppenheimer',2023,'Drama',8.9,5.99,'💣'],
    ['The Batman',2022,'Action',7.8,4.99,'🦇'],
    ['Barbie',2023,'Comedy',6.8,4.99,'💗'],
    ['Top Gun: Maverick',2022,'Action',8.3,4.99,'✈️'],
  ].forEach(m => im.run(h1.lastInsertRowid, ...m));

  const imb = db.prepare('INSERT INTO minibar_items (hotel_id, name, category, cost_price, sell_price, icon, location) VALUES (?, ?, ?, ?, ?, ?, ?)');
  [
    ['Sparkling Water','Beverage',1.20,4.50,'💧','Mini Fridge'],
    ['Craft Beer','Beverage',3.50,9.00,'🍺','Mini Fridge'],
    ['Pringles','Snack',0.80,3.50,'🥔','Cabinet'],
    ['Red Bull','Beverage',1.80,6.00,'⚡','Mini Fridge'],
    ['Red Wine','Beverage',8.00,22.00,'🍷','Wine Rack'],
  ].forEach(i => imb.run(h1.lastInsertRowid, ...i));

  const ip = db.prepare('INSERT INTO portal_pages (hotel_id, title, sort_order, active) VALUES (?, ?, ?, 1)');
  ['Guest Services','Watch TV','Movies','Dining','Streamcast'].forEach((t,i) => ip.run(h1.lastInsertRowid, t, i));

  const devs = db.prepare("SELECT id FROM devices WHERE status != 'online' AND hotel_id = ?").all(h1.lastInsertRowid);
  const ifl = db.prepare('INSERT INTO device_fault_log (device_id, fault_type, note, resolved) VALUES (?, ?, ?, 0)');
  if (devs[0]) ifl.run(devs[0].id, 'Socket Timeout', 'Recurring socket timeout');
  if (devs[1]) ifl.run(devs[1].id, 'No Ping', 'Device not responding for 3+ hours');

  console.log('✅ Seed complete');
}

seed();
module.exports = db;
