#!/usr/bin/env bash
# Streamvision CMS — Management helper
# Usage: streamtv {status|start|stop|restart|logs|update|backup|shell}
set -euo pipefail

DEPLOY_DIR="/opt/streamtv-cms"
cd "$DEPLOY_DIR"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

case "${1:-status}" in
  status)
    echo -e "${CYAN}── Streamvision CMS ──────────────────────────────${NC}"
    docker compose ps
    echo ""
    echo -e "${CYAN}── Volume (DB) ────────────────────────────────────${NC}"
    docker volume inspect streamtv_data \
      --format 'Mountpoint: {{.Mountpoint}}  Created: {{.CreatedAt}}' 2>/dev/null || true
    ;;

  start)
    docker compose up -d
    echo -e "${GREEN}✓ Started${NC}"
    ;;

  stop)
    docker compose stop
    echo -e "${YELLOW}● Stopped (data preserved)${NC}"
    ;;

  restart)
    docker compose restart
    echo -e "${GREEN}✓ Restarted${NC}"
    ;;

  logs)
    docker compose logs -f --tail=100 app
    ;;

  update)
    [[ $EUID -ne 0 ]] && echo "Update requires sudo" && exit 1
    echo "Rebuilding image..."
    docker compose build --quiet
    echo "Replacing container (data volume preserved)..."
    docker compose up -d --force-recreate
    echo -e "${GREEN}✓ Update complete${NC}"
    ;;

  backup)
    [[ -z "${BACKUP_S3_BUCKET:-}" ]] && source .env 2>/dev/null || true
    [[ -z "${BACKUP_S3_BUCKET:-}" ]] && echo "Set BACKUP_S3_BUCKET in .env first." && exit 1
    docker compose --profile backup run --rm backup
    ;;

  nginx-reload)
    docker compose exec nginx nginx -s reload
    echo -e "${GREEN}✓ Nginx reloaded${NC}"
    ;;

  shell)
    docker compose exec app sh
    ;;

  db)
    # Open SQLite shell directly against the live database
    docker run --rm -it \
      -v streamtv_data:/data \
      alpine sh -c "apk add -q sqlite && sqlite3 /data/streamtv.db"
    ;;

  *)
    echo "Usage: streamtv {status|start|stop|restart|logs|update|backup|nginx-reload|shell|db}"
    exit 1
    ;;
esac
