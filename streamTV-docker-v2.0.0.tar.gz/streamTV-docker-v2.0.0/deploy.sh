#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  Streamvision CMS — AWS EC2 deploy script
#  Run this ONCE on a fresh Ubuntu 24.04 EC2 instance.
#  Then use manage.sh for day-to-day operations.
#
#  Usage: sudo bash deploy.sh [--domain yourdomain.com]
# ═══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info()    { echo -e "${CYAN}▸ $*${NC}"; }
success() { echo -e "${GREEN}✓ $*${NC}"; }
warn()    { echo -e "${YELLOW}⚠  $*${NC}"; }
die()     { echo -e "${RED}✗ $*${NC}"; exit 1; }

[[ $EUID -ne 0 ]] && die "Run as root: sudo bash deploy.sh"

DOMAIN=""
DEPLOY_DIR="/opt/streamtv-cms"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain) DOMAIN="$2"; shift 2 ;;
    *) warn "Unknown: $1"; shift ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${BOLD}${CYAN}  ┌──────────────────────────────────────────────┐"
echo -e "  │   streamvision CMS — Docker Deploy          │"
echo -e "  └──────────────────────────────────────────────┘${NC}"
echo ""

# ── 1. System packages ─────────────────────────────────────────────────────────
info "[1/5] Installing system packages..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  ca-certificates curl gnupg lsb-release ufw
success "System packages ready"

# ── 2. Docker ─────────────────────────────────────────────────────────────────
info "[2/5] Installing Docker..."
if command -v docker &>/dev/null; then
  success "Docker $(docker --version | cut -d' ' -f3 | tr -d ',') already installed"
else
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
    https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io \
    docker-buildx-plugin docker-compose-plugin
  systemctl enable docker
  systemctl start docker
  success "Docker $(docker --version | cut -d' ' -f3 | tr -d ',') installed"
fi

# ── 3. Deploy files ────────────────────────────────────────────────────────────
info "[3/5] Setting up application..."
mkdir -p "$DEPLOY_DIR"
cp -r "$SCRIPT_DIR"/. "$DEPLOY_DIR/"

# Generate .env if not present
if [[ ! -f "$DEPLOY_DIR/.env" ]]; then
  JWT_SECRET=$(openssl rand -hex 32)
  cat > "$DEPLOY_DIR/.env" <<ENVEOF
JWT_SECRET=${JWT_SECRET}
AWS_REGION=ap-southeast-2
BACKUP_S3_BUCKET=
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
ENVEOF
  chmod 600 "$DEPLOY_DIR/.env"
  warn ".env created with random JWT secret — add S3 bucket details to enable backups"
else
  success ".env already exists — keeping current config"
fi

chmod +x "$DEPLOY_DIR/manage.sh" 2>/dev/null || true

# Symlink manage.sh for convenience
ln -sf "$DEPLOY_DIR/manage.sh" /usr/local/bin/streamtv 2>/dev/null || true

success "Files deployed to $DEPLOY_DIR"

# ── 4. Build and start ─────────────────────────────────────────────────────────
info "[4/5] Building Docker image and starting services..."
cd "$DEPLOY_DIR"
docker compose build --quiet
docker compose up -d

# Wait for health
info "Waiting for app to be healthy..."
for i in $(seq 1 24); do
  STATUS=$(docker compose ps --format json app 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('Health',''))" 2>/dev/null || echo "")
  if [[ "$STATUS" == "healthy" ]] || docker compose ps app 2>/dev/null | grep -q "healthy"; then
    break
  fi
  sleep 5
done
success "Services running"

# ── 5. Firewall ────────────────────────────────────────────────────────────────
info "[5/5] Configuring firewall..."
ufw allow OpenSSH    >/dev/null 2>&1 || true
ufw allow 80/tcp     >/dev/null 2>&1 || true
ufw allow 443/tcp    >/dev/null 2>&1 || true
ufw --force enable   >/dev/null 2>&1 || true
success "Firewall: SSH + 80 + 443 open"

# ── SSL hint ───────────────────────────────────────────────────────────────────
if [[ -n "$DOMAIN" ]]; then
  info "To enable HTTPS for ${DOMAIN}:"
  echo    "  apt install certbot python3-certbot-nginx"
  echo -e "  ${BOLD}certbot certonly --webroot -w /var/lib/docker/volumes/streamtv_certbot_www/_data -d ${DOMAIN}${NC}"
  echo    "  Then uncomment the HTTPS block in nginx/conf.d/streamtv.conf and: streamtv nginx-reload"
fi

# ── Summary ────────────────────────────────────────────────────────────────────
PUBLIC_IP=$(curl -sf --max-time 5 http://checkip.amazonaws.com 2>/dev/null || echo "<ec2-ip>")

echo ""
echo -e "${GREEN}${BOLD}"
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║        Deployment complete!  ✓                ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "  ${BOLD}URL:${NC}           http://${DOMAIN:-$PUBLIC_IP}"
echo -e "  ${BOLD}Deploy dir:${NC}    $DEPLOY_DIR"
echo -e "  ${BOLD}Manage:${NC}        streamtv {status|restart|logs|update|backup}"
echo ""
echo -e "  ${BOLD}DB volume:${NC}     docker volume inspect streamtv_data"
echo -e "  ${BOLD}DB backup:${NC}     Add BACKUP_S3_BUCKET to $DEPLOY_DIR/.env"
echo ""
echo -e "  ${BOLD}Default logins:${NC}"
printf  "    %-12s %-40s %s\n" "Superadmin"  "admin@streamvision.com.au"  "StreamTV2026!"
printf  "    %-12s %-40s %s\n" "Group Admin" "portfolio@hilton.com"       "Hilton2026!"
printf  "    %-12s %-40s %s\n" "Hotel Admin" "manager@hgidarwin.com.au"   "HotelDemo2026!"
echo ""
echo -e "  ${YELLOW}⚠  Change default passwords immediately!${NC}"
echo ""
