#!/bin/sh
# Streamvision CMS — SQLite backup to S3
# Runs inside the backup container. Loops every 6 hours.
# Set BACKUP_S3_BUCKET in .env to enable.

set -e

if [ -z "$BACKUP_S3_BUCKET" ]; then
  echo "[backup] BACKUP_S3_BUCKET not set — backup disabled. Exiting."
  exit 0
fi

DB_PATH="/data/streamtv.db"
REGION="${AWS_DEFAULT_REGION:-ap-southeast-2}"

run_backup() {
  if [ ! -f "$DB_PATH" ]; then
    echo "[backup] Database not found at $DB_PATH — skipping."
    return
  fi

  TIMESTAMP=$(date +%Y%m%d-%H%M%S)
  BACKUP_KEY="streamtv-cms/backups/streamtv-${TIMESTAMP}.db"
  LATEST_KEY="streamtv-cms/backups/streamtv-latest.db"

  echo "[backup] Uploading $DB_PATH → s3://${BACKUP_S3_BUCKET}/${BACKUP_KEY}"
  aws s3 cp "$DB_PATH" "s3://${BACKUP_S3_BUCKET}/${BACKUP_KEY}" \
    --region "$REGION" --sse aws:kms --quiet
  aws s3 cp "$DB_PATH" "s3://${BACKUP_S3_BUCKET}/${LATEST_KEY}" \
    --region "$REGION" --sse aws:kms --quiet

  echo "[backup] ✓ Done — s3://${BACKUP_S3_BUCKET}/${BACKUP_KEY}"

  # Prune backups older than 30 days
  CUTOFF=$(date -d '30 days ago' +%Y-%m-%dT%H:%M:%S 2>/dev/null || \
           date -v-30d +%Y-%m-%dT%H:%M:%S 2>/dev/null || echo "")
  if [ -n "$CUTOFF" ]; then
    aws s3 ls "s3://${BACKUP_S3_BUCKET}/streamtv-cms/backups/" --region "$REGION" | \
      awk '{print $4}' | grep -v 'latest' | while read -r key; do
        FILE_DATE=$(echo "$key" | grep -oE '[0-9]{8}-[0-9]{6}' | head -1)
        if [ -n "$FILE_DATE" ] && [ "$FILE_DATE" \< "$(date -d '30 days ago' +%Y%m%d 2>/dev/null || echo '')" ]; then
          aws s3 rm "s3://${BACKUP_S3_BUCKET}/streamtv-cms/backups/${key}" \
            --region "$REGION" --quiet && echo "[backup] Pruned: ${key}"
        fi
      done
  fi
}

# Run immediately on start, then every 6 hours
run_backup
while true; do
  sleep 21600
  run_backup
done
