#!/bin/bash
# Streamvision CMS — Restore SQLite from S3
# Usage: ./scripts/restore.sh [s3://bucket/path/to/backup.db]
set -euo pipefail

source "$(dirname "$0")/../.env" 2>/dev/null || true

REGION="${AWS_DEFAULT_REGION:-ap-southeast-2}"
VOLUME_NAME="streamtv_data"

if [ -n "${1:-}" ]; then
  S3_PATH="$1"
else
  if [ -z "${BACKUP_S3_BUCKET:-}" ]; then
    echo "Set BACKUP_S3_BUCKET in .env or pass S3 path as argument."
    exit 1
  fi
  S3_PATH="s3://${BACKUP_S3_BUCKET}/streamtv-cms/backups/streamtv-latest.db"
fi

echo "⚠  This will REPLACE the current database with: $S3_PATH"
read -rp "Continue? [y/N] " yn
[[ "$yn" =~ ^[Yy]$ ]] || exit 1

echo "Stopping app..."
docker compose stop app

echo "Downloading backup..."
TMPFILE=$(mktemp /tmp/streamtv-restore-XXXXXX.db)
aws s3 cp "$S3_PATH" "$TMPFILE" --region "$REGION"

echo "Copying into Docker volume..."
docker run --rm \
  -v "${VOLUME_NAME}:/data" \
  -v "${TMPFILE}:/backup.db:ro" \
  alpine sh -c "cp /backup.db /data/streamtv.db && chown 1000:1000 /data/streamtv.db"
rm -f "$TMPFILE"

echo "Restarting app..."
docker compose start app

echo "✓ Restore complete."
