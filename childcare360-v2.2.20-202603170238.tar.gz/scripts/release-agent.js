#!/usr/bin/env node
/**
 * Childcare360 — Autonomous Release Agent
 * Usage:
 *   node scripts/release-agent.js                  # analyse only
 *   node scripts/release-agent.js --fix            # fix criticals
 *   node scripts/release-agent.js --fix --package  # full release
 *   node scripts/release-agent.js --skip-ai        # static only
 *   node scripts/release-agent.js --fix --package --version 2.3.0
 */
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');
const args = process.argv.slice(2);
const FIX     = args.includes('--fix');
const PACKAGE = args.includes('--package');
const SKIP_AI = args.includes('--skip-ai');
const DRY_RUN = args.includes('--dry-run');
const VERBOSE = args.includes('--verbose');
const vIdx    = args.indexOf('--version');
const TARGET_VERSION = vIdx !== -1 ? args[vIdx + 1] : null;
const AI_MODEL   = 'claude-sonnet-4-20250514';
const MAX_RETRIES = 2;

const c = {
  reset:'\x1b[0m', bold:'\x1b[1m', dim:'\x1b[2m',
  red:'\x1b[31m', green:'\x1b[32m', yellow:'\x1b[33m',
  cyan:'\x1b[36m', magenta:'\x1b[35m',
};
const log  = (...a) => console.log(...a);
const ok   = m => log(`  ${c.green}✓${c.reset}  ${m}`);
const fail = m => log(`  ${c.red}✗${c.reset}  ${m}`);
const warn = m => log(`  ${c.yellow}⚠${c.reset}  ${m}`);
const info = m => log(`  ${c.cyan}ℹ${c.reset}  ${m}`);
const hdr  = m => log(`\n${c.bold}${c.cyan}── ${m} ${'─'.repeat(Math.max(0,50-m.length))}${c.reset}`);

const TENANT_SCOPED = [
  'rooms','children','educators','roster_entries','shift_fill_requests',
  'shift_fill_attempts','educator_absences','leave_requests','learning_stories',
  'story_photos','story_children','learning_albums','eylf_progressions',
  'weekly_reports','compliance_scans','equipment_register','families',
  'parent_messages','enrolment_applications','waitlist_entries','invoices',
  'invoice_items','ccs_claims','excursions','excursion_children',
  'excursion_permissions','audit_log','tenant_members','educator_notes',
  'educator_availability','lunch_cover_sessions','roster_templates','roster_periods',
];

// These files do cross-tenant queries intentionally (platform admin)
const PLATFORM_ADMIN_FILES = ['server/platform.js', 'server/admin.js'];
// These server files don't need to be mounted as routes
const SKIP_MOUNT_CHECK = ['server/db.js','server/middleware.js','server/seed-cn.js',
  'server/seed-rich.js','server/index.js','server/retell.js'];
const SKIP_SQL_CHECK = ['server/seed-cn.js','server/seed-rich.js'];

function readFile(rel) {
  const abs = path.join(ROOT, rel);
  return fs.existsSync(abs) ? fs.readFileSync(abs, 'utf8') : null;
}
function writeFile(rel, content) {
  if (DRY_RUN) { info('[dry-run] would write ' + rel); return; }
  fs.writeFileSync(path.join(ROOT, rel), content, 'utf8');
}
function lineOf(content, idx) {
  return content.substring(0, idx).split('\n').length;
}
function extractLines(content, lineNum, ctx = 30) {
  const lines = content.split('\n');
  const start = Math.max(0, lineNum - ctx - 1);
  const end   = Math.min(lines.length, lineNum + ctx);
  return lines.slice(start, end).map((l,i) => `${start+i+1}: ${l}`).join('\n');
}
function dedup(findings) {
  const seen = new Set();
  return findings.filter(f => {
    const k = `${f.file}:${f.line}:${f.rule}`;
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
}

function discoverFiles() {
  const srcDir = path.join(ROOT, 'src');
  const srvDir = path.join(ROOT, 'server');
  const jsx = fs.existsSync(srcDir)
    ? fs.readdirSync(srcDir).filter(f => f.endsWith('.jsx') || f.endsWith('.js')).map(f => 'src/' + f)
    : [];
  const server = fs.existsSync(srvDir)
    ? fs.readdirSync(srvDir).filter(f => f.endsWith('.js') && !f.endsWith('.bak')).map(f => 'server/' + f)
    : [];
  return { jsx, server };
}

function getMountedRoutes() {
  const idx = readFile('server/index.js');
  if (!idx) return new Set();
  const mounted = new Set();
  for (const m of idx.matchAll(/from\s+['"]\.\/([\w-]+)(?:\.js)?['"]/g))
    mounted.add(m[1]);
  return mounted;
}

// Built-in fixes that don't need the AI API
function applyBuiltinFix(file, content, finding) {
  let updated = content;

  if (finding.rule === 'no-form-tags') {
    updated = updated.replace(/<form\s+onSubmit=\{([^}]+)\}([^>]*)>/g, '<div$2>');
    updated = updated.replace(/<form([^>]*)>/g, '<div$1>');
    updated = updated.replace(/<\/form>/g, '</div>');
    updated = updated.replace(/(<button[^>]*)\s+type="submit"/g, '$1 type="button"');
    updated = updated.replace(/(<button[^>]*)\s+type='submit'/g, "$1 type='button'");
    return updated !== content ? updated : null;
  }

  if (finding.rule === 'no-css-imports') {
    updated = updated.replace(/^import\s+['"][^'"]+\.css['"]\s*;?\s*\n/gm, '');
    return updated !== content ? updated : null;
  }

  if (finding.rule === 'version-mismatch') {
    try {
      const pkg = JSON.parse(readFile('package.json'));
      updated = updated.replace(/v\d+\.\d+\.\d+/, 'v' + pkg.version);
      return updated !== content ? updated : null;
    } catch { return null; }
  }

  return null;
}

function runStaticAnalysis() {
  const findings = [];
  const FILES  = discoverFiles();
  const mounted = getMountedRoutes();

  for (const file of FILES.jsx) {
    const content = readFile(file);
    if (!content) continue;

    for (const m of content.matchAll(/<form[\s>]/g))
      findings.push({ severity:'critical', file, line:lineOf(content,m.index),
        rule:'no-form-tags', fixable_without_ai:true,
        description:'<form> tag — React hydration conflict risk.',
        fix_hint:'Replace with <div>, move onSubmit to button onClick.' });

    const rr = content.match(/from ['"]react-router/);
    if (rr) findings.push({ severity:'critical', file, line:lineOf(content,rr.index),
      rule:'no-react-router',
      description:'React Router import detected.',
      fix_hint:'Remove — use useState activeTab navigation.' });

    for (const m of content.matchAll(/import\s+['"][^'"]+\.css['"]/g))
      findings.push({ severity:'critical', file, line:lineOf(content,m.index),
        rule:'no-css-imports', fixable_without_ai:true,
        description:'CSS file import: ' + m[0],
        fix_hint:'Remove import, use inline style={{}}.' });

    for (const m of content.matchAll(/console\.log\(/g))
      findings.push({ severity:'warning', file, line:lineOf(content,m.index),
        rule:'no-console-log',
        description:'console.log() in production component.',
        fix_hint:'Remove or guard with NODE_ENV check.' });
  }

  for (const file of FILES.server) {
    const content = readFile(file);
    if (!content) continue;
    const isDb       = file === 'server/db.js' || SKIP_SQL_CHECK.includes(file);
    const isPlatform = PLATFORM_ADMIN_FILES.includes(file);

    if (!isDb) {
      for (const m of content.matchAll(/router\.(get|post|put|delete|patch)\s*\([^,\n]+,\s*async\s*(?:\([^)]*\)|\w+)\s*=>/g)) {
        const after = content.substring(m.index, m.index + 400);
        if (!after.includes('try {') && !after.includes('try{'))
          findings.push({ severity:'warning', file, line:lineOf(content,m.index),
            rule:'async-missing-try-catch',
            description:'Async route handler without try/catch — crash risk.',
            fix_hint:'Wrap body in try { } catch(e) { res.status(500).json({error:e.message}); }' });
      }
    }

    if (!isDb && !isPlatform) {
      // Use separate patterns per quote type so inner quotes don't prematurely end the match.
      // Also check a ±8 line window for tenant_id to catch dynamic WHERE clauses (${where} patterns).
      const sqlPatterns = [
        /\.prepare\s*\(\s*`([\s\S]*?)`\s*\)/g,   // template literals — stop at backtick only
        /\.prepare\s*\(\s*'([^']*?)'\s*\)/g,       // single-quoted
        /\.prepare\s*\(\s*"([^"]*?)"\s*\)/g,       // double-quoted
      ];
      const contentLines = content.split('\n');
      for (const pattern of sqlPatterns) {
        for (const m of content.matchAll(pattern)) {
          const sql = m[1].toLowerCase();
          if (/create table|alter table|drop table|pragma|create index/.test(sql)) continue;
          const touched = TENANT_SCOPED.find(t =>
            new RegExp('\\b(from|into|update|join)\\s+' + t + '\\b').test(sql)
          );
          if (!touched) continue;
          // Check the SQL itself for tenant_id
          if (sql.includes('tenant_id')) continue;
          // Check surrounding ±8 lines for tenant_id (catches dynamic ${where} injection patterns)
          const lineNum = lineOf(content, m.index);
          const windowStart = Math.max(0, lineNum - 9);
          const windowEnd   = Math.min(contentLines.length, lineNum + 9);
          const window = contentLines.slice(windowStart, windowEnd).join('\n').toLowerCase();
          if (window.includes('tenant_id')) continue;
          findings.push({ severity:'warning', file, line:lineNum,
            rule:'sql-missing-tenant-id',
            description:`SQL on '${touched}' may lack tenant_id scope — check for data leak.`,
            fix_hint:'Add WHERE tenant_id = ? to the prepared statement.' });
        }
      }
    }

    if (!isDb) {
      for (const m of content.matchAll(/\.prepare\s*\(\s*`[^`]*\$\{[^}]*(?:req\.|body\.|params\.|query\.)[^}]*\}[^`]*`\s*\)/g))
        findings.push({ severity:'critical', file, line:lineOf(content,m.index),
          rule:'sql-injection-risk',
          description:'User input interpolated into SQL — injection risk.',
          fix_hint:'Use ? placeholders in prepared statements.' });
    }

    if (!SKIP_MOUNT_CHECK.includes(file)) {
      const base = path.basename(file, '.js');
      if (!mounted.has(base)) {
        if (content.includes('router.get') || content.includes('router.post') ||
            content.includes('router.put') || content.includes('router.delete'))
          findings.push({ severity:'warning', file, line:1,
            rule:'route-not-mounted',
            description:`server/${base}.js has routes but isn't imported in server/index.js`,
            fix_hint:`Import and mount in server/index.js` });
      }
    }
  }

  const pkg = readFile('package.json');
  const app = readFile('src/App.jsx');
  if (pkg && app) {
    try {
      const pkgVer = JSON.parse(pkg).version;
      const vm = app.match(/v(\d+\.\d+\.\d+)/);
      if (vm && vm[1] !== pkgVer)
        findings.push({ severity:'warning', file:'src/App.jsx', line:1,
          rule:'version-mismatch', fixable_without_ai:true,
          description:`Version mismatch: package.json=${pkgVer}, App.jsx=v${vm[1]}`,
          fix_hint:`Update App.jsx sidebar to v${pkgVer}` });
    } catch {}
  }

  return dedup(findings);
}

const ANALYSIS_SYSTEM = `You are a senior code reviewer for Childcare360 (React 18 + Express + better-sqlite3 + JWT).
CRITICAL RULES: No <form> in JSX. Tenant-scoped SQL needs tenant_id. No hardcoded secrets. Async routes need try/catch. No react-router. No CSS imports.
NOTE: server/platform.js is intentionally cross-tenant (platform admin) — do NOT flag missing tenant_id there.
Respond ONLY with JSON (no markdown): {"findings":[{"severity":"critical"|"warning"|"info","line":N,"rule":"rule-name","description":"...","fix_hint":"..."}]}`;

async function callAI(messages, system, maxTokens = 2000) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error('ANTHROPIC_API_KEY not set');
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type':'application/json', 'x-api-key':key, 'anthropic-version':'2023-06-01' },
    body: JSON.stringify({ model:AI_MODEL, max_tokens:maxTokens, system, messages }),
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${(await res.text()).substring(0,200)}`);
  return (await res.json()).content?.[0]?.text || '';
}

async function runAIAnalysis(FILES) {
  const all = [];
  for (const file of [...FILES.jsx, ...FILES.server]) {
    const content = readFile(file);
    if (!content) continue;
    process.stdout.write(`  ${c.dim}${file.padEnd(45)}${c.reset}`);
    try {
      const body = content.length > 80000 ? content.substring(0,80000) + '\n//[TRUNCATED]' : content;
      const text = await callAI(
        [{ role:'user', content:`Review file: ${file}\n\`\`\`\n${body}\n\`\`\`` }],
        ANALYSIS_SYSTEM
      );
      const clean = text.replace(/^```(?:json)?\n?/m,'').replace(/\n?```\s*$/m,'').trim();
      const result = JSON.parse(clean);
      const findings = (result.findings || []).map(f => ({ ...f, file, source:'ai' }));
      const crits = findings.filter(f => f.severity === 'critical').length;
      const warns = findings.filter(f => f.severity === 'warning').length;
      if (!crits && !warns) process.stdout.write(`${c.green}✓ clean${c.reset}\n`);
      else {
        const parts = [];
        if (crits) parts.push(`${c.red}${crits} critical${c.reset}`);
        if (warns) parts.push(`${c.yellow}${warns} warn${c.reset}`);
        process.stdout.write(parts.join(', ') + '\n');
      }
      all.push(...findings);
    } catch(e) {
      process.stdout.write(`${c.red}error: ${e.message.substring(0,60)}${c.reset}\n`);
    }
    await new Promise(r => setTimeout(r, 250));
  }
  return dedup(all);
}

const FIX_SYSTEM = `Fix a specific bug in Childcare360. Respond ONLY with JSON (no markdown):
{"search":"exact verbatim substring to find (2-5 lines, must be unique in file)","replace":"fixed replacement preserving all logic"}`;

async function generateAIFix(file, content, finding) {
  const ctx = finding.line ? extractLines(content, finding.line, 30) : content.substring(0, 2000);
  const text = await callAI([{ role:'user', content:
    `Fix in ${file}.\nBug: [${finding.rule}] ${finding.description}\nHint: ${finding.fix_hint}\n` +
    `Context:\n\`\`\`\n${ctx}\n\`\`\`\nFull file:\n\`\`\`\n${content.substring(0,60000)}\n\`\`\``
  }], FIX_SYSTEM, 1000);
  const clean = text.replace(/^```(?:json)?\n?/m,'').replace(/\n?```\s*$/m,'').trim();
  const patch = JSON.parse(clean);
  if (!patch.search || patch.replace === undefined) throw new Error('Invalid patch structure');
  if (!content.includes(patch.search)) throw new Error('Search string not found in file');
  const occ = (content.match(new RegExp(patch.search.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'g')) || []).length;
  if (occ > 1) throw new Error(`Search not unique (${occ} matches)`);
  return patch;
}

async function autoFix(allFindings) {
  const criticals = allFindings.filter(f => f.severity === 'critical');
  const byFile = {};
  for (const f of criticals) { if (!byFile[f.file]) byFile[f.file] = []; byFile[f.file].push(f); }
  const fixed = [], failed = [];
  const hasKey = !!process.env.ANTHROPIC_API_KEY;

  for (const [file, bugs] of Object.entries(byFile)) {
    log(`\n  ${c.bold}${file}${c.reset} — ${bugs.length} critical bug(s)`);
    for (const bug of bugs) {
      process.stdout.write(`    ${c.dim}[${bug.rule}] line ${bug.line || '?'}...${c.reset} `);
      let content = readFile(file);

      const builtin = applyBuiltinFix(file, content, bug);
      if (builtin !== null) {
        if (!DRY_RUN) {
          if (!fs.existsSync(path.join(ROOT, file + '.bak'))) writeFile(file + '.bak', content);
          writeFile(file, builtin);
        }
        process.stdout.write(`${c.green}✓ fixed (built-in)${c.reset}${DRY_RUN ? ' [dry-run]' : ''}\n`);
        if (!fixed.includes(file)) fixed.push(file);
        continue;
      }

      if (!hasKey) {
        process.stdout.write(`${c.yellow}⚠ needs ANTHROPIC_API_KEY for AI fix${c.reset}\n`);
        failed.push({ file, rule:bug.rule, error:'Set ANTHROPIC_API_KEY in .env for AI-powered fixes' });
        continue;
      }

      let attempt = 0, succeeded = false;
      while (attempt < MAX_RETRIES && !succeeded) {
        attempt++;
        try {
          const patch = await generateAIFix(file, content, bug);
          const updated = content.replace(patch.search, patch.replace);
          if (updated.length < content.length * 0.8) throw new Error('Fix shrinks file too much');
          if (!DRY_RUN) {
            if (!fs.existsSync(path.join(ROOT, file + '.bak'))) writeFile(file + '.bak', content);
            writeFile(file, updated);
          }
          content = updated;
          process.stdout.write(`${c.green}✓ fixed (AI)${c.reset}${DRY_RUN ? ' [dry-run]' : ''}\n`);
          succeeded = true;
          if (!fixed.includes(file)) fixed.push(file);
        } catch(e) {
          if (attempt < MAX_RETRIES) process.stdout.write('retry... ');
          else {
            process.stdout.write(`${c.red}✗ failed${c.reset}\n`);
            if (VERBOSE) fail('  ' + e.message);
            failed.push({ file, rule:bug.rule, error:e.message });
          }
          await new Promise(r => setTimeout(r, 500));
        }
      }
    }
  }
  return { fixed, failed };
}

function bumpPatch(v) {
  const [a,b,p] = v.split('.').map(Number);
  return `${a}.${b}.${p+1}`;
}

function packageRelease(version) {
  hdr('Packaging');
  const pkgPath = path.join(ROOT, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  const prev = pkg.version;
  pkg.version = version;
  if (!DRY_RUN) {
    fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');
    ok(`package.json ${prev} → ${version}`);
  }
  const appPath = path.join(ROOT, 'src/App.jsx');
  if (fs.existsSync(appPath)) {
    const app = fs.readFileSync(appPath, 'utf8');
    const updated = app.replace(/v\d+\.\d+\.\d+/, 'v' + version);
    if (updated !== app && !DRY_RUN) { fs.writeFileSync(appPath, updated); ok(`App.jsx → v${version}`); }
  }
  const ts = new Date().toISOString().replace(/[-:T]/g,'').substring(0,12);
  const tarName = `childcare360-v${version}-${ts}.tar.gz`;
  if (!DRY_RUN) {
    try {
      const tmpTar = `/tmp/${tarName}`;
      execSync(`tar czf ${tmpTar} \
        --exclude=./data \
        --exclude=./node_modules \
        --exclude=./.env \
        --exclude=./*.bak \
        --exclude=./src/*.bak \
        --exclude=./server/*.bak \
        --exclude=./RELEASE_BUG_REPORT.md \
        -C ${ROOT} .`, { stdio:'pipe' });
      fs.renameSync(tmpTar, path.join(ROOT, tarName));
      ok(`Created: ${c.green}${tarName}${c.reset}`);
    } catch(e) {
      fail('tar failed: ' + e.message);
      process.exit(2);
    }
  } else { info(`[dry-run] would create: ${tarName}`); }

  log(`\n${c.bold}${c.green}Deploy snippet:${c.reset}`);
  log(`${c.dim}──────────────────────────────────────────────────────`);
  log(`kill -9 $(lsof -t -i:3003) 2>/dev/null`);
  log(`cd ~/childcare360-app`);
  log(`tar xf /media/sf_VM_Shared_Folder/${tarName} --strip-components=1`);
  log(`npm install`);
  log(`npx vite build`);
  log(`nohup node server/index.js > childcare360.log 2>&1 &`);
  log(`sleep 3 && curl -s http://localhost:3003/health${c.reset}\n`);
  return tarName;
}

function writeReport({ staticFindings, aiFindings, fixResults, version }) {
  const all   = dedup([...staticFindings, ...aiFindings]);
  const crits = all.filter(f => f.severity === 'critical');
  const warns = all.filter(f => f.severity === 'warning');
  let md = `# Childcare360 Release Bug Report\n\n`;
  md += `**Generated:** ${new Date().toISOString()}  \n**Version:** ${version}  \n\n`;
  md += `## Summary\n\n|Severity|Found|Fixed|\n|---|---|---|\n`;
  md += `|🔴 Critical|${crits.length}|${fixResults.fixed.length} files|\n`;
  md += `|🟡 Warning|${warns.length}|—|\n\n`;
  if (fixResults.failed.length > 0) {
    md += `## ❌ Manual Action Required\n\n`;
    for (const f of fixResults.failed) md += `- **${f.file}** [${f.rule}] — ${f.error}\n`;
    md += '\n';
  }
  if (crits.length > 0) {
    md += `## 🔴 Critical\n\n`;
    for (const f of crits) {
      md += `### ${f.file} line ${f.line||'?'} [${f.rule}]${fixResults.fixed.includes(f.file)?' ✅ fixed':''}\n`;
      md += `**Issue:** ${f.description}  \n**Fix:** ${f.fix_hint}\n\n`;
    }
  }
  if (warns.length > 0) {
    md += `## 🟡 Warnings\n\n`;
    for (const f of warns) md += `- **${f.file}**:${f.line||'?'} [${f.rule}] — ${f.description}\n`;
  }
  md += '\n---\n*Childcare360 Release Agent*\n';
  writeFile('RELEASE_BUG_REPORT.md', md);
}

async function main() {
  const t0 = Date.now();
  log(`\n${c.bold}${c.magenta}╔══════════════════════════════════════════╗`);
  log(`║   🔍 Childcare360 Release Agent v2       ║`);
  log(`╚══════════════════════════════════════════╝${c.reset}`);
  const flags = [SKIP_AI?'static-only':'static+AI', FIX?'auto-fix':'report-only',
    PACKAGE?'package':null, DRY_RUN?'DRY-RUN':null].filter(Boolean);
  log(`${c.dim}  Mode: ${flags.join(' | ')}${c.reset}\n`);

  // Load .env
  const envPath = path.join(ROOT, '.env');
  if (fs.existsSync(envPath)) {
    for (const line of fs.readFileSync(envPath,'utf8').split('\n')) {
      const eq = line.indexOf('=');
      if (eq === -1 || line.startsWith('#')) continue;
      const k = line.substring(0,eq).trim();
      const v = line.substring(eq+1).trim().replace(/^['"]|['"]$/g,'');
      if (k && !process.env[k]) process.env[k] = v;
    }
  }

  const pkg = JSON.parse(readFile('package.json') || '{"version":"0.0.0"}');
  info(`Current version: ${c.cyan}${pkg.version}${c.reset}`);
  if (!process.env.ANTHROPIC_API_KEY && !SKIP_AI)
    warn('ANTHROPIC_API_KEY not set — AI analysis disabled. Built-in fixes (form tags, CSS imports) still work.');

  const FILES = discoverFiles();
  info(`Scanning ${FILES.jsx.length} JSX + ${FILES.server.length} server files`);

  hdr('Phase 1 — Static Analysis');
  const staticFindings = runStaticAnalysis();
  const sc = staticFindings.filter(f => f.severity === 'critical');
  const sw = staticFindings.filter(f => f.severity === 'warning');
  if (!sc.length && !sw.length) ok('All static checks passed');
  else {
    for (const f of sc) fail(`${c.red}CRITICAL${c.reset} ${f.file}:${f.line||'?'} [${f.rule}] — ${f.description}`);
    for (const f of sw) warn(`${f.file}:${f.line||'?'} [${f.rule}] — ${f.description}`);
  }

  let aiFindings = [];
  if (!SKIP_AI && process.env.ANTHROPIC_API_KEY) {
    hdr('Phase 2 — AI Semantic Analysis');
    aiFindings = await runAIAnalysis(FILES);
  } else if (!SKIP_AI) {
    info('AI analysis skipped — add ANTHROPIC_API_KEY to .env to enable');
  }

  const allCrits = dedup([...staticFindings, ...aiFindings]).filter(f => f.severity === 'critical');
  let fixResults = { fixed:[], failed:[] };

  if (FIX && allCrits.length > 0) {
    hdr('Auto-fix — Critical Issues');
    fixResults = await autoFix(allCrits);
    if (fixResults.fixed.length > 0 && !DRY_RUN) {
      log(''); info('Re-checking fixed files...');
      const recheck = runStaticAnalysis().filter(f =>
        f.severity === 'critical' && fixResults.fixed.includes(f.file)
      );
      recheck.length === 0 ? ok('All fixed files pass ✓') :
        recheck.forEach(f => warn(`Still present: ${f.file} [${f.rule}]`));
    }
  } else if (FIX) {
    info('No critical issues to fix');
  }

  hdr('Report');
  writeReport({ staticFindings, aiFindings, fixResults, version:pkg.version });
  ok('Written: RELEASE_BUG_REPORT.md');

  hdr('Summary');
  const all    = dedup([...staticFindings, ...aiFindings]);
  const tc     = all.filter(f => f.severity === 'critical').length;
  const tw     = all.filter(f => f.severity === 'warning').length;
  const unfixed = Math.max(0, tc - fixResults.fixed.length) +
    fixResults.failed.filter(f => !f.error.toLowerCase().includes('api key') && !f.error.toLowerCase().includes('api_key')).length;
  const elapsed = ((Date.now()-t0)/1000).toFixed(1);
  log(`\n  ${'─'.repeat(46)}`);
  log(`  Critical: ${tc?c.red:c.green}${tc}${c.reset}  (${fixResults.fixed.length} fixed, ${unfixed?c.red:c.green}${unfixed} remaining${c.reset})`);
  log(`  Warnings: ${tw?c.yellow:c.green}${tw}${c.reset}`);
  log(`  Time:     ${elapsed}s`);
  log(`  ${'─'.repeat(46)}\n`);

  if (PACKAGE) {
    if (unfixed > 0) { fail(`Cannot package: ${unfixed} critical issue(s) remain.`); process.exit(1); }
    packageRelease(TARGET_VERSION || bumpPatch(pkg.version));
  } else if (FIX && fixResults.fixed.length > 0) {
    info('Fixes applied. Run with --package to create a release tar.');
  }

  process.exit(unfixed > 0 ? 1 : 0);
}

main().catch(e => {
  console.error(`\n${c.red}${c.bold}Fatal: ${e.message}${c.reset}`);
  if (VERBOSE) console.error(e.stack);
  process.exit(2);
});
